﻿Public Class About
    Private Sub bt_create_conponent_Click(sender As Object, e As EventArgs) Handles bt_create_conponent.Click
        My.Forms.About.Close()
        My.Forms.CNS_Auto_E.Show()
    End Sub
End Class