﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class CNS_Auto_E
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(CNS_Auto_E))
        Me.TV_Test_Component_List = New System.Windows.Forms.TreeView()
        Me.CMS_Actions = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ClickToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WriteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SelectToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IsElementAvailableToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IsElementDisplayToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WaitUntilElementDisplayToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RunTimeChangeObjectValueToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CapturePropertyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InnerTextToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ValueToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IDToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TypeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MS_Functions = New System.Windows.Forms.MenuStrip()
        Me.MenuToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TS_Load_URL_Function = New System.Windows.Forms.ToolStripMenuItem()
        Me.WaitForPageLoadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TakeScreenShotToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MyWaitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.BrowserBackToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BrowserRefreshToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BrowserForwardToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AcceptAlertToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DismissAlertToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Switch2FrameToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SwitchBackToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SwitchToTabToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SwitchBackToMainTabToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConditionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem7 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem8 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem11 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem12 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem13 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem15 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem16 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CodeSeparatorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.lbl_Test_Component = New System.Windows.Forms.Label()
        Me.lbl_Script_Steps = New System.Windows.Forms.Label()
        Me.OFD_Get_File = New System.Windows.Forms.OpenFileDialog()
        Me.TV_web_Object_List = New System.Windows.Forms.TreeView()
        Me.DG_CodeSection = New System.Windows.Forms.DataGridView()
        Me.MenuStrip_DataGridView_Code = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.CopyModeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PastedisableToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeleteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CommentCodeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemoveCodeCommentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lbl_TC_Last_UpdatedBy = New System.Windows.Forms.Label()
        Me.lbl_TC_last_Updated_Time = New System.Windows.Forms.Label()
        Me.lbl_TC_Status = New System.Windows.Forms.Label()
        Me.lbl_about = New System.Windows.Forms.LinkLabel()
        Me.bt_create_Object_File = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.bt_create_conponent_ = New System.Windows.Forms.Button()
        Me.Bt_Edit_Web_Repository = New System.Windows.Forms.Button()
        Me.bt_Delete_Component = New System.Windows.Forms.Button()
        Me.bt_excel = New System.Windows.Forms.Button()
        Me.bt_up = New System.Windows.Forms.Button()
        Me.bt_down = New System.Windows.Forms.Button()
        Me.bt_delete_row = New System.Windows.Forms.Button()
        Me.bt_run_program = New System.Windows.Forms.Button()
        Me.bt_compile_program = New System.Windows.Forms.Button()
        Me.bt_create_conponent = New System.Windows.Forms.Button()
        Me.Object_Name = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Test_Data = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Comment_Line = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.Dev_Note = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Sequence_Numbers = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CMS_Actions.SuspendLayout()
        Me.MS_Functions.SuspendLayout()
        CType(Me.DG_CodeSection, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip_DataGridView_Code.SuspendLayout()
        Me.SuspendLayout()
        '
        'TV_Test_Component_List
        '
        Me.TV_Test_Component_List.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TV_Test_Component_List.Font = New System.Drawing.Font("Berlin Sans FB", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TV_Test_Component_List.HideSelection = False
        Me.TV_Test_Component_List.Location = New System.Drawing.Point(8, 139)
        Me.TV_Test_Component_List.Name = "TV_Test_Component_List"
        Me.TV_Test_Component_List.ShowLines = False
        Me.TV_Test_Component_List.ShowPlusMinus = False
        Me.TV_Test_Component_List.ShowRootLines = False
        Me.TV_Test_Component_List.Size = New System.Drawing.Size(222, 616)
        Me.TV_Test_Component_List.TabIndex = 0
        '
        'CMS_Actions
        '
        Me.CMS_Actions.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ClickToolStripMenuItem, Me.WriteToolStripMenuItem, Me.SelectToolStripMenuItem, Me.IsElementAvailableToolStripMenuItem, Me.IsElementDisplayToolStripMenuItem, Me.WaitUntilElementDisplayToolStripMenuItem, Me.RunTimeChangeObjectValueToolStripMenuItem, Me.CapturePropertyToolStripMenuItem})
        Me.CMS_Actions.Name = "CMS_Actions"
        Me.CMS_Actions.Size = New System.Drawing.Size(280, 180)
        '
        'ClickToolStripMenuItem
        '
        Me.ClickToolStripMenuItem.Name = "ClickToolStripMenuItem"
        Me.ClickToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.ClickToolStripMenuItem.Text = "Click"
        '
        'WriteToolStripMenuItem
        '
        Me.WriteToolStripMenuItem.Name = "WriteToolStripMenuItem"
        Me.WriteToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.WriteToolStripMenuItem.Text = "Write"
        '
        'SelectToolStripMenuItem
        '
        Me.SelectToolStripMenuItem.Name = "SelectToolStripMenuItem"
        Me.SelectToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.SelectToolStripMenuItem.Text = "Select"
        '
        'IsElementAvailableToolStripMenuItem
        '
        Me.IsElementAvailableToolStripMenuItem.Name = "IsElementAvailableToolStripMenuItem"
        Me.IsElementAvailableToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.IsElementAvailableToolStripMenuItem.Text = "Is Element Exist"
        '
        'IsElementDisplayToolStripMenuItem
        '
        Me.IsElementDisplayToolStripMenuItem.Name = "IsElementDisplayToolStripMenuItem"
        Me.IsElementDisplayToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.IsElementDisplayToolStripMenuItem.Text = "Is Element Display"
        '
        'WaitUntilElementDisplayToolStripMenuItem
        '
        Me.WaitUntilElementDisplayToolStripMenuItem.Name = "WaitUntilElementDisplayToolStripMenuItem"
        Me.WaitUntilElementDisplayToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.WaitUntilElementDisplayToolStripMenuItem.Text = "Wait Until Element Display"
        '
        'RunTimeChangeObjectValueToolStripMenuItem
        '
        Me.RunTimeChangeObjectValueToolStripMenuItem.Name = "RunTimeChangeObjectValueToolStripMenuItem"
        Me.RunTimeChangeObjectValueToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.RunTimeChangeObjectValueToolStripMenuItem.Text = "Run Time Change WebObject Property"
        '
        'CapturePropertyToolStripMenuItem
        '
        Me.CapturePropertyToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.InnerTextToolStripMenuItem, Me.ValueToolStripMenuItem, Me.IDToolStripMenuItem, Me.TypeToolStripMenuItem})
        Me.CapturePropertyToolStripMenuItem.Name = "CapturePropertyToolStripMenuItem"
        Me.CapturePropertyToolStripMenuItem.Size = New System.Drawing.Size(279, 22)
        Me.CapturePropertyToolStripMenuItem.Text = "Capture Attribute"
        '
        'InnerTextToolStripMenuItem
        '
        Me.InnerTextToolStripMenuItem.Name = "InnerTextToolStripMenuItem"
        Me.InnerTextToolStripMenuItem.Size = New System.Drawing.Size(127, 22)
        Me.InnerTextToolStripMenuItem.Text = "Inner-Text"
        '
        'ValueToolStripMenuItem
        '
        Me.ValueToolStripMenuItem.Name = "ValueToolStripMenuItem"
        Me.ValueToolStripMenuItem.Size = New System.Drawing.Size(127, 22)
        Me.ValueToolStripMenuItem.Text = "Value"
        '
        'IDToolStripMenuItem
        '
        Me.IDToolStripMenuItem.Name = "IDToolStripMenuItem"
        Me.IDToolStripMenuItem.Size = New System.Drawing.Size(127, 22)
        Me.IDToolStripMenuItem.Text = "ID"
        '
        'TypeToolStripMenuItem
        '
        Me.TypeToolStripMenuItem.Name = "TypeToolStripMenuItem"
        Me.TypeToolStripMenuItem.Size = New System.Drawing.Size(127, 22)
        Me.TypeToolStripMenuItem.Text = "Type"
        '
        'MS_Functions
        '
        Me.MS_Functions.Dock = System.Windows.Forms.DockStyle.None
        Me.MS_Functions.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MS_Functions.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MenuToolStripMenuItem})
        Me.MS_Functions.Location = New System.Drawing.Point(1016, 102)
        Me.MS_Functions.Name = "MS_Functions"
        Me.MS_Functions.Size = New System.Drawing.Size(199, 31)
        Me.MS_Functions.TabIndex = 12
        Me.MS_Functions.Text = "MS_Functions"
        '
        'MenuToolStripMenuItem
        '
        Me.MenuToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AToolStripMenuItem, Me.BToolStripMenuItem, Me.ConditionsToolStripMenuItem, Me.CToolStripMenuItem, Me.CodeSeparatorToolStripMenuItem})
        Me.MenuToolStripMenuItem.Font = New System.Drawing.Font("Berlin Sans FB", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuToolStripMenuItem.Name = "MenuToolStripMenuItem"
        Me.MenuToolStripMenuItem.Size = New System.Drawing.Size(191, 27)
        Me.MenuToolStripMenuItem.Text = "Functions / Methods"
        '
        'AToolStripMenuItem
        '
        Me.AToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TS_Load_URL_Function, Me.WaitForPageLoadToolStripMenuItem, Me.TakeScreenShotToolStripMenuItem, Me.MyWaitToolStripMenuItem, Me.ToolStripMenuItem2, Me.BrowserBackToolStripMenuItem, Me.BrowserRefreshToolStripMenuItem, Me.BrowserForwardToolStripMenuItem})
        Me.AToolStripMenuItem.Name = "AToolStripMenuItem"
        Me.AToolStripMenuItem.Size = New System.Drawing.Size(218, 28)
        Me.AToolStripMenuItem.Text = "Browser"
        '
        'TS_Load_URL_Function
        '
        Me.TS_Load_URL_Function.Name = "TS_Load_URL_Function"
        Me.TS_Load_URL_Function.Size = New System.Drawing.Size(306, 28)
        Me.TS_Load_URL_Function.Text = "Open Browser / Load URL"
        '
        'WaitForPageLoadToolStripMenuItem
        '
        Me.WaitForPageLoadToolStripMenuItem.Name = "WaitForPageLoadToolStripMenuItem"
        Me.WaitForPageLoadToolStripMenuItem.Size = New System.Drawing.Size(306, 28)
        Me.WaitForPageLoadToolStripMenuItem.Text = "Wait For Page Load"
        '
        'TakeScreenShotToolStripMenuItem
        '
        Me.TakeScreenShotToolStripMenuItem.Name = "TakeScreenShotToolStripMenuItem"
        Me.TakeScreenShotToolStripMenuItem.Size = New System.Drawing.Size(306, 28)
        Me.TakeScreenShotToolStripMenuItem.Text = "Take ScreenShot"
        '
        'MyWaitToolStripMenuItem
        '
        Me.MyWaitToolStripMenuItem.Name = "MyWaitToolStripMenuItem"
        Me.MyWaitToolStripMenuItem.Size = New System.Drawing.Size(306, 28)
        Me.MyWaitToolStripMenuItem.Text = "My Wait"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(306, 28)
        Me.ToolStripMenuItem2.Text = "Browser : Get URL"
        '
        'BrowserBackToolStripMenuItem
        '
        Me.BrowserBackToolStripMenuItem.Name = "BrowserBackToolStripMenuItem"
        Me.BrowserBackToolStripMenuItem.Size = New System.Drawing.Size(306, 28)
        Me.BrowserBackToolStripMenuItem.Text = "Browser : Back"
        '
        'BrowserRefreshToolStripMenuItem
        '
        Me.BrowserRefreshToolStripMenuItem.Name = "BrowserRefreshToolStripMenuItem"
        Me.BrowserRefreshToolStripMenuItem.Size = New System.Drawing.Size(306, 28)
        Me.BrowserRefreshToolStripMenuItem.Text = "Browser : Refresh"
        '
        'BrowserForwardToolStripMenuItem
        '
        Me.BrowserForwardToolStripMenuItem.Name = "BrowserForwardToolStripMenuItem"
        Me.BrowserForwardToolStripMenuItem.Size = New System.Drawing.Size(306, 28)
        Me.BrowserForwardToolStripMenuItem.Text = "Browser : Forward"
        '
        'BToolStripMenuItem
        '
        Me.BToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AcceptAlertToolStripMenuItem, Me.DismissAlertToolStripMenuItem, Me.Switch2FrameToolStripMenuItem, Me.SwitchBackToolStripMenuItem, Me.SwitchToTabToolStripMenuItem, Me.SwitchBackToMainTabToolStripMenuItem})
        Me.BToolStripMenuItem.Name = "BToolStripMenuItem"
        Me.BToolStripMenuItem.Size = New System.Drawing.Size(218, 28)
        Me.BToolStripMenuItem.Text = "Web"
        '
        'AcceptAlertToolStripMenuItem
        '
        Me.AcceptAlertToolStripMenuItem.Name = "AcceptAlertToolStripMenuItem"
        Me.AcceptAlertToolStripMenuItem.Size = New System.Drawing.Size(317, 28)
        Me.AcceptAlertToolStripMenuItem.Text = "Alert - Accept"
        '
        'DismissAlertToolStripMenuItem
        '
        Me.DismissAlertToolStripMenuItem.Name = "DismissAlertToolStripMenuItem"
        Me.DismissAlertToolStripMenuItem.Size = New System.Drawing.Size(317, 28)
        Me.DismissAlertToolStripMenuItem.Text = "Alert - Dismiss"
        '
        'Switch2FrameToolStripMenuItem
        '
        Me.Switch2FrameToolStripMenuItem.Name = "Switch2FrameToolStripMenuItem"
        Me.Switch2FrameToolStripMenuItem.Size = New System.Drawing.Size(317, 28)
        Me.Switch2FrameToolStripMenuItem.Text = "Switch to Frame"
        '
        'SwitchBackToolStripMenuItem
        '
        Me.SwitchBackToolStripMenuItem.Name = "SwitchBackToolStripMenuItem"
        Me.SwitchBackToolStripMenuItem.Size = New System.Drawing.Size(317, 28)
        Me.SwitchBackToolStripMenuItem.Text = "Switch Back to Main Frame"
        '
        'SwitchToTabToolStripMenuItem
        '
        Me.SwitchToTabToolStripMenuItem.Name = "SwitchToTabToolStripMenuItem"
        Me.SwitchToTabToolStripMenuItem.Size = New System.Drawing.Size(317, 28)
        Me.SwitchToTabToolStripMenuItem.Text = "Switch to Tab 2"
        '
        'SwitchBackToMainTabToolStripMenuItem
        '
        Me.SwitchBackToMainTabToolStripMenuItem.Name = "SwitchBackToMainTabToolStripMenuItem"
        Me.SwitchBackToMainTabToolStripMenuItem.Size = New System.Drawing.Size(317, 28)
        Me.SwitchBackToMainTabToolStripMenuItem.Text = "Switch Back to Main Tab"
        '
        'ConditionsToolStripMenuItem
        '
        Me.ConditionsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem7, Me.ToolStripMenuItem8, Me.ToolStripMenuItem11, Me.ToolStripMenuItem12, Me.ToolStripMenuItem13})
        Me.ConditionsToolStripMenuItem.Name = "ConditionsToolStripMenuItem"
        Me.ConditionsToolStripMenuItem.Size = New System.Drawing.Size(218, 28)
        Me.ConditionsToolStripMenuItem.Text = "Conditions"
        '
        'ToolStripMenuItem7
        '
        Me.ToolStripMenuItem7.Name = "ToolStripMenuItem7"
        Me.ToolStripMenuItem7.Size = New System.Drawing.Size(278, 28)
        Me.ToolStripMenuItem7.Text = "If Condition"
        '
        'ToolStripMenuItem8
        '
        Me.ToolStripMenuItem8.Name = "ToolStripMenuItem8"
        Me.ToolStripMenuItem8.Size = New System.Drawing.Size(278, 28)
        Me.ToolStripMenuItem8.Text = "If..Else Condition"
        '
        'ToolStripMenuItem11
        '
        Me.ToolStripMenuItem11.Name = "ToolStripMenuItem11"
        Me.ToolStripMenuItem11.Size = New System.Drawing.Size(278, 28)
        Me.ToolStripMenuItem11.Text = "Do..While Loop"
        '
        'ToolStripMenuItem12
        '
        Me.ToolStripMenuItem12.Name = "ToolStripMenuItem12"
        Me.ToolStripMenuItem12.Size = New System.Drawing.Size(278, 28)
        Me.ToolStripMenuItem12.Text = "While.. End While Loop"
        '
        'ToolStripMenuItem13
        '
        Me.ToolStripMenuItem13.Name = "ToolStripMenuItem13"
        Me.ToolStripMenuItem13.Size = New System.Drawing.Size(278, 28)
        Me.ToolStripMenuItem13.Text = "Exit Loop"
        '
        'CToolStripMenuItem
        '
        Me.CToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem15, Me.ToolStripMenuItem16})
        Me.CToolStripMenuItem.Name = "CToolStripMenuItem"
        Me.CToolStripMenuItem.Size = New System.Drawing.Size(218, 28)
        Me.CToolStripMenuItem.Text = "' Excel"
        '
        'ToolStripMenuItem15
        '
        Me.ToolStripMenuItem15.Name = "ToolStripMenuItem15"
        Me.ToolStripMenuItem15.Size = New System.Drawing.Size(318, 28)
        Me.ToolStripMenuItem15.Text = "Set Test Data Value"
        '
        'ToolStripMenuItem16
        '
        Me.ToolStripMenuItem16.Name = "ToolStripMenuItem16"
        Me.ToolStripMenuItem16.Size = New System.Drawing.Size(318, 28)
        Me.ToolStripMenuItem16.Text = "Store Data In Test Data File"
        '
        'CodeSeparatorToolStripMenuItem
        '
        Me.CodeSeparatorToolStripMenuItem.Name = "CodeSeparatorToolStripMenuItem"
        Me.CodeSeparatorToolStripMenuItem.Size = New System.Drawing.Size(218, 28)
        Me.CodeSeparatorToolStripMenuItem.Text = "Code Separator"
        '
        'lbl_Test_Component
        '
        Me.lbl_Test_Component.AutoSize = True
        Me.lbl_Test_Component.BackColor = System.Drawing.Color.Silver
        Me.lbl_Test_Component.Font = New System.Drawing.Font("Berlin Sans FB", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Test_Component.Location = New System.Drawing.Point(12, 110)
        Me.lbl_Test_Component.Name = "lbl_Test_Component"
        Me.lbl_Test_Component.Size = New System.Drawing.Size(162, 23)
        Me.lbl_Test_Component.TabIndex = 10
        Me.lbl_Test_Component.Text = "Test Component :"
        '
        'lbl_Script_Steps
        '
        Me.lbl_Script_Steps.AutoSize = True
        Me.lbl_Script_Steps.BackColor = System.Drawing.Color.Silver
        Me.lbl_Script_Steps.Font = New System.Drawing.Font("Berlin Sans FB", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Script_Steps.Location = New System.Drawing.Point(895, 110)
        Me.lbl_Script_Steps.Name = "lbl_Script_Steps"
        Me.lbl_Script_Steps.Size = New System.Drawing.Size(118, 23)
        Me.lbl_Script_Steps.TabIndex = 13
        Me.lbl_Script_Steps.Text = "Script Steps :"
        '
        'OFD_Get_File
        '
        Me.OFD_Get_File.FileName = "OFD_GetFile"
        Me.OFD_Get_File.Filter = "Web_Object Files|*.properties"
        Me.OFD_Get_File.Title = "UPLOAD WEB_OBJECT FILE"
        '
        'TV_web_Object_List
        '
        Me.TV_web_Object_List.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TV_web_Object_List.ContextMenuStrip = Me.CMS_Actions
        Me.TV_web_Object_List.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TV_web_Object_List.Location = New System.Drawing.Point(240, 139)
        Me.TV_web_Object_List.Name = "TV_web_Object_List"
        Me.TV_web_Object_List.ShowLines = False
        Me.TV_web_Object_List.ShowPlusMinus = False
        Me.TV_web_Object_List.ShowRootLines = False
        Me.TV_web_Object_List.Size = New System.Drawing.Size(246, 616)
        Me.TV_web_Object_List.TabIndex = 1
        '
        'DG_CodeSection
        '
        Me.DG_CodeSection.AllowUserToResizeColumns = False
        Me.DG_CodeSection.AllowUserToResizeRows = False
        Me.DG_CodeSection.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DG_CodeSection.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DG_CodeSection.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DG_CodeSection.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Object_Name, Me.DataGridViewTextBoxColumn1, Me.Test_Data, Me.Comment_Line, Me.Dev_Note, Me.Sequence_Numbers})
        Me.DG_CodeSection.ContextMenuStrip = Me.MenuStrip_DataGridView_Code
        Me.DG_CodeSection.Location = New System.Drawing.Point(492, 139)
        Me.DG_CodeSection.Name = "DG_CodeSection"
        Me.DG_CodeSection.Size = New System.Drawing.Size(990, 616)
        Me.DG_CodeSection.TabIndex = 3
        '
        'MenuStrip_DataGridView_Code
        '
        Me.MenuStrip_DataGridView_Code.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CopyModeToolStripMenuItem, Me.CopyToolStripMenuItem, Me.PastedisableToolStripMenuItem, Me.DeleteToolStripMenuItem, Me.CommentCodeToolStripMenuItem, Me.RemoveCodeCommentToolStripMenuItem})
        Me.MenuStrip_DataGridView_Code.Name = "MenuStrip_DataGridView_Code"
        Me.MenuStrip_DataGridView_Code.Size = New System.Drawing.Size(270, 136)
        '
        'CopyModeToolStripMenuItem
        '
        Me.CopyModeToolStripMenuItem.Name = "CopyModeToolStripMenuItem"
        Me.CopyModeToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.E), System.Windows.Forms.Keys)
        Me.CopyModeToolStripMenuItem.Size = New System.Drawing.Size(269, 22)
        Me.CopyModeToolStripMenuItem.Text = "Enable - Multi Selection Mode"
        '
        'CopyToolStripMenuItem
        '
        Me.CopyToolStripMenuItem.Name = "CopyToolStripMenuItem"
        Me.CopyToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.C), System.Windows.Forms.Keys)
        Me.CopyToolStripMenuItem.Size = New System.Drawing.Size(269, 22)
        Me.CopyToolStripMenuItem.Text = "Copy"
        '
        'PastedisableToolStripMenuItem
        '
        Me.PastedisableToolStripMenuItem.Name = "PastedisableToolStripMenuItem"
        Me.PastedisableToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.V), System.Windows.Forms.Keys)
        Me.PastedisableToolStripMenuItem.Size = New System.Drawing.Size(269, 22)
        Me.PastedisableToolStripMenuItem.Text = "Paste"
        '
        'DeleteToolStripMenuItem
        '
        Me.DeleteToolStripMenuItem.Name = "DeleteToolStripMenuItem"
        Me.DeleteToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D), System.Windows.Forms.Keys)
        Me.DeleteToolStripMenuItem.Size = New System.Drawing.Size(269, 22)
        Me.DeleteToolStripMenuItem.Text = "Delete"
        '
        'CommentCodeToolStripMenuItem
        '
        Me.CommentCodeToolStripMenuItem.Name = "CommentCodeToolStripMenuItem"
        Me.CommentCodeToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.C), System.Windows.Forms.Keys)
        Me.CommentCodeToolStripMenuItem.Size = New System.Drawing.Size(269, 22)
        Me.CommentCodeToolStripMenuItem.Text = "Comment Code"
        '
        'RemoveCodeCommentToolStripMenuItem
        '
        Me.RemoveCodeCommentToolStripMenuItem.Name = "RemoveCodeCommentToolStripMenuItem"
        Me.RemoveCodeCommentToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.U), System.Windows.Forms.Keys)
        Me.RemoveCodeCommentToolStripMenuItem.Size = New System.Drawing.Size(269, 22)
        Me.RemoveCodeCommentToolStripMenuItem.Text = "Un-Comment Code"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Silver
        Me.Label1.Font = New System.Drawing.Font("Berlin Sans FB", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(242, 110)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(154, 23)
        Me.Label1.TabIndex = 27
        Me.Label1.Text = "Web Object List :"
        '
        'lbl_TC_Last_UpdatedBy
        '
        Me.lbl_TC_Last_UpdatedBy.AutoSize = True
        Me.lbl_TC_Last_UpdatedBy.Location = New System.Drawing.Point(489, 761)
        Me.lbl_TC_Last_UpdatedBy.Name = "lbl_TC_Last_UpdatedBy"
        Me.lbl_TC_Last_UpdatedBy.Size = New System.Drawing.Size(95, 13)
        Me.lbl_TC_Last_UpdatedBy.TabIndex = 29
        Me.lbl_TC_Last_UpdatedBy.Text = "Last Updated By : "
        '
        'lbl_TC_last_Updated_Time
        '
        Me.lbl_TC_last_Updated_Time.AutoSize = True
        Me.lbl_TC_last_Updated_Time.Location = New System.Drawing.Point(669, 761)
        Me.lbl_TC_last_Updated_Time.Name = "lbl_TC_last_Updated_Time"
        Me.lbl_TC_last_Updated_Time.Size = New System.Drawing.Size(137, 13)
        Me.lbl_TC_last_Updated_Time.TabIndex = 30
        Me.lbl_TC_last_Updated_Time.Text = "Last Updated Date / Time :"
        '
        'lbl_TC_Status
        '
        Me.lbl_TC_Status.AutoSize = True
        Me.lbl_TC_Status.Location = New System.Drawing.Point(943, 761)
        Me.lbl_TC_Status.Name = "lbl_TC_Status"
        Me.lbl_TC_Status.Size = New System.Drawing.Size(43, 13)
        Me.lbl_TC_Status.TabIndex = 31
        Me.lbl_TC_Status.Text = "Status :"
        '
        'lbl_about
        '
        Me.lbl_about.AutoSize = True
        Me.lbl_about.Font = New System.Drawing.Font("Arial Narrow", 12.0!)
        Me.lbl_about.Location = New System.Drawing.Point(13, 761)
        Me.lbl_about.Name = "lbl_about"
        Me.lbl_about.Size = New System.Drawing.Size(44, 20)
        Me.lbl_about.TabIndex = 32
        Me.lbl_about.TabStop = True
        Me.lbl_about.Text = "About"
        '
        'bt_create_Object_File
        '
        Me.bt_create_Object_File.Image = Global.Auto_E.My.ResourcesRepair.Resources._1498639552_school_object_study_student_2
        Me.bt_create_Object_File.Location = New System.Drawing.Point(190, 95)
        Me.bt_create_Object_File.Name = "bt_create_Object_File"
        Me.bt_create_Object_File.Size = New System.Drawing.Size(40, 38)
        Me.bt_create_Object_File.TabIndex = 33
        Me.bt_create_Object_File.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Image = Global.Auto_E.My.ResourcesRepair.Resources._1493310165_make
        Me.Button1.Location = New System.Drawing.Point(12, 40)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(60, 49)
        Me.Button1.TabIndex = 4
        Me.Button1.UseVisualStyleBackColor = True
        '
        'bt_create_conponent_
        '
        Me.bt_create_conponent_.BackColor = System.Drawing.SystemColors.Control
        Me.bt_create_conponent_.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt_create_conponent_.Image = Global.Auto_E.My.ResourcesRepair.Resources.EditDocument
        Me.bt_create_conponent_.Location = New System.Drawing.Point(78, 40)
        Me.bt_create_conponent_.Name = "bt_create_conponent_"
        Me.bt_create_conponent_.Size = New System.Drawing.Size(60, 49)
        Me.bt_create_conponent_.TabIndex = 5
        Me.bt_create_conponent_.UseVisualStyleBackColor = False
        '
        'Bt_Edit_Web_Repository
        '
        Me.Bt_Edit_Web_Repository.Image = Global.Auto_E.My.ResourcesRepair.Resources._1490192373_pencil_gear
        Me.Bt_Edit_Web_Repository.Location = New System.Drawing.Point(402, 97)
        Me.Bt_Edit_Web_Repository.Name = "Bt_Edit_Web_Repository"
        Me.Bt_Edit_Web_Repository.Size = New System.Drawing.Size(40, 38)
        Me.Bt_Edit_Web_Repository.TabIndex = 7
        Me.Bt_Edit_Web_Repository.UseVisualStyleBackColor = True
        '
        'bt_Delete_Component
        '
        Me.bt_Delete_Component.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt_Delete_Component.Image = Global.Auto_E.My.ResourcesRepair.Resources.delete
        Me.bt_Delete_Component.Location = New System.Drawing.Point(144, 40)
        Me.bt_Delete_Component.Name = "bt_Delete_Component"
        Me.bt_Delete_Component.Size = New System.Drawing.Size(60, 49)
        Me.bt_Delete_Component.TabIndex = 6
        Me.bt_Delete_Component.UseVisualStyleBackColor = True
        '
        'bt_excel
        '
        Me.bt_excel.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt_excel.Image = Global.Auto_E.My.ResourcesRepair.Resources.microsoft_office_excel
        Me.bt_excel.Location = New System.Drawing.Point(612, 96)
        Me.bt_excel.Name = "bt_excel"
        Me.bt_excel.Size = New System.Drawing.Size(40, 38)
        Me.bt_excel.TabIndex = 10
        Me.bt_excel.UseVisualStyleBackColor = True
        '
        'bt_up
        '
        Me.bt_up.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt_up.Image = Global.Auto_E.My.ResourcesRepair.Resources.upload
        Me.bt_up.Location = New System.Drawing.Point(1267, 95)
        Me.bt_up.Name = "bt_up"
        Me.bt_up.Size = New System.Drawing.Size(40, 38)
        Me.bt_up.TabIndex = 14
        Me.bt_up.UseVisualStyleBackColor = True
        '
        'bt_down
        '
        Me.bt_down.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt_down.Image = Global.Auto_E.My.ResourcesRepair.Resources.download
        Me.bt_down.Location = New System.Drawing.Point(1313, 95)
        Me.bt_down.Name = "bt_down"
        Me.bt_down.Size = New System.Drawing.Size(40, 38)
        Me.bt_down.TabIndex = 15
        Me.bt_down.UseVisualStyleBackColor = True
        '
        'bt_delete_row
        '
        Me.bt_delete_row.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt_delete_row.Image = Global.Auto_E.My.ResourcesRepair.Resources.free
        Me.bt_delete_row.Location = New System.Drawing.Point(1221, 95)
        Me.bt_delete_row.Name = "bt_delete_row"
        Me.bt_delete_row.Size = New System.Drawing.Size(40, 38)
        Me.bt_delete_row.TabIndex = 13
        Me.bt_delete_row.UseVisualStyleBackColor = True
        '
        'bt_run_program
        '
        Me.bt_run_program.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt_run_program.Image = Global.Auto_E.My.ResourcesRepair.Resources.play_circle
        Me.bt_run_program.Location = New System.Drawing.Point(658, 96)
        Me.bt_run_program.Name = "bt_run_program"
        Me.bt_run_program.Size = New System.Drawing.Size(40, 38)
        Me.bt_run_program.TabIndex = 11
        Me.bt_run_program.UseVisualStyleBackColor = True
        '
        'bt_compile_program
        '
        Me.bt_compile_program.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt_compile_program.Image = Global.Auto_E.My.ResourcesRepair.Resources.application_code
        Me.bt_compile_program.Location = New System.Drawing.Point(538, 95)
        Me.bt_compile_program.Name = "bt_compile_program"
        Me.bt_compile_program.Size = New System.Drawing.Size(40, 38)
        Me.bt_compile_program.TabIndex = 9
        Me.bt_compile_program.UseVisualStyleBackColor = True
        '
        'bt_create_conponent
        '
        Me.bt_create_conponent.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt_create_conponent.Image = Global.Auto_E.My.ResourcesRepair.Resources.save
        Me.bt_create_conponent.Location = New System.Drawing.Point(492, 95)
        Me.bt_create_conponent.Name = "bt_create_conponent"
        Me.bt_create_conponent.Size = New System.Drawing.Size(40, 38)
        Me.bt_create_conponent.TabIndex = 8
        Me.bt_create_conponent.UseVisualStyleBackColor = True
        '
        'Object_Name
        '
        Me.Object_Name.HeaderText = "Object Name"
        Me.Object_Name.Name = "Object_Name"
        Me.Object_Name.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.HeaderText = "Action"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'Test_Data
        '
        Me.Test_Data.HeaderText = "Test Data"
        Me.Test_Data.Name = "Test_Data"
        Me.Test_Data.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'Comment_Line
        '
        Me.Comment_Line.HeaderText = "Comment Line"
        Me.Comment_Line.Name = "Comment_Line"
        '
        'Dev_Note
        '
        Me.Dev_Note.HeaderText = "Dev Note"
        Me.Dev_Note.Name = "Dev_Note"
        Me.Dev_Note.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'Sequence_Numbers
        '
        Me.Sequence_Numbers.HeaderText = "Sequence Numbers"
        Me.Sequence_Numbers.Name = "Sequence_Numbers"
        Me.Sequence_Numbers.ReadOnly = True
        '
        'CNS_Auto_E
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(1494, 783)
        Me.Controls.Add(Me.bt_create_Object_File)
        Me.Controls.Add(Me.lbl_about)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.lbl_TC_Status)
        Me.Controls.Add(Me.lbl_TC_last_Updated_Time)
        Me.Controls.Add(Me.lbl_TC_Last_UpdatedBy)
        Me.Controls.Add(Me.bt_create_conponent_)
        Me.Controls.Add(Me.Bt_Edit_Web_Repository)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.bt_Delete_Component)
        Me.Controls.Add(Me.bt_excel)
        Me.Controls.Add(Me.bt_up)
        Me.Controls.Add(Me.bt_down)
        Me.Controls.Add(Me.bt_delete_row)
        Me.Controls.Add(Me.bt_run_program)
        Me.Controls.Add(Me.bt_compile_program)
        Me.Controls.Add(Me.bt_create_conponent)
        Me.Controls.Add(Me.DG_CodeSection)
        Me.Controls.Add(Me.TV_web_Object_List)
        Me.Controls.Add(Me.lbl_Script_Steps)
        Me.Controls.Add(Me.lbl_Test_Component)
        Me.Controls.Add(Me.MS_Functions)
        Me.Controls.Add(Me.TV_Test_Component_List)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "CNS_Auto_E"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "CNS_Auto-E"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.CMS_Actions.ResumeLayout(False)
        Me.MS_Functions.ResumeLayout(False)
        Me.MS_Functions.PerformLayout()
        CType(Me.DG_CodeSection, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip_DataGridView_Code.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TV_Test_Component_List As TreeView
    Friend WithEvents CMS_Actions As ContextMenuStrip
    Friend WithEvents MS_Functions As MenuStrip
    Friend WithEvents MenuToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TS_Load_URL_Function As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents BToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem15 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem16 As ToolStripMenuItem
    Friend WithEvents ConditionsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem7 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem8 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem11 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem12 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem13 As ToolStripMenuItem
    Friend WithEvents lbl_Test_Component As Label
    Friend WithEvents lbl_Script_Steps As Label
    Friend WithEvents ClickToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents WriteToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SelectToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OFD_Get_File As OpenFileDialog
    Friend WithEvents TV_web_Object_List As TreeView
    Friend WithEvents DG_CodeSection As DataGridView
    Friend WithEvents WaitForPageLoadToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents WaitUntilElementDisplayToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents bt_create_conponent As Button
    Friend WithEvents bt_compile_program As Button
    Friend WithEvents bt_run_program As Button
    Friend WithEvents bt_delete_row As Button
    Friend WithEvents bt_down As Button
    Friend WithEvents bt_up As Button
    Friend WithEvents bt_excel As Button
    Friend WithEvents bt_create_conponent_ As Button
    Friend WithEvents bt_Delete_Component As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Bt_Edit_Web_Repository As Button
    Friend WithEvents RunTimeChangeObjectValueToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TakeScreenShotToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BrowserBackToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BrowserRefreshToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents IsElementAvailableToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents IsElementDisplayToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AcceptAlertToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DismissAlertToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Switch2FrameToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SwitchBackToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CapturePropertyToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents InnerTextToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents IDToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TypeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MyWaitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BrowserForwardToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CodeSeparatorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents lbl_TC_Last_UpdatedBy As Label
    Friend WithEvents lbl_TC_last_Updated_Time As Label
    Friend WithEvents lbl_TC_Status As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents lbl_about As LinkLabel
    Friend WithEvents ValueToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SwitchToTabToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SwitchBackToMainTabToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents bt_create_Object_File As Button
    Friend WithEvents MenuStrip_DataGridView_Code As ContextMenuStrip
    Friend WithEvents CopyModeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PastedisableToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CopyToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DeleteToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CommentCodeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RemoveCodeCommentToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Object_Name As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents Test_Data As DataGridViewTextBoxColumn
    Friend WithEvents Comment_Line As DataGridViewCheckBoxColumn
    Friend WithEvents Dev_Note As DataGridViewTextBoxColumn
    Friend WithEvents Sequence_Numbers As DataGridViewTextBoxColumn
End Class
