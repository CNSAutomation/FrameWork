﻿Imports System.ComponentModel
Imports System.Data.SqlClient
Imports Excel = Microsoft.Office.Interop.Excel
Imports System.Runtime.InteropServices
Imports System.IO

Public Class CNS_Auto_E

    Public path, foldername As String
    Dim file, runme As System.IO.StreamWriter
    Public RepositoryFilePath As String
    Dim TestDataFileAddress As String

    'Declaration of Excel Objects
    Dim appXL As Excel.Application
    Dim wbXl As Excel.Workbook
    Dim shXL As Excel.Worksheet
    Dim raXL As Excel.Range

    'DataBase
    Dim cn As SqlConnection
    Dim cmd As SqlCommand
    Dim da As SqlDataAdapter
    Dim bm As BindingManagerBase
    Dim ds As New Data.DataSet

    'Save After Change
    Dim savechange As Integer = 0
    Dim CurrentSelectedNode As Integer
    Dim fireeve As Integer

    'Copy Patse Variables
    Dim RowList As New List(Of String)()
    Private Sub CNS_Auto_E_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Path_File_Generate()

        path = GetProject_FolderPath()


        DB_Selection()

        get_List_of_test_components()

        'DG_CodeSection.Columns(5).Visible = False

        DG_CodeSection.RowHeadersVisible = False
        DG_CodeSection.MultiSelect = False
        Dim intX As Integer = Screen.PrimaryScreen.Bounds.Width
        Dim intY As Integer = Screen.PrimaryScreen.Bounds.Height

        bt_down.Location = New Point(intX - 70, 95)
        bt_up.Location = New Point(intX - 115, 95)
        bt_delete_row.Location = New Point(intX - 160, 95)
        MS_Functions.Location = New Point(intX - 450, 98)
        If intX < 1599 Then
            lbl_Script_Steps.Location = New Point(intX - 600, 110)
        End If
        lbl_about.Location = New Point(10, intY - 90)
        lbl_TC_Status.Location = New Point(intX - 1110, intY - 85)
        lbl_TC_last_Updated_Time.Location = New Point(intX - 650, intY - 85)
        lbl_TC_Last_UpdatedBy.Location = New Point(intX - 300, intY - 85)
        TV_Test_Component_List.Sort()
    End Sub
    Sub Path_File_Generate()
        'MsgBox("Executable Path" + Application.StartupPath)

        Dim utf8 As New System.Text.UTF8Encoding(False)
        'if exist delete old

        If (Not System.IO.Directory.Exists("C:\E_FrameWork\Test Componentz\")) Then
            System.IO.Directory.CreateDirectory("C:\E_FrameWork\Test Componentz\")
        End If

        If System.IO.File.Exists("C:\E_FrameWork\Test Componentz" + "\Path_Folder.txt") Then
            System.IO.File.Delete("C:\E_FrameWork\Test Componentz" + "\Path_Folder.txt")
        End If

        runme = My.Computer.FileSystem.OpenTextFileWriter("C:\E_FrameWork\Test Componentz" + "\Path_Folder.txt", True, utf8)

        runme.WriteLine("Path : " + Application.StartupPath)
        runme.Close()
    End Sub
    Sub DB_Selection()
        'START : DB SECTION

        'cn = New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=" + GetDBPATH() + ";Integrated Security=False;User Id=sa,;Password=user123")

        'cn = New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=" + GetDBPATH() + ";Integrated Security=False;User ID=sa;Password=user123;Connect Timeout=15;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False")

        'IN-USE Temp
        '''cn = New SqlConnection("Server=CNS10\E_MSSQLSERVER;Database=Auto_E_DB;User ID=sa;Password=user@123;Trusted_Connection=True;")
        cn = New SqlConnection("Server=db;Database=Auto_E;Integrated Security=SSPI;")
        'IN-USETemp

        'REAL
        'cn = New SqlConnection("Server=.\SQLExpress;Database=AUTO_E;Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=" + My.Forms.CNS_Auto_E.GetDBPATH() + ";Integrated Security=True;User ID=sa;Password=user123;Trusted_Connection=True;MultipleActiveResultSets=true")
        'REAL

        'DB : \\CNNAS\AUTOMATION\AUTO-E\DB\AUTO_E.MDF
        cmd = New SqlCommand("select * from Test_Component_Creation", cn)

        da = New SqlDataAdapter(cmd)

        da.Fill(ds)
        bm = Me.BindingContext(ds.Tables(0))
        'END : DB SECTION
    End Sub
    Sub get_List_of_test_components()
        'Get TOTAL TestComponent List From DB
        Dim propertyList As New List(Of String)()

        For i = 0 To ds.Tables(0).Rows.Count - 1
            propertyList.Add(ds.Tables(0).Rows(i)("TestComponent_Name").ToString)
        Next

        For i = 0 To ds.Tables(0).Rows.Count - 1
            TV_Test_Component_List.Nodes.Add(propertyList(i))
        Next


        'Get Total Rows in DB Table
        'MsgBox("Count Again" + ds.Tables(0).Rows.Count.ToString())
    End Sub
    Sub get_all_table_names_from_db()
        Dim createtable As String = "Select TABLE_NAME from INFORMATION_SCHEMA.TABLES;"

        Dim Execute_Cmdfd As New SqlCommand(createtable, cn)
        cn.Open()
        Using RDR = Execute_Cmdfd.ExecuteReader()
            If RDR.HasRows Then
                Do While RDR.Read
                    MsgBox(RDR("TABLE_NAME").ToString())
                Loop
            End If
        End Using
        cn.Close()
    End Sub
    Sub Delete_TableData_from_table(tableName As String)
        Dim createtable As String = "delete from " + tableName

        Dim Execute_Cmdfdd As New SqlCommand(createtable, cn)
        cn.Open()
        Execute_Cmdfdd.ExecuteNonQuery()
        cn.Close()
    End Sub
    Function GetDBPATH()
        '.exe PATH
        ' MsgBox("Executable Path" + Application.StartupPath)
        Dim line As String = ""
        Try
            Using sr As New StreamReader(Application.StartupPath + "\DSS.lib")
                ' Read the stream to a string and write the string to the console.
                line = sr.ReadLine
                'Console.WriteLine(line)
                sr.Close()
            End Using
        Catch ex As Exception
            MsgBox("DB String not found, Please check DSS file.",, "DSS file missing.")
        End Try

        Return line.ToString
    End Function
    Function GetProject_FolderPath()
        '.exe PATH
        ' MsgBox("Executable Path" + Application.StartupPath)
        Dim line = "", linel As String = ""

        Try
            Using sr As New StreamReader(Application.StartupPath + "\DSS.lib")
                ' Read the stream to a string and write the string to the console.
                line = sr.ReadLine()
                linel = sr.ReadLine()
                'Console.WriteLine(line)
                sr.Close()
            End Using
        Catch ex As Exception
            MsgBox("PATH String not found, Please check DSS file.",, "DSS file missing.")
        End Try
        Return linel.ToString

        'Return Application.StartupPath
    End Function
    Private Sub Button1_Click(sender As Object, e As EventArgs)
        'OFD_Get_File.ShowDialog()

        'RepositoryFilePath = OFD_Get_File.FileName
    End Sub

    Private Sub OFD_Get_File_FileOk(sender As Object, e As CancelEventArgs) Handles OFD_Get_File.FileOk
        ' MsgBox(OFD_Get_File.FileName.ToString)


        'START : READ WEB-OBJECT FROM .PROPERTIES FILE
        '''TV_web_Object_List.Nodes.Clear()

        '''Dim reader As System.IO.StreamReader = My.Computer.FileSystem.OpenTextFileReader(OFD_Get_File.FileName.ToString)
        '''Dim a As String
        '''Dim no As Integer = 1
        '''Dim PropertyNamesArray As String()
        '''Dim propertyList As New List(Of String)()

        '''Do
        '''    a = reader.ReadLine
        '''    If a <> "" Then
        '''        Dim PropertyArray As Char() = a.ToCharArray
        '''        Dim firstName As Char()

        '''        For i = 0 To PropertyArray.Length - 1
        '''            If PropertyArray(i) = "=" Then
        '''                Exit For
        '''            Else
        '''                firstName = firstName + PropertyArray(i)
        '''            End If
        '''        Next


        '''        propertyList.Add(firstName)
        '''        ' MsgBox(no.ToString + " : Property Name = " + firstName)
        '''        no = no + 1
        '''        firstName = ""
        '''    End If
        '''Loop Until a Is Nothing

        '''reader.Close()
        '''PropertyNamesArray = propertyList.ToArray

        '''For i = 0 To PropertyNamesArray.Length - 1
        '''    Dim getElement_Type As Char() = PropertyNamesArray(i).ToCharArray
        '''    Dim getElement_Ini As String
        '''    For y = 0 To 3
        '''        getElement_Ini = getElement_Ini + getElement_Type(y)
        '''    Next

        '''    If getElement_Ini = "lnk_" Or getElement_Ini = "lbl_" Or getElement_Ini = "txt_" Or getElement_Ini = "cmb_" Or getElement_Ini = "chk_" Or getElement_Ini = "rbd_" Or getElement_Ini = "img_" Or getElement_Ini = "btn_" Then
        '''        TV_web_Object_List.Nodes.Add(PropertyNamesArray(i))
        '''    End If
        '''    getElement_Ini = ""
        '''Next
        'END : READ WEB-OBJECT FROM .PROPERTIES FILE

    End Sub
    'Strip MENU
    Private Sub ClickToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ClickToolStripMenuItem.Click
        'MsgBox("Selected Row : " + GetSelectedRow().ToString)
        'MsgBox("Active Row : " + (GetActiveRow() - 2).ToString)

        If DG_CodeSection.SelectedRows.Count = 1 Then
            DG_CodeSection.Rows.Insert(GetSelectedRow(), TV_web_Object_List.SelectedNode.Text, "Click", "", False, "")
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).ReadOnly = True
        Else
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = TV_web_Object_List.SelectedNode.Text
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = "Click"
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).ReadOnly = True
        End If
    End Sub

    Private Sub WriteToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles WriteToolStripMenuItem.Click
        If DG_CodeSection.SelectedRows.Count = 1 Then
            DG_CodeSection.Rows.Insert(GetSelectedRow(), TV_web_Object_List.SelectedNode.Text, "Write", "", False, "")
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).ReadOnly = False
        Else
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = TV_web_Object_List.SelectedNode.Text
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = "Write"
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).ReadOnly = False
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).Value = ""
        End If

    End Sub
    Private Sub WaitUntilElementDisplayToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles WaitUntilElementDisplayToolStripMenuItem.Click
        If DG_CodeSection.SelectedRows.Count = 1 Then
            DG_CodeSection.Rows.Insert(GetSelectedRow(), TV_web_Object_List.SelectedNode.Text, "Wait Until Element Display", "", False, "")
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).ReadOnly = True
        Else
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = TV_web_Object_List.SelectedNode.Text
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = "Wait Until Element Display"
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).ReadOnly = True
        End If

    End Sub
    Private Sub SelectToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SelectToolStripMenuItem.Click
        'Condition to Add in Selected Row
        If DG_CodeSection.SelectedRows.Count = 1 Then
            DG_CodeSection.Rows.Insert(GetSelectedRow(), TV_web_Object_List.SelectedNode.Text, "Select From Drop-Down/ListBox", "", False, "")
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).ReadOnly = False
        Else
            'Condition to Add in Last Row
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = TV_web_Object_List.SelectedNode.Text
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = "Select From Drop-Down/ListBox"
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).ReadOnly = False
        End If
    End Sub

    'Strip MENU
    'START: Get Active Row Index
    Function GetActiveRow()
        Dim GetRowNo As Integer = 0

        For i = 0 To DG_CodeSection.Rows.Count - 1
            GetRowNo = GetRowNo + 1
        Next

        Return GetRowNo
    End Function
    'END: Get Active Row Index
    'START: Get Selected Row Index
    Function GetSelectedRow()
        'Dim GetRowNo As Integer = 0

        'For i = 0 To DG_CodeSection.Rows.Count - 1
        '    GetRowNo = GetRowNo + 1
        'Next
        Try
            Return DG_CodeSection.SelectedCells.Item(0).RowIndex
        Catch ex As Exception
            MsgBox("Next Time... Please select any 'Code Section' row, before selecting this option.",, "Auto-E Suggestion")
            Application.Exit()

        End Try


    End Function
    'END: Get Selected Row Index
    Private Sub TV_web_Object_List_MouseClick(sender As Object, e As MouseEventArgs) Handles TV_web_Object_List.MouseClick
        'When User Click Right Click
        If e.Button = MouseButtons.Right Then

            'Get First four Characters of selected Node
            Dim getElement_Type As Char() = TV_web_Object_List.SelectedNode.Text.ToCharArray
            Dim getElement_Ini As String = ""
            For y = 0 To 3
                getElement_Ini = getElement_Ini + getElement_Type(y)
            Next

            'hide all nodes
            CMS_Actions.Items(0).Visible = False
            CMS_Actions.Items(1).Visible = False
            CMS_Actions.Items(2).Visible = False

            If getElement_Ini = "lnk_" Then
                CMS_Actions.Items(0).Visible = True

            ElseIf getElement_Ini = "txt_" Then
                CMS_Actions.Items(0).Visible = True
                CMS_Actions.Items(1).Visible = True

            ElseIf getElement_Ini = "cmb_" Then
                CMS_Actions.Items(0).Visible = True

                CMS_Actions.Items(2).Visible = True
            ElseIf getElement_Ini = "chk_" Then
                CMS_Actions.Items(0).Visible = True

            ElseIf getElement_Ini = "rbd_" Then
                CMS_Actions.Items(0).Visible = True

            ElseIf getElement_Ini = "lbl_" Or getElement_Ini = "img_" Or getElement_Ini = "btn_" Then
                CMS_Actions.Items(0).Visible = True

            End If
        End If
    End Sub

    Private Sub TS_Load_URL_Function_Click(sender As Object, e As EventArgs) Handles TS_Load_URL_Function.Click
        If DG_CodeSection.SelectedRows.Count = 1 Then
            DG_CodeSection.Rows.Insert(GetSelectedRow(), "", "Invoke Browser", "", False, "")
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).ReadOnly = False
        Else
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = ""
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = "Invoke Browser"
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).ReadOnly = False
        End If
    End Sub

    Private Sub bt_create_conponent_Click(sender As Object, e As EventArgs) Handles bt_create_conponent.Click
        ' To Add Line IDs
        ADD_Line_IDS()

        SaveComponent_On_bt_Create_Compo("")
    End Sub
    Sub SaveComponent_On_bt_Create_Compo(ed_condition As String)
        savechange = 0
        DG_CodeSection.Refresh()

        da.Fill(ds)

        foldername = TV_Test_Component_List.SelectedNode.Text
        'To create file
        If (Not System.IO.Directory.Exists(path + foldername + "\Package\")) Then
            System.IO.Directory.CreateDirectory(path + foldername + "\Package\")
        End If

        Dim utf8 As New System.Text.UTF8Encoding(False)

        'Delete File if Run exist
        If System.IO.File.Exists(path + foldername + "\Package\" + foldername + ".java") Then
            System.IO.File.Delete(path + foldername + "\Package\" + foldername + ".java")
        End If


        'START : Create Component

        file = My.Computer.FileSystem.OpenTextFileWriter(path + foldername + "\Package\" + foldername + ".java", True, utf8)
        JFile_Header()

        file.WriteLine("public class " + foldername)
        file.WriteLine("{")

        file.WriteLine(vbTab + "static E_FrameWork driver;")
        file.WriteLine(vbTab + "static int ExecutionMode;" + vbNewLine)

        RunFunc()

        file.WriteLine(vbTab + "public static void main(String args[]) throws Exception")
        file.WriteLine(vbTab + "{}")
        file.WriteLine("}")

        'END : Create Component

        file.Close()

        CreateMainClass()

        'Generate Excel
        GenerateExcel(TV_Test_Component_List.SelectedNode.Text)
        UpdateExcel()


        If ed_condition = "" Then
            MsgBox("Test Component Saved : '" + TV_Test_Component_List.SelectedNode.Text + "'",, "Auto-E Test Component")
        End If


        lbl_TC_Status.Text = "Status : Not Compiled."
        lbl_TC_Last_UpdatedBy.Text = "Last Updated By : " + My.User.Name.ToString
        lbl_TC_last_Updated_Time.Text = "Last Updated Date/Time : " + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")


        'Enable Compile Button
        bt_compile_program.Enabled = True

        Me.Refresh()
    End Sub
    Sub CreateMainClass()
        Dim utf8 As New System.Text.UTF8Encoding(False)
        'if exist delete old
        If System.IO.File.Exists(path + foldername + "\E_RunMe.java") Then
            System.IO.File.Delete(path + foldername + "\E_RunMe.java")
        End If
        runme = My.Computer.FileSystem.OpenTextFileWriter(path + foldername + "\E_RunMe.java", True, utf8)

        runme.WriteLine("import java.io.*;")
        runme.WriteLine("import java.util.Properties;")
        runme.WriteLine("import E_FrameWork_PKG.*;")
        runme.WriteLine("import Package.*;" + vbNewLine)

        runme.WriteLine("public class E_RunMe")
        runme.WriteLine("{")

        runme.WriteLine(vbTab + "public static void main(String args[]) throws Exception")
        runme.WriteLine(vbTab + "{")

        runme.WriteLine(vbTab + vbTab + "int ExeutionMode,start,end,browserr;" + vbNewLine)

        runme.WriteLine(vbTab + vbTab + "//Object properties Variables ")
        runme.WriteLine(vbTab + vbTab + "Properties objpro = null;")
        runme.WriteLine(vbTab + vbTab + "FileInputStream objfile;" + vbNewLine)

        runme.WriteLine(vbTab + vbTab + "//Get Default Folder Path")
        runme.WriteLine(vbTab + vbTab + "File currentDirectory = new File(new File(""."").getAbsolutePath());")
        runme.WriteLine(vbTab + vbTab + "final String dir = currentDirectory.getCanonicalPath()+""\\"";" + vbNewLine)

        runme.WriteLine(vbTab + vbTab + "try")
        runme.WriteLine(vbTab + vbTab + "{")

        runme.WriteLine(vbTab + vbTab + vbTab + "objpro = new Properties();")
        runme.WriteLine(vbTab + vbTab + vbTab + "objfile = new FileInputStream(dir+""\\WebObject Repository\\RunMe.properties"");")
        runme.WriteLine(vbTab + vbTab + vbTab + "objpro.load(objfile); ")
        runme.WriteLine(vbTab + vbTab + vbTab + "ExeutionMode=Integer.parseInt(objpro.getProperty(""ExeutionMode""));")
        runme.WriteLine(vbTab + vbTab + vbTab + "start=Integer.parseInt(objpro.getProperty(""StartIteration""));")
        runme.WriteLine(vbTab + vbTab + vbTab + "end=Integer.parseInt(objpro.getProperty(""EndIteration""));")
        runme.WriteLine(vbTab + vbTab + vbTab + "browserr=Integer.parseInt(objpro.getProperty(""Browser""));")

        runme.WriteLine(vbTab + vbTab + "}catch(java.io.FileNotFoundException FNFE)")
        runme.WriteLine(vbTab + vbTab + "{")
        runme.WriteLine(vbTab + vbTab + vbTab + "browserr=1;")
        runme.WriteLine(vbTab + vbTab + vbTab + "ExeutionMode=0;")
        runme.WriteLine(vbTab + vbTab + vbTab + "start=1;")
        runme.WriteLine(vbTab + vbTab + vbTab + "end=1;")
        runme.WriteLine(vbTab + vbTab + "}" + vbNewLine)

        runme.WriteLine(vbTab + vbTab + "E_FrameWork driver = new E_FrameWork();" + vbNewLine)

        'Create Test Data Folder for File
        If (Not System.IO.Directory.Exists(path + foldername + "\Test Data")) Then
            System.IO.Directory.CreateDirectory(path + foldername + "\Test Data")
        End If
        runme.WriteLine(vbTab + vbTab + "driver.E_Browser_Selection(browserr);")
        runme.WriteLine(vbTab + vbTab + "driver.ETestData_File(dir+""\\Test Data\\" + foldername + ".xlsx"");")

        If (Not System.IO.Directory.Exists(path + foldername + "\Result")) Then
            System.IO.Directory.CreateDirectory(path + foldername + "\Result")
        End If
        runme.WriteLine(vbTab + vbTab + "driver.EReport_CreateHTMLReport(dir+""\\Result\\""+""" + foldername + " Component "");" + vbNewLine)

        runme.WriteLine(vbTab + vbTab + "driver.E_LoadURL(""http://www.bing.com/"");")
        runme.WriteLine(vbTab + vbTab + "BufferedReader in = new BufferedReader(new InputStreamReader(System.in));")
        runme.WriteLine(vbTab + vbTab + "System.out.println(""\n\nHit Any Key And Continue :"");")
        runme.WriteLine(vbTab + vbTab + "String Conti = in.readLine();" + vbNewLine)

        runme.WriteLine(vbTab + vbTab + "for(int i=start;i<=end;i++)")
        runme.WriteLine(vbTab + vbTab + "{")
        runme.WriteLine(vbTab + vbTab + vbTab + foldername + ".RunFunc(driver,""" + foldername + """,ExeutionMode,i);")
        runme.WriteLine(vbTab + vbTab + "}" + vbNewLine)


        runme.WriteLine(vbTab + vbTab + "//FINAL Section")
        runme.WriteLine(vbTab + vbTab + "driver.Efile_CloseALL();" + vbNewLine)

        runme.WriteLine(vbTab + vbTab + "System.out.println(""\n\nScript Execution Completed"");")

        runme.WriteLine(vbTab + "}")

        runme.WriteLine("}")
        runme.Close()
    End Sub
    Sub JFile_Header()
        file.WriteLine("package Package;")
        file.WriteLine("import java.io.*;")
        file.WriteLine("import E_FrameWork_PKG.*;" & vbNewLine)
    End Sub
    Sub RunFunc()
        'In this function ADD Data into DB
        file.WriteLine(vbTab + "public static void RunFunc(E_FrameWork e_frame_obj,String CName,int ExecutionModeGet,int TD_row)throws Exception")
        file.WriteLine(vbTab + "{")


        file.WriteLine(vbTab + vbTab + "System.out.println(""\n\n=  =  =  =  =  =  =  =  =  Started : " + foldername + "(TC-""+TD_row+"") =  =  =  =  =  =  =\n\n"");")



        file.WriteLine(vbTab + vbTab + "//Get Default Folder Path")
        file.WriteLine(vbTab + vbTab + "File currentDirectory = new File(new File(""."").getAbsolutePath());")
        file.WriteLine(vbTab + vbTab + "final String dir = currentDirectory.getCanonicalPath()+""\\"";" + vbNewLine)

        file.WriteLine(vbTab + vbTab + "//Create Object of Browser")
        file.WriteLine(vbTab + vbTab + "driver = e_frame_obj;" + vbNewLine)

        'Replace String '\' with '\\' for Java Execution.
        Dim pathh As String = path + foldername + "\"
        pathh.Replace("\", "\\")

        file.WriteLine(vbTab + vbTab + "//Initialize / Declaration Section")
        file.WriteLine(vbTab + vbTab + "driver.E_CallWebObjectsFile(dir+""\\WebObject Repository\\""+CName+"".properties"");")
        file.WriteLine(vbTab + vbTab + "driver.ETestData_FileSheetAndRow(CName,TD_row);" + vbNewLine)


        file.WriteLine(vbTab + vbTab + "int i=0;")
        file.WriteLine(vbTab + vbTab + "while(i==0)")
        file.WriteLine(vbTab + vbTab + "{")

        file.WriteLine(vbTab + vbTab + vbTab + "try")
        file.WriteLine(vbTab + vbTab + vbTab + "{")

        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "driver.EReport_CreateHTMLReport(dir+""\\Result\\""+CName+""_TC-""+TD_row);" + vbNewLine)
        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//CODING Section")

        WriteDGVinJAVA()

        file.WriteLine(vbNewLine + vbTab + vbTab + vbTab + vbTab + "i=1;")
        file.WriteLine(vbTab + vbTab + vbTab + "}")
        file.WriteLine(vbTab + vbTab + vbTab + "catch(Exception e)")
        file.WriteLine(vbTab + vbTab + vbTab + "{")
        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "ExecutionMode=ExecutionModeGet;")

        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "while(ExecutionMode==0)")
        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "{")

        file.WriteLine(vbTab + vbTab + vbTab + vbTab + vbTab + "System.out.println(""\n\n= = = = = = = CHOICE = = = = = = ="");")
        file.WriteLine(vbTab + vbTab + vbTab + vbTab + vbTab + "System.out.println(""Press 1 to re-execute this iteration."");")
        file.WriteLine(vbTab + vbTab + vbTab + vbTab + vbTab + "System.out.println(""Press 2 to move to next iteration."");")
        file.WriteLine(vbTab + vbTab + vbTab + vbTab + vbTab + "System.out.println(""\nPlease Enter Your Choice: "");")

        file.WriteLine(vbTab + vbTab + vbTab + vbTab + vbTab + "BufferedReader in = new BufferedReader(new InputStreamReader(System.in));")
        file.WriteLine(vbTab + vbTab + vbTab + vbTab + vbTab + "int choic=0;")

        file.WriteLine(vbTab + vbTab + vbTab + vbTab + vbTab + "try{")

        file.WriteLine(vbTab + vbTab + vbTab + vbTab + vbTab + vbTab + "choic = Integer.parseInt(in.readLine());")
        file.WriteLine(vbTab + vbTab + vbTab + vbTab + vbTab + "}catch(Exception ee)")
        file.WriteLine(vbTab + vbTab + vbTab + vbTab + vbTab + "{")
        file.WriteLine(vbTab + vbTab + vbTab + vbTab + vbTab + vbTab + "i=100;")
        file.WriteLine(vbTab + vbTab + vbTab + vbTab + vbTab + "}")

        file.WriteLine(vbTab + vbTab + vbTab + vbTab + vbTab + "if(choic==1)")
        file.WriteLine(vbTab + vbTab + vbTab + vbTab + vbTab + "{")
        file.WriteLine(vbTab + vbTab + vbTab + vbTab + vbTab + vbTab + "i=0;")
        file.WriteLine(vbTab + vbTab + vbTab + vbTab + vbTab + vbTab + "break;")
        file.WriteLine(vbTab + vbTab + vbTab + vbTab + vbTab + "}")


        file.WriteLine(vbTab + vbTab + vbTab + vbTab + vbTab + "else if(choic==2)")
        file.WriteLine(vbTab + vbTab + vbTab + vbTab + vbTab + "{")
        file.WriteLine(vbTab + vbTab + vbTab + vbTab + vbTab + vbTab + "i=1;")
        file.WriteLine(vbTab + vbTab + vbTab + vbTab + vbTab + vbTab + "break;")
        file.WriteLine(vbTab + vbTab + vbTab + vbTab + vbTab + "}")

        file.WriteLine(vbTab + vbTab + vbTab + vbTab + vbTab + "else")
        file.WriteLine(vbTab + vbTab + vbTab + vbTab + vbTab + "{")
        file.WriteLine(vbTab + vbTab + vbTab + vbTab + vbTab + vbTab + "System.out.println(""\nPlease Enter Correct Choice..."");")
        file.WriteLine(vbTab + vbTab + vbTab + vbTab + vbTab + vbTab + "System.out.println(""\n= = = = = = = = = = = = = = = = ="");")
        file.WriteLine(vbTab + vbTab + vbTab + vbTab + vbTab + vbTab + "ExecutionMode=0;")
        file.WriteLine(vbTab + vbTab + vbTab + vbTab + vbTab + "}")

        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "}")

        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "if(ExecutionMode==1)")
        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "{")
        file.WriteLine(vbTab + vbTab + vbTab + vbTab + vbTab + "i=1;")
        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "}")

        file.WriteLine(vbTab + vbTab + vbTab + "}")

        file.WriteLine(vbTab + vbTab + "}")
        file.WriteLine(vbTab + vbTab + "System.out.println(""\n\n=  =  =  =  =  =  =  =  =  Finished : " + foldername + "(TC-""+TD_row+"") =  =  =  =  =  =  =\n\n"");")
        file.WriteLine(vbTab + "}")
    End Sub

    Sub check_dis_enable_lines()
        For i = 0 To GetActiveRow() - 2
            If DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Invoke Browser" Then

                DG_CodeSection.Rows(i).Cells(0).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(1).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(2).ReadOnly = False

            ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Wait For Page Load" Then

                DG_CodeSection.Rows(i).Cells(0).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(1).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(2).ReadOnly = True

            ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Wait Until Element Display" Then

                DG_CodeSection.Rows(i).Cells(0).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(1).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(2).ReadOnly = True

            ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Click" Then

                DG_CodeSection.Rows(i).Cells(0).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(1).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(2).ReadOnly = True

            ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Write" Then

                DG_CodeSection.Rows(i).Cells(0).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(1).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(2).ReadOnly = False

            ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Select From Drop-Down/ListBox" Then

                DG_CodeSection.Rows(i).Cells(0).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(1).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(2).ReadOnly = False

            ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Is Element Exist" Then

                DG_CodeSection.Rows(i).Cells(0).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(1).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(2).ReadOnly = False

            ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Is Element Display" Then

                DG_CodeSection.Rows(i).Cells(0).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(1).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(2).ReadOnly = False

            ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Run Time Change WebObject Property" Then

                DG_CodeSection.Rows(i).Cells(0).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(1).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(2).ReadOnly = False

            ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "ScreenShot" Then

                DG_CodeSection.Rows(i).Cells(0).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(1).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(2).ReadOnly = False

            ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "My Wait (Enter in Seconds)" Then

                DG_CodeSection.Rows(i).Cells(0).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(1).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(2).ReadOnly = False

            ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Get URL" Then

                DG_CodeSection.Rows(i).Cells(0).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(1).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(2).ReadOnly = False

            ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Browser : Back" Then

                DG_CodeSection.Rows(i).Cells(0).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(1).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(2).ReadOnly = True

            ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Browser : Refresh" Then

                DG_CodeSection.Rows(i).Cells(0).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(1).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(2).ReadOnly = True

            ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Browser : Forward" Then

                DG_CodeSection.Rows(i).Cells(0).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(1).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(2).ReadOnly = True

            ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Alert - Accept" Then

                DG_CodeSection.Rows(i).Cells(0).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(1).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(2).ReadOnly = True

            ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Alert - Dismiss" Then

                DG_CodeSection.Rows(i).Cells(0).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(1).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(2).ReadOnly = True

            ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Switch to Frame" Then

                DG_CodeSection.Rows(i).Cells(0).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(1).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(2).ReadOnly = False

            ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Switch Back to Main Frame" Then

                DG_CodeSection.Rows(i).Cells(0).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(1).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(2).ReadOnly = True

            ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "IF" Then

                DG_CodeSection.Rows(i).Cells(0).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(1).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(2).ReadOnly = False

            ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "End IF" Then

                DG_CodeSection.Rows(i).Cells(0).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(1).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(2).ReadOnly = True

            ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Else" Then

                DG_CodeSection.Rows(i).Cells(0).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(1).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(2).ReadOnly = True

            ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Do.." Then

                DG_CodeSection.Rows(i).Cells(0).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(1).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(2).ReadOnly = True

            ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "While" Then

                DG_CodeSection.Rows(i).Cells(0).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(1).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(2).ReadOnly = False

            ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "While.." Then

                DG_CodeSection.Rows(i).Cells(0).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(1).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(2).ReadOnly = False

            ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "End..While" Then

                DG_CodeSection.Rows(i).Cells(0).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(1).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(2).ReadOnly = True

            ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Exit Loop" Then

                DG_CodeSection.Rows(i).Cells(0).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(1).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(2).ReadOnly = True

            ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "- - - - - - -     Code-Separator     - - - - - - -" Then

                DG_CodeSection.Rows(i).Cells(0).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(1).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(2).ReadOnly = True

            ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Capture Attribute - InnerText" Then
                DG_CodeSection.Rows(i).Cells(0).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(1).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(2).ReadOnly = False
            ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Capture Attribute - Value" Then
                DG_CodeSection.Rows(i).Cells(0).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(1).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(2).ReadOnly = False
            ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Capture Attribute - ID" Then
                DG_CodeSection.Rows(i).Cells(0).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(1).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(2).ReadOnly = False
            ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Capture Attribute - Type" Then
                DG_CodeSection.Rows(i).Cells(0).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(1).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(2).ReadOnly = False
            ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Switch to tab 2" Then
                DG_CodeSection.Rows(i).Cells(0).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(1).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(2).ReadOnly = True
            ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Switch to main tab" Then
                DG_CodeSection.Rows(i).Cells(0).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(1).ReadOnly = True
                DG_CodeSection.Rows(i).Cells(2).ReadOnly = True
            Else
                Exit For
            End If
        Next
    End Sub
    Sub ADD_Line_IDS()
        ' To Add Line IDs
        For i = 0 To GetActiveRow() - 2
            If Convert.ToString(DG_CodeSection.Rows(i).Cells(1).Value) <> "IF" And Convert.ToString(DG_CodeSection.Rows(i).Cells(1).Value) <> "End IF" And Convert.ToString(DG_CodeSection.Rows(i).Cells(1).Value) <> "Else" Then
                DG_CodeSection.Rows(i).Cells(5).Value = "ID_" + i.ToString
            End If
        Next
    End Sub
    Function IF_ConditionCount(Name As String)
        'To count if conditions
        Dim count_ifcondition As Integer = 0

        If Name = "IF" Then
            For i = 0 To GetActiveRow() - 2
                If Convert.ToString(DG_CodeSection.Rows(i).Cells(1).Value) = "IF" Then
                    count_ifcondition = count_ifcondition + 1
                End If
            Next
        ElseIf Name = "End IF" Then
            For i = 0 To GetActiveRow() - 2
                If Convert.ToString(DG_CodeSection.Rows(i).Cells(1).Value) = "End IF" Then
                    count_ifcondition = count_ifcondition + 1
                End If
            Next
        End If



        Return count_ifcondition
    End Function
    Sub WriteDGVinJAVA()
        'START : Empty_Table
        Delete_TableData_from_table(TV_Test_Component_List.SelectedNode.Text)
        'END :  Empty_Table


        For i = 0 To GetActiveRow() - 2

            If Convert.ToString(DG_CodeSection.Rows(i).Cells(0).Value) <> "" Or Convert.ToString(DG_CodeSection.Rows(i).Cells(1).Value) <> "" Then
                'MsgBox("Query")
                'MsgBox("Insert into " + TV_Test_Component_List.SelectedNode.Text + " (Object_Name,Action,Test_Data,Comment_Line,Dev_Note,Last_Updated_UserName,Last_Updated_TimeDate,Status,RowIds) values('" + Convert.ToString(DG_CodeSection.Rows(i).Cells(0).Value) + "','" + Convert.ToString(DG_CodeSection.Rows(i).Cells(1).Value) + "','" + Convert.ToString(DG_CodeSection.Rows(i).Cells(2).Value) + "','" + Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) + "','" + Convert.ToString(DG_CodeSection.Rows(i).Cells(4).Value) + "','" + My.User.Name.ToString + "','" + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + "','" + "Not Compiled" + "','" + Convert.ToString(DG_CodeSection.Rows(i).Cells(5).Value) + "')")
                'START: ADD DATA INTO TABLE
                Dim Update_TC_Table As String
                Update_TC_Table = "Insert into " + TV_Test_Component_List.SelectedNode.Text + " (Object_Name,Action,Test_Data,Comment_Line,Dev_Note,Last_Updated_UserName,Last_Updated_TimeDate,Status,RowIds) values('" + Convert.ToString(DG_CodeSection.Rows(i).Cells(0).Value) + "','" + Convert.ToString(DG_CodeSection.Rows(i).Cells(1).Value) + "','" + Convert.ToString(DG_CodeSection.Rows(i).Cells(2).Value) + "','" + Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) + "','" + Convert.ToString(DG_CodeSection.Rows(i).Cells(4).Value) + "','" + My.User.Name.ToString + "','" + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + "','" + "Not Compiled" + "','" + Convert.ToString(DG_CodeSection.Rows(i).Cells(5).Value) + "')"
                'MsgBox(Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value))
                Dim Execute_Cmd As New SqlCommand(Update_TC_Table, cn)
                cn.Open()
                Execute_Cmd.ExecuteNonQuery()
                cn.Close()
                'END: ADD DATA INTO TABLE




                'MsgBox(DG_CodeSection.Rows(i).Cells(1).Value.ToString)
                If DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Invoke Browser" Then
                    'INVOKE BROWSER
                    If Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) = "True" Then
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//driver.E_LoadURL(""" + Convert.ToString(DG_CodeSection.Rows(i).Cells(2).Value) + """);")
                    Else
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "driver.E_LoadURL(""" + Convert.ToString(DG_CodeSection.Rows(i).Cells(2).Value) + """);")
                    End If
                ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Wait For Page Load" Then
                    'WAIT FOR PAGE LOAD
                    If Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) = "True" Then
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//driver.E_WaitForPageLoad();")
                    Else
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "driver.E_WaitForPageLoad();")
                    End If

                ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Wait Until Element Display" Then
                    'WAIT UNTIL ELEMENT DISPLAY
                    If Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) = "True" Then
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//driver.E_WaitUntilElementDisplay(""" + DG_CodeSection.Rows(i).Cells(0).Value.ToString + """);")
                    Else
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "driver.E_WaitUntilElementDisplay(""" + DG_CodeSection.Rows(i).Cells(0).Value.ToString + """);")
                    End If

                ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Click" Then
                    'CLICK
                    If Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) = "True" Then
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//driver.E_Click(""" + DG_CodeSection.Rows(i).Cells(0).Value.ToString + """);")
                    Else
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "driver.E_Click(""" + DG_CodeSection.Rows(i).Cells(0).Value.ToString + """);")
                    End If

                ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Write" Then
                    'WRITE
                    If Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) = "True" Then
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//driver.E_Write(""" + DG_CodeSection.Rows(i).Cells(0).Value.ToString + """,""" + DG_CodeSection.Rows(i).Cells(2).Value.ToString + """);")
                    Else
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "driver.E_Write(""" + DG_CodeSection.Rows(i).Cells(0).Value.ToString + """,""" + DG_CodeSection.Rows(i).Cells(2).Value.ToString + """);")
                    End If
                ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Select From Drop-Down/ListBox" Then
                    'SELECT
                    If Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) = "True" Then
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//driver.E_Select(""" + DG_CodeSection.Rows(i).Cells(0).Value.ToString + """,""" + DG_CodeSection.Rows(i).Cells(2).Value.ToString + """);")
                    Else
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "driver.E_Select(""" + DG_CodeSection.Rows(i).Cells(0).Value.ToString + """,""" + DG_CodeSection.Rows(i).Cells(2).Value.ToString + """);")
                    End If
                ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Is Element Exist" Then
                    'Is Element Exist
                    If Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) = "True" Then
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//driver.E_IsElementExist(""" + Convert.ToString(DG_CodeSection.Rows(i).Cells(0).Value.ToString) + """,""" + Convert.ToString(DG_CodeSection.Rows(i).Cells(2).Value.ToString) + """);")
                    Else
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "driver.E_IsElementExist(""" + Convert.ToString(DG_CodeSection.Rows(i).Cells(0).Value.ToString) + """,""" + Convert.ToString(DG_CodeSection.Rows(i).Cells(2).Value.ToString) + """);")
                    End If


                    ''If Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) = "True" Then
                    ''    file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//driver.E_IsElementExist(""" + DG_CodeSection.Rows(i).Cells(0).Value.ToString + """);")
                    ''Else
                    ''    If Convert.ToString(DG_CodeSection.Rows(i).Cells(2).Value) <> "" Then
                    ''        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "driver.ETestData_SetData(""" + DG_CodeSection.Rows(i).Cells(2).Value.ToString + """,driver.E_IsElementExist(""" + DG_CodeSection.Rows(i).Cells(0).Value.ToString + """)+"""");")
                    ''    Else
                    ''        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "driver.E_IsElementExist(""" + DG_CodeSection.Rows(i).Cells(0).Value.ToString + """);")
                    ''    End If
                    ''End If
                ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Is Element Display" Then
                    'Is Element Display

                    If Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) = "True" Then
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//driver.E_IsElementDisplayed(""" + Convert.ToString(DG_CodeSection.Rows(i).Cells(0).Value.ToString) + """,""" + Convert.ToString(DG_CodeSection.Rows(i).Cells(2).Value.ToString) + """);")
                    Else
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "driver.E_IsElementDisplayed(""" + Convert.ToString(DG_CodeSection.Rows(i).Cells(0).Value.ToString) + """,""" + Convert.ToString(DG_CodeSection.Rows(i).Cells(2).Value.ToString) + """);")
                    End If

                    'Update Is Element Display
                    ''If Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) = "True" Then
                    ''    file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//driver.ETestData_SetData(""" + DG_CodeSection.Rows(i).Cells(2).Value.ToString + """,driver.E_IsElementDisplayed(""" + DG_CodeSection.Rows(i).Cells(0).Value.ToString + """)+"""");")
                    ''Else
                    ''    If Convert.ToString(DG_CodeSection.Rows(i).Cells(2).Value) <> "" Then
                    ''        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "driver.ETestData_SetData(""" + DG_CodeSection.Rows(i).Cells(2).Value.ToString + """,driver.E_IsElementDisplayed(""" + DG_CodeSection.Rows(i).Cells(0).Value.ToString + """)+"""");")
                    ''    Else
                    ''        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "driver.E_IsElementDisplayed(""" + Convert.ToString(DG_CodeSection.Rows(i).Cells(0).Value.ToString) + """);")
                    ''    End If
                    ''End If


                ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Run Time Change WebObject Property" Then
                    'RunTime Change Web-Object Property
                    If Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) = "True" Then
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//driver.E_RunTimeChangeWebObjectValue(""" + DG_CodeSection.Rows(i).Cells(0).Value.ToString + """,""" + DG_CodeSection.Rows(i).Cells(2).Value.ToString + """);")
                    Else
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "driver.E_RunTimeChangeWebObjectValue(""" + Convert.ToString(DG_CodeSection.Rows(i).Cells(0).Value) + """,""" + Convert.ToString(DG_CodeSection.Rows(i).Cells(2).Value) + """);")
                    End If
                ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "ScreenShot" Then
                    'ScreenShot
                    If Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) = "True" Then
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//driver.E_TakeScreenShot(dir+""\\ScreehShots"",""" + DG_CodeSection.Rows(i).Cells(2).Value.ToString + """);")
                    Else
                        If Convert.ToString(DG_CodeSection.Rows(i).Cells(2).Value) = "" Then
                            'NOT_COMPLETE
                            file.WriteLine(vbTab + vbTab + vbTab + vbTab + "driver.E_TakeScreenShot(dir+""\\ScreenShots"",""" + Convert.ToString(DG_CodeSection.Rows(i).Cells(2).Value) + "1234"");")
                        Else
                            file.WriteLine(vbTab + vbTab + vbTab + vbTab + "driver.E_TakeScreenShot(dir+""\\ScreenShots"",""" + Convert.ToString(DG_CodeSection.Rows(i).Cells(2).Value) + """);")
                        End If
                    End If
                ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "My Wait (Enter in Seconds)" Then
                    'My Wait (Enter in Seconds)
                    If Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) = "True" Then
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//driver.E_MyWait(" + Convert.ToString(DG_CodeSection.Rows(i).Cells(2).Value) + ");")
                    Else
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "driver.E_MyWait(" + Convert.ToString(DG_CodeSection.Rows(i).Cells(2).Value) + ");")
                    End If
                ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Get URL" Then
                    'Get URL
                    If Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) = "True" Then
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//driver.E_Browser_GetURL(""" + Convert.ToString(DG_CodeSection.Rows(i).Cells(2).Value) + """);")
                    Else
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "driver.E_Browser_GetURL(""" + Convert.ToString(DG_CodeSection.Rows(i).Cells(2).Value) + """);")
                    End If

                ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Browser : Back" Then
                    'Browser : Back
                    If Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) = "True" Then
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//driver.E_Browser_Back();")
                    Else
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "driver.E_Browser_Back();")
                    End If
                ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Browser : Refresh" Then
                    'Browser : Refresh
                    If Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) = "True" Then
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//driver.E_Browser_refresh();")
                    Else
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "driver.E_Browser_refresh();")
                    End If
                ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Browser : Forward" Then
                    'Browser : Forward
                    If Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) = "True" Then
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//driver.E_Browser_forward();")
                    Else
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "driver.E_Browser_forward();")
                    End If
                ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Alert - Accept" Then
                    'Browser : Accept Alert
                    If Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) = "True" Then
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//driver.E_Alert_Accept();")
                    Else
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "driver.E_Alert_Accept();")
                    End If
                ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Alert - Dismiss" Then
                    'Browser : Alert - Dismiss
                    If Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) = "True" Then
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//driver.E_Alert_dismiss();")
                    Else
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "driver.E_Alert_dismiss();")
                    End If
                ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Switch to Frame" Then
                    'Browser : Switch to Frame
                    If Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) = "True" Then
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//driver.E_Switch2Frame(""" + Convert.ToString(DG_CodeSection.Rows(i).Cells(2).Value) + """);")
                    Else
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "driver.E_Switch2Frame(""" + Convert.ToString(DG_CodeSection.Rows(i).Cells(2).Value) + """);")
                    End If
                ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Switch Back to Main Frame" Then
                    'Browser : Switch Back to Main Frame
                    If Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) = "True" Then
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//driver.E_Switch_Back2Main_Frame();")
                    Else

                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "driver.E_Switch_Back2Main_Frame();")
                    End If
                ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "IF" Then
                    'Browser : IF..End IF
                    If Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) = "True" Then
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//if(" + Convert.ToString(DG_CodeSection.Rows(i).Cells(2).Value) + ")")
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//{")
                    Else
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "if(" + Convert.ToString(DG_CodeSection.Rows(i).Cells(2).Value) + ")")
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "{")
                    End If
                    'IFConditionCount
                    'Add run time unique id to if condition


                ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "End IF" Then
                    'Browser : IF..End IF
                    If Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) = "True" Then
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//}")
                    Else
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "}" + vbNewLine)
                    End If
                ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Else" Then
                    'Browser : IF..End IF
                    If Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) = "True" Then
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//}")
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//else")
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//{")
                    Else
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "}")
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "else")
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "{")
                    End If
                ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Do.." Then
                    'Browser : Do..While
                    If Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) = "True" Then
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//do")
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//{" + vbNewLine)
                    Else
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "do")
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "{" + vbNewLine)
                    End If
                ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "While" Then
                    'Browser : Do..While
                    If Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) = "True" Then
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//}while(""" + Convert.ToString(DG_CodeSection.Rows(i).Cells(2).Value) + """);" + vbNewLine)

                    Else
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "}while(""" + Convert.ToString(DG_CodeSection.Rows(i).Cells(2).Value) + """);" + vbNewLine)
                    End If
                ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "While.." Then
                    'Browser : Do..While
                    If Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) = "True" Then
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//while(""" + Convert.ToString(DG_CodeSection.Rows(i).Cells(2).Value) + """)")
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//{")

                    Else
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "while(""" + Convert.ToString(DG_CodeSection.Rows(i).Cells(2).Value) + """)")
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "{")
                    End If
                ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "End..While" Then
                    'Browser : Do..While
                    If Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) = "True" Then
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//}")
                    Else
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "}")
                    End If
                ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Exit Loop" Then
                    'Browser : Do..While
                    If Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) = "True" Then
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//break;")
                    Else
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "break;")
                    End If
                ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "- - - - - - -     Code-Separator     - - - - - - -" Then
                    'Browser : Do..While
                    If Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) = "True" Then
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "" + vbNewLine)
                    Else
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "" + vbNewLine)
                    End If
                ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Capture Attribute - InnerText" Then
                    'Capture Attribute - InnerText
                    If Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) = "True" Then
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//driver.E_CaptureProperty(""" + DG_CodeSection.Rows(i).Cells(0).Value.ToString + """,""innertext"",""" + DG_CodeSection.Rows(i).Cells(2).Value.ToString + """);")
                    Else
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "driver.E_CaptureProperty(""" + DG_CodeSection.Rows(i).Cells(0).Value.ToString + """,""innertext"",""" + DG_CodeSection.Rows(i).Cells(2).Value.ToString + """);")
                    End If
                ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Capture Attribute - Value" Then
                    'Capture Attribute - value
                    If Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) = "True" Then
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//driver.E_CaptureProperty(""" + DG_CodeSection.Rows(i).Cells(0).Value.ToString + """,""value"",""" + DG_CodeSection.Rows(i).Cells(2).Value.ToString + """);")
                    Else
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "driver.E_CaptureProperty(""" + DG_CodeSection.Rows(i).Cells(0).Value.ToString + """,""value"",""" + DG_CodeSection.Rows(i).Cells(2).Value.ToString + """);")
                    End If
                ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Capture Attribute - ID" Then
                    'Capture Attribute - id
                    If Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) = "True" Then
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//driver.E_CaptureProperty(""" + DG_CodeSection.Rows(i).Cells(0).Value.ToString + """,""id"",""" + DG_CodeSection.Rows(i).Cells(2).Value.ToString + """);")
                    Else
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "driver.E_CaptureProperty(""" + DG_CodeSection.Rows(i).Cells(0).Value.ToString + """,""id"",""" + DG_CodeSection.Rows(i).Cells(2).Value.ToString + """);")
                    End If
                ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Capture Attribute - Type" Then
                    'Capture Attribute - type
                    If Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) = "True" Then
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//driver.E_CaptureProperty(""" + DG_CodeSection.Rows(i).Cells(0).Value.ToString + """,""type"",""" + DG_CodeSection.Rows(i).Cells(2).Value.ToString + """);")
                    Else
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "driver.E_CaptureProperty(""" + DG_CodeSection.Rows(i).Cells(0).Value.ToString + """,""type"",""" + DG_CodeSection.Rows(i).Cells(2).Value.ToString + """);")
                    End If
                ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Switch to tab 2" Then
                    'Browser : Switch to tab 2
                    If Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) = "True" Then
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//driver.E_Switch2tab2();")
                    Else
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "driver.E_Switch2tab2();")
                    End If
                    '
                ElseIf DG_CodeSection.Rows(i).Cells(1).Value.ToString = "Switch to main tab" Then
                    'Browser : Switch to main tab
                    If Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value) = "True" Then
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "//driver.E_Switch_back2maintab();")
                    Else
                        file.WriteLine(vbTab + vbTab + vbTab + vbTab + "driver.E_Switch_back2maintab();")
                    End If
                Else
                    Exit For
                End If
            End If
        Next
    End Sub
    Private Sub bt_compile_program_Click(sender As Object, e As EventArgs) Handles bt_compile_program.Click
        compilation_button()

    End Sub
    Sub compilation_button()
        'foldername = txt_component_name.Text
        path = GetProject_FolderPath()
        foldername = TV_Test_Component_List.SelectedNode.Text
        Dim filename As String = path + foldername + "\Compile.bat"
        Dim filenameRun As String = path + foldername + "\Run.bat"


        Dim utf8 As New System.Text.UTF8Encoding(False)

        'Delete File if Compile exist
        If System.IO.File.Exists(filename) Then

            System.IO.File.Delete(filename)

        End If

        'START : Update Test_Component Status
        Dim Update_TC_Table As String
        Update_TC_Table = "update " + TV_Test_Component_List.SelectedNode.Text + " set Status='Ready to Execute.'"
        Dim Execute_Cmd As New SqlCommand(Update_TC_Table, cn)
        cn.Open()
        Execute_Cmd.ExecuteNonQuery()
        cn.Close()
        lbl_TC_Status.Text = "Status : Ready to Execute."

        'END : Update Test_Component Status


        Using sw As System.IO.StreamWriter = New System.IO.StreamWriter(filename, True, utf8)
            sw.WriteLine("@ECHO OFF")
            'sw.WriteLine("set CLASSPATH=%CLASSPATH%;")
            sw.WriteLine("pushd " + GetProject_FolderPath() + "\" + foldername)
            sw.WriteLine("chdir /d " + GetProject_FolderPath() + "\" + foldername)
            sw.WriteLine("cls")
            sw.WriteLine("javac Package/" + foldername + ".java")
            sw.WriteLine("javac E_RunMe.java")
            sw.WriteLine("popd")
            sw.WriteLine("echo Test_Component '" + foldername + "' Compiled.")
            sw.Write("pause")

            sw.Close()

            Dim proc As Process = Nothing
            proc = New Process()
            proc.StartInfo.WorkingDirectory = path + foldername
            proc.StartInfo.FileName = "Compile.bat"
            proc.StartInfo.CreateNoWindow = False
            proc.Start()
            proc.WaitForExit()

            'Process.Start(filename)
        End Using


        'Delete File if Run exist
        If System.IO.File.Exists(filenameRun) Then

            System.IO.File.Delete(filenameRun)

        End If


        Using sw As System.IO.StreamWriter = New System.IO.StreamWriter(filenameRun, True, utf8)
            sw.WriteLine("@ECHO OFF")
            sw.WriteLine("pushd " + GetProject_FolderPath() + "\" + foldername)
            sw.WriteLine("chdir /d " + GetProject_FolderPath() + "\" + foldername)
            sw.WriteLine("cls")
            'sw.WriteLine("set CLASSPATH=%CLASSPATH%;")
            sw.WriteLine("java E_RunMe")
            sw.WriteLine("popd")
            sw.Write("pause")
            sw.Close()
        End Using

        'Enable Excel and Run button
        bt_excel.Enabled = True
        bt_run_program.Enabled = True
    End Sub
    Private Sub bt_run_program_Click(sender As Object, e As EventArgs) Handles bt_run_program.Click

        GetAuto_Script_From_S_TO_D()
        'foldername = txt_component_name.Text
        '''Dim filenameRun As String = path + foldername + "\Run.bat"
        '''Dim proc As Process = Nothing
        '''proc = New Process()
        '''proc.StartInfo.WorkingDirectory = path + foldername
        '''proc.StartInfo.FileName = "Run.bat"
        '''proc.StartInfo.CreateNoWindow = False
        '''proc.Start()
        '''proc.WaitForExit()
    End Sub
    Sub Just_Copy_From_Server_To_Local()
        Dim strMasterResourceDirectory As String
        Dim strDirectory As String

        strDirectory = "C:\E_FrameWork\Test Componentz\" + TV_Test_Component_List.SelectedNode.Text
        strMasterResourceDirectory = path + TV_Test_Component_List.SelectedNode.Text

        If My.Computer.FileSystem.DirectoryExists(strDirectory) = False Then
            My.Computer.FileSystem.CreateDirectory(strDirectory)
        End If

        My.Computer.FileSystem.CopyDirectory(strMasterResourceDirectory, strDirectory, True)




        Dim filename As String = strDirectory + "\Compile.bat"
        Dim filenameRun As String = strDirectory + "\Run.bat"

        Dim utf8 As New System.Text.UTF8Encoding(False)

        'Delete File if Compile exist
        If System.IO.File.Exists(filename) Then

            System.IO.File.Delete(filename)

        End If



        Using sw As System.IO.StreamWriter = New System.IO.StreamWriter(filename, True, utf8)
            sw.WriteLine("@ECHO OFF")
            'sw.WriteLine("set CLASSPATH=%CLASSPATH%;")
            sw.WriteLine("javac Package/" + TV_Test_Component_List.SelectedNode.Text + ".java")
            sw.WriteLine("javac E_RunMe.java")
            sw.WriteLine("echo Compiled..!")
            sw.Write("pause")

            sw.Close()



            'Process.Start(filename)
        End Using


        'Delete File if Run exist
        If System.IO.File.Exists(filenameRun) Then

            System.IO.File.Delete(filenameRun)

        End If


        Using sw As System.IO.StreamWriter = New System.IO.StreamWriter(filenameRun, True, utf8)
            sw.WriteLine("@ECHO OFF")
            'sw.WriteLine("set CLASSPATH=%CLASSPATH%;")
            sw.WriteLine("java E_RunMe")
            sw.Write("pause")
            sw.Close()


        End Using

        Process.Start("C:\E_FrameWork\Test Componentz\" + TV_Test_Component_List.SelectedNode.Text)
    End Sub
    Sub GetAuto_Script_From_S_TO_D()
        Dim strMasterResourceDirectory As String
        Dim strDirectory As String

        strDirectory = "C:\E_FrameWork\Test Componentz\" + TV_Test_Component_List.SelectedNode.Text
        strMasterResourceDirectory = path + TV_Test_Component_List.SelectedNode.Text

        If My.Computer.FileSystem.DirectoryExists(strDirectory) = False Then
            My.Computer.FileSystem.CreateDirectory(strDirectory)
        End If

        My.Computer.FileSystem.CopyDirectory(strMasterResourceDirectory, strDirectory, True)




        Dim filename As String = strDirectory + "\Compile.bat"
        Dim filenameRun As String = strDirectory + "\Run.bat"

        Dim utf8 As New System.Text.UTF8Encoding(False)

        'Delete File if Compile exist
        If System.IO.File.Exists(filename) Then

            System.IO.File.Delete(filename)

        End If



        Using sw As System.IO.StreamWriter = New System.IO.StreamWriter(filename, True, utf8)
            sw.WriteLine("@ECHO OFF")
            'sw.WriteLine("set CLASSPATH=%CLASSPATH%;")
            sw.WriteLine("javac Package/" + TV_Test_Component_List.SelectedNode.Text + ".java")
            sw.WriteLine("javac E_RunMe.java")
            sw.WriteLine("echo Compiled..!")
            sw.Write("pause")

            sw.Close()



            'Process.Start(filename)
        End Using


        'Delete File if Run exist
        If System.IO.File.Exists(filenameRun) Then

            System.IO.File.Delete(filenameRun)

        End If


        Using sw As System.IO.StreamWriter = New System.IO.StreamWriter(filenameRun, True, utf8)
            sw.WriteLine("@ECHO OFF")
            'sw.WriteLine("set CLASSPATH=%CLASSPATH%;")
            sw.WriteLine("java E_RunMe")
            sw.Write("pause")
            sw.Close()


        End Using

        Dim proc As Process = Nothing
        proc = New Process()
        proc.StartInfo.WorkingDirectory = strDirectory
        proc.StartInfo.FileName = "Run.bat"
        proc.StartInfo.CreateNoWindow = False
        proc.Start()
        proc.WaitForExit()
    End Sub
    Private Sub WaitForPageLoadToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles WaitForPageLoadToolStripMenuItem.Click
        If DG_CodeSection.SelectedRows.Count = 1 Then
            DG_CodeSection.Rows.Insert(GetSelectedRow(), "", "Wait For Page Load", "", False, "")
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).ReadOnly = True
        Else
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = ""
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = "Wait For Page Load"
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).ReadOnly = True
        End If
    End Sub

    Private Sub DG_CodeSection_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DG_CodeSection.CellClick
        If e.RowIndex >= 0 Then
            DG_CodeSection.Rows(e.RowIndex).Selected = True
        End If

    End Sub

    Private Sub bt_delete_row_Click(sender As Object, e As EventArgs) Handles bt_delete_row.Click
        If DG_CodeSection.Rows.Count > 1 Then
            'If Convert.ToString(DG_CodeSection.Rows(GetSelectedRow()).Cells(0).Value) <> "" Or Convert.ToString(DG_CodeSection.Rows(GetSelectedRow()).Cells(1).Value) <> "" Then

            Dim selected_Rows_id As String = Convert.ToString(DG_CodeSection.Rows(GetSelectedRow()).Cells(5).Value)
            Try
                'Remove whole if..end_if condition
                If Convert.ToString(DG_CodeSection.Rows(GetSelectedRow()).Cells(1).Value) = "IF" Then
                    'Get IF Condition ID
                    Dim store_ID As String = Convert.ToString(DG_CodeSection.Rows(GetSelectedRow()).Cells(5).Value)

                    Dim tot_rows_count As Integer = GetActiveRow() - 2

                    For i = 0 To tot_rows_count
                        'Loop will get total number of lines and start deleting assigned lines, total lines will reduce but loop count will not update, that's why if loop cross available lines then loop will exit.
                        If i > tot_rows_count Then
                            Exit For
                        End If
                        If Convert.ToString(DG_CodeSection.Rows(i).Cells(5).Value) = store_ID Then
                            DG_CodeSection.Rows.RemoveAt(i)
                            DG_CodeSection.Rows(GetSelectedRow()).Selected = True
                            tot_rows_count = GetActiveRow() - 2
                            i = i - 1
                        End If
                    Next


                    'Delete Data from Sql
                    Dim Delete_query As String = "Delete from If_Conditions where TestComponent_Name='" + TV_Test_Component_List.SelectedNode.Text + "' AND RowIds='" + selected_Rows_id + "'"
                    Dim Execute_Cmd As New SqlCommand(Delete_query, cn)
                    cn.Open()
                    Execute_Cmd.ExecuteNonQuery()
                    cn.Close()

                ElseIf Convert.ToString(DG_CodeSection.Rows(GetSelectedRow()).Cells(1).Value) = "Else" Then
                    'Get IF Condition ID
                    Dim store_ID As String = Convert.ToString(DG_CodeSection.Rows(GetSelectedRow()).Cells(5).Value)

                    Dim tot_rows_count As Integer = GetActiveRow() - 2

                    For i = 0 To tot_rows_count
                        'Loop will get total number of lines and start deleting assigned lines, total lines will reduce but loop count will not update, that's why if loop cross available lines then loop will exit.
                        If i > tot_rows_count Then
                            Exit For
                        End If
                        If Convert.ToString(DG_CodeSection.Rows(i).Cells(5).Value) = store_ID Then
                            DG_CodeSection.Rows.RemoveAt(i)
                            DG_CodeSection.Rows(GetSelectedRow()).Selected = True
                            tot_rows_count = GetActiveRow() - 2
                            i = i - 1
                        End If
                    Next

                    'Delete Data from Sql
                    Dim Delete_query As String = "Delete from If_Conditions where TestComponent_Name='" + TV_Test_Component_List.SelectedNode.Text + "' AND RowIds='" + selected_Rows_id + "'"
                    Dim Execute_Cmd As New SqlCommand(Delete_query, cn)
                    cn.Open()
                    Execute_Cmd.ExecuteNonQuery()
                    cn.Close()
                ElseIf Convert.ToString(DG_CodeSection.Rows(GetSelectedRow()).Cells(1).Value) = "End IF" Then
                    'Get IF Condition ID
                    Dim store_ID As String = Convert.ToString(DG_CodeSection.Rows(GetSelectedRow()).Cells(5).Value)

                    Dim tot_rows_count As Integer = GetActiveRow() - 2

                    For i = 0 To tot_rows_count
                        'Loop will get total number of lines and start deleting assigned lines, total lines will reduce but loop count will not update, that's why if loop cross available lines then loop will exit.
                        If i > tot_rows_count Then
                            Exit For
                        End If
                        If Convert.ToString(DG_CodeSection.Rows(i).Cells(5).Value) = store_ID Then
                            DG_CodeSection.Rows.RemoveAt(i)
                            DG_CodeSection.Rows(GetSelectedRow()).Selected = True
                            tot_rows_count = GetActiveRow() - 2
                            i = i - 1
                        End If
                    Next

                    'Delete Data from Sql
                    Dim Delete_query As String = "Delete from If_Conditions where TestComponent_Name='" + TV_Test_Component_List.SelectedNode.Text + "' AND RowIds='" + selected_Rows_id + "'"
                    Dim Execute_Cmd As New SqlCommand(Delete_query, cn)
                    cn.Open()
                    Execute_Cmd.ExecuteNonQuery()
                    cn.Close()
                Else
                    DG_CodeSection.Rows.RemoveAt(GetSelectedRow())
                    DG_CodeSection.Rows(GetSelectedRow()).Selected = True
                End If

                SaveComponent_On_bt_Create_Compo("No")
                MsgBox("Row / Rows(related) deleted.",, "Delete")

            Catch ex As System.InvalidOperationException
                MsgBox("Selected Row Might Be Null.",, "Exception...Hhhmmmm")
            End Try

            'End If

        End If
    End Sub
    Private Sub DG_CodeSection_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles DG_CodeSection.CellDoubleClick
        If e.RowIndex >= 0 Then
            DG_CodeSection.Rows(e.RowIndex).Selected = True
        End If

        'IF_FORM
        'MsgBox(DG_CodeSection.Rows(GetSelectedRow()).Cells(1).ToString)
        If DG_CodeSection.SelectedRows.Count = 1 Then
            If DG_CodeSection.Rows(GetSelectedRow()).Cells(1).Value = "IF" Then
                IF_Form.Show()
            End If
        End If

        'ToGetColumn
        'If e.ColumnIndex = 2 Then
        '    MsgBox(e.ColumnIndex)
        'End If

    End Sub

    Private Sub bt_up_Click(sender As Object, e As EventArgs) Handles bt_up.Click
        If GetSelectedRow() > 0 Then
            Dim objrow As DataGridViewRow = DG_CodeSection.Rows(GetSelectedRow())
            Dim indexx As Integer = GetSelectedRow()

            If Convert.ToString(DG_CodeSection.Rows(GetSelectedRow()).Cells(0).Value) <> "" Or Convert.ToString(DG_CodeSection.Rows(GetSelectedRow()).Cells(1).Value) <> "" Then
                DG_CodeSection.Rows.RemoveAt(indexx)
                DG_CodeSection.Rows.Insert(indexx - 1, objrow)
                DG_CodeSection.Rows(indexx - 1).Cells(0).Selected = True
                DG_CodeSection.Rows(indexx - 1).Selected = True
            End If
        End If
    End Sub

    Private Sub bt_down_Click(sender As Object, e As EventArgs) Handles bt_down.Click
        If GetSelectedRow() >= 0 Then
            Dim objrow As DataGridViewRow = DG_CodeSection.Rows(GetSelectedRow())
            Dim indexx As Integer = GetSelectedRow()

            If GetSelectedRow() < GetActiveRow() Then
                If Convert.ToString(DG_CodeSection.Rows(GetSelectedRow()).Cells(0).Value) <> "" Or Convert.ToString(DG_CodeSection.Rows(GetSelectedRow()).Cells(1).Value) <> "" Then
                    If Convert.ToString(DG_CodeSection.Rows(GetSelectedRow() + 1).Cells(0).Value) <> "" Or Convert.ToString(DG_CodeSection.Rows(GetSelectedRow() + 1).Cells(1).Value) <> "" Then
                        DG_CodeSection.Rows.RemoveAt(indexx)
                        DG_CodeSection.Rows.Insert(indexx + 1, objrow)
                        DG_CodeSection.Rows(indexx + 1).Cells(0).Selected = True
                        DG_CodeSection.Rows(indexx + 1).Selected = True
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub DG_CodeSection_MouseClick(sender As Object, e As MouseEventArgs) Handles DG_CodeSection.MouseClick
        DG_CodeSection.Rows(GetSelectedRow()).Selected = True
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles bt_create_conponent_.Click
        My.Forms.Create_Component.Show()
        My.Forms.CNS_Auto_E.Hide()

        'Temp Test COmponent Blank
        'TV_Test_Component_List.Nodes.Clear()

        'TEMP
        'TV_web_Object_List.Nodes.Clear()
        'DG_CodeSection.Rows.Clear()
        'TEMP
    End Sub

    Private Sub bt_Delete_Component_Click(sender As Object, e As EventArgs) Handles bt_Delete_Component.Click
        Dim result As Integer = MessageBox.Show("Do You Want To Delete '" + TV_Test_Component_List.SelectedNode.Text + "' Test Component.", "Delete Test Component", MessageBoxButtons.YesNo)

        If result = DialogResult.No Then
            'MessageBox.Show("No pressed")
        ElseIf result = DialogResult.Yes Then
            'MsgBox(path + TV_Test_Component_List.SelectedNode.Text)
            Dim createtable As String
            createtable = "delete from Test_Component_Creation where TestComponent_Name='" + TV_Test_Component_List.SelectedNode.Text + "'"
            Dim Execute_Cmd As New SqlCommand(createtable, cn)
            cn.Open()
            Execute_Cmd.ExecuteNonQuery()
            cn.Close()


            'START : DELETE DIRECTORY FROM SERVER
            Directory.Delete(path + TV_Test_Component_List.SelectedNode.Text, True)
            'END : DELETE DIRECTORY FROM SERVER


            'My.Computer.FileSystem.DeleteDirectory(path + TV_Test_Component_List.SelectedNode.Text, FileIO.DeleteDirectoryOption.ThrowIfDirectoryNonEmpty)
            Dim Delete_Table As String
            Delete_Table = "drop table " + TV_Test_Component_List.SelectedNode.Text

            Dim Execute_Cmd_delete As New SqlCommand(Delete_Table, cn)
            cn.Open()
            Execute_Cmd_delete.ExecuteNonQuery()
            cn.Close()

            MsgBox("Test Component Deleted : '" + TV_Test_Component_List.SelectedNode.Text + "'",, "Test Component Deleted")
            TV_Test_Component_List.Nodes.Remove(TV_Test_Component_List.SelectedNode)
            'get_List_of_test_components()
        End If





    End Sub

    Private Sub Bt_Edit_Web_Repository_Click(sender As Object, e As EventArgs) Handles Bt_Edit_Web_Repository.Click
        'Process.Start("D:\Utilities Made By Me\Object_File_Creator_Tool.xlsm")
        '\\host2\Automation\Auto-E\Generated_Test_Components
        'MsgBox("FULL PATH : \\host2\Automation\Auto-E\Generated_Test_Components\" + TV_Test_Component_List.SelectedNode.Text + "\WebObject Repository\" + TV_Test_Component_List.SelectedNode.Text + ".properties")
        'MsgBox("FILE NAME : " + TV_Test_Component_List.SelectedNode.Text + ".properties")

        Try
            If (Not System.IO.Directory.Exists("C:\E_FrameWork\Temp\")) Then
                System.IO.Directory.CreateDirectory("C:\E_FrameWork\Temp\")
            End If

            My.Computer.FileSystem.CopyDirectory("\\host2\Automation\Auto-E\Object Collector", "C:\E_FrameWork\Temp", True)




            'START : EXCEL OBJECT
            appXL = CreateObject("Excel.Application")
            appXL.Visible = True
            wbXl = appXL.Workbooks.Open("C:\E_FrameWork\Temp\Auto_E - Edit Object Collector.xlsm")
            appXL.DisplayAlerts = False
            appXL.ActiveWindow.WindowState = Excel.XlWindowState.xlMaximized
            'shXL = wbXl.Sheets
            shXL = wbXl.Sheets("Auto_E")
            shXL = wbXl.ActiveSheet
            Dim CellStart As Integer = 9
            'END : EXCEL OBJECT

            Dim reader As StreamReader = My.Computer.FileSystem.OpenTextFileReader("\\host2\Automation\Auto-E\Generated_Test_Components\" + TV_Test_Component_List.SelectedNode.Text + "\WebObject Repository\" + TV_Test_Component_List.SelectedNode.Text + ".properties")
            Dim a As String

            Do
                a = reader.ReadLine
                If a <> "" Then
                    Dim storetemp, storevalue As String
                    Dim chars() = a.ToCharArray()
                    Dim checkChartillGot As Integer = 0
                    For i = 0 To chars.Length - 1
                        If checkChartillGot = 0 Then
                            If chars(i).ToString = "=" Then
                                checkChartillGot = 1
                            Else
                                storetemp = storetemp + chars(i).ToString
                            End If
                        ElseIf checkChartillGot = 1 Then
                            storevalue = storevalue + chars(i).ToString
                        End If

                    Next
                    checkChartillGot = 0
                    shXL.Cells(CellStart, 1) = storetemp
                    shXL.Cells(CellStart, 2) = storevalue
                    'MsgBox("Attribute : " + storetemp)
                    'MsgBox("Value : " + storevalue)
                    storetemp = ""
                    storevalue = ""
                    CellStart = CellStart + 1
                End If
            Loop Until a Is Nothing

            shXL = wbXl.Sheets("Edit_Tab")
            'shXL = wbXl.ActiveSheet

            shXL.Cells(1, 2) = "\\host2\Automation\Auto-E\Generated_Test_Components\" + TV_Test_Component_List.SelectedNode.Text + "\WebObject Repository\" + TV_Test_Component_List.SelectedNode.Text + ".properties"

            wbXl.Save()
            'wbXl.Close()
            reader.Close()
            CellStart = 9
        Catch ex As System.IO.IOException
            MsgBox("File Might be Opened, Please close it and try again!")
        End Try


    End Sub

    Private Sub IsElementAvailableToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles IsElementAvailableToolStripMenuItem.Click
        'Condition to Add in Selected Row
        If DG_CodeSection.SelectedRows.Count = 1 Then
            DG_CodeSection.Rows.Insert(GetSelectedRow(), TV_web_Object_List.SelectedNode.Text, "Is Element Exist", "", False, "")
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).ReadOnly = False
        Else
            'Condition to Add in Last Row
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = TV_web_Object_List.SelectedNode.Text
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = "Is Element Exist"
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).ReadOnly = False
        End If
    End Sub

    Private Sub IsElementDisplayToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles IsElementDisplayToolStripMenuItem.Click
        'Condition to Add in Selected Row
        If DG_CodeSection.SelectedRows.Count = 1 Then
            DG_CodeSection.Rows.Insert(GetSelectedRow(), TV_web_Object_List.SelectedNode.Text, "Is Element Display", "", False, "")
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).ReadOnly = False
        Else
            'Condition to Add in Last Row
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = TV_web_Object_List.SelectedNode.Text
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = "Is Element Display"
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).ReadOnly = False
        End If
    End Sub

    Private Sub RunTimeChangeObjectValueToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RunTimeChangeObjectValueToolStripMenuItem.Click
        'Condition to Add in Selected Row
        If DG_CodeSection.SelectedRows.Count = 1 Then
            DG_CodeSection.Rows.Insert(GetSelectedRow(), TV_web_Object_List.SelectedNode.Text, "Run Time Change WebObject Property", "", False, "")
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).ReadOnly = False
        Else
            'Condition to Add in Last Row
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = TV_web_Object_List.SelectedNode.Text
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = "Run Time Change WebObject Property"
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).ReadOnly = False
        End If
    End Sub

    Private Sub TakeScreenShotToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TakeScreenShotToolStripMenuItem.Click
        If DG_CodeSection.SelectedRows.Count = 1 Then
            DG_CodeSection.Rows.Insert(GetSelectedRow(), "", "ScreenShot", "", False, "")
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).ReadOnly = False
        Else
            'Condition to Add in Last Row
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = ""
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = "ScreenShot"
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).ReadOnly = False
        End If
    End Sub

    Private Sub bt_excel_Click(sender As Object, e As EventArgs) Handles bt_excel.Click
        'UpdateExcel()
        Excel_Click()

    End Sub
    Sub Excel_Click()
        'START : Original
        'TestDataFileAddress = path + TV_Test_Component_List.SelectedNode.Text + "\Test Data\" + TV_Test_Component_List.SelectedNode.Text + ".xlsx"
        'Process.Start(TestDataFileAddress)
        'END : Original

        Dim proc As Process = Nothing
        proc = New Process()
        proc.StartInfo.WorkingDirectory = path + TV_Test_Component_List.SelectedNode.Text + "\Test Data"
        proc.StartInfo.FileName = TV_Test_Component_List.SelectedNode.Text + ".xlsx"
        proc.StartInfo.FileName.Max
        proc.StartInfo.CreateNoWindow = False
        proc.Start()

    End Sub
    Sub GenerateExcel(SheetFileName As String)
        TestDataFileAddress = path + foldername + "\Test Data\" + SheetFileName + ".xlsx"

        appXL = CreateObject("Excel.Application")
        appXL.Visible = False


        If System.IO.File.Exists(TestDataFileAddress) Then
            'Already Exist
            wbXl = appXL.Workbooks.Open(TestDataFileAddress)
            appXL.DisplayAlerts = False
            'shXL = wbXl.Sheets
            shXL = wbXl.Sheets(SheetFileName)
            shXL.Name = SheetFileName
            shXL = wbXl.ActiveSheet
        Else
            ' Add a new workbook.
            wbXl = appXL.Workbooks.Add
            appXL.DisplayAlerts = False
            'shXL = wbXl.Sheets
            shXL = wbXl.Sheets("Sheet1")
            shXL.Name = SheetFileName
            shXL = wbXl.ActiveSheet
            wbXl.SaveAs(TestDataFileAddress)
        End If


        ' Dim misValue As Object = System.Reflection.Missing.Value

        ' Start Excel and get Application object.

        ' appXL.WindowState = Excel.XlWindowState.xlMaximized


        'shXL = wbXl.Sheets.Add

        'Excel Heading
        'shXL.Cells(1, 1) = "#No."
        'shXL.Cells(1, 2) = "LINKS"



        ' Add a new workbook.
        '''wbXl = appXL.Workbooks.Add
        '''appXL.DisplayAlerts = False
        ''''shXL = wbXl.Sheets
        '''shXL = wbXl.Sheets("Sheet1")
        '''shXL.Name = SheetFileName
        '''shXL = wbXl.ActiveSheet




        ''''Save
        '''wbXl.SaveAs(TestDataFileAddress)

        'Create Function which will read data from DataGridView and identify readable Excel Coulmns.
        'Create Function , which will Update Excel File.


        'Close
        'wbXl.Close()
    End Sub
    Sub UpdateExcel()
        Dim TestDataFieldList() As String
        Dim TestDataFieldListNo As Integer = 0
        Dim propertyList As New List(Of String)()
        Dim TestDataFields() As String = {"A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1", "AB1", "AC1", "AD1", "AE1", "AF1", "AG1", "AH1", "AI1", "AJ1", "AK1", "AL1", "AM1", "AN1", "AO1", "AP1", "AQ1", "AR1", "AS1", "AT1", "AU1", "AV1", "AW1", "AX1", "AY1", "AZ1", "BA1", "BB1", "BC1", "BD1", "BE1", "BF1", "BG1", "BH1", "BI1", "BJ1", "BK1", "BL1", "BM1", "BN1", "BO1", "BP1", "BQ1", "BR1", "BS1", "BT1", "BU1", "BV1", "BW1", "BX1", "BY1", "BZ1", "CA1", "CB1", "CC1", "CD1", "CE1", "CF1", "CG1", "CH1", "CI1", "CJ1", "CK1", "CL1", "CM1", "CN1", "CO1", "CP1", "CQ1", "CR1", "CS1", "CT1", "CU1", "CV1", "CW1", "CX1", "CY1", "CZ1", "DA1", "DB1", "DC1", "DD1", "DE1", "DF1", "DG1", "DH1", "DI1", "DJ1", "DK1", "DL1", "DM1", "DN1", "DO1", "DP1", "DQ1", "DR1", "DS1", "DT1", "DU1", "DV1", "DW1", "DX1", "DY1", "DZ1"}

        For i = 0 To GetActiveRow() - 2

            If Convert.ToString(DG_CodeSection.Rows(i).Cells(2).Value) <> "" Then
                If Convert.ToString(DG_CodeSection.Rows(i).Cells(2).Value).Substring(0, 1) = "#" Then
                    propertyList.Add(Convert.ToString(DG_CodeSection.Rows(i).Cells(2).Value).Remove(0, 1))
                    TestDataFieldListNo = TestDataFieldListNo + 1
                End If
            End If
        Next
        TestDataFieldList = propertyList.ToArray

        Dim filledFields As Integer = 0
        'To Calculate Filled Fields
        For i = 0 To 129
            If shXL.Range(TestDataFields(i)).Text = "" Then
                Exit For
            Else
                filledFields = filledFields + 1
            End If
        Next

        Dim checkforstatus As Integer = 0

        For i = 0 To TestDataFieldList.Length - 1
            For x = 0 To TestDataFields.Length - 1
                If shXL.Range(TestDataFields(x)).Value = TestDataFieldList(i).ToString Then
                    checkforstatus = 0
                    Exit For
                Else
                    checkforstatus = checkforstatus + 1
                End If
            Next

            If checkforstatus = 130 Then
                'Create It
                shXL.Range(TestDataFields(filledFields)).Value = TestDataFieldList(i)
                filledFields = filledFields + 1
                checkforstatus = 0
            End If
        Next

        wbXl.Save()
        wbXl.Close()

        'shXL.Cells(1, 1) = ""

    End Sub

    Private Sub TV_Test_Component_List_AfterSelect(sender As Object, e As TreeViewEventArgs) Handles TV_Test_Component_List.AfterSelect
        If savechange > 1 Then
            Me.TV_Test_Component_List.SelectedNode = Me.TV_Test_Component_List.Nodes(CurrentSelectedNode)
            If fireeve = 1 Then
                Dim result As Integer = MessageBox.Show("Recent changes are not saved, do you want to proceed?", "Save Changes", MessageBoxButtons.YesNo)
                If result = DialogResult.No Then
                    fireeve=0
                    Exit Sub
                ElseIf result = DialogResult.Yes Then
                    savechange = 0
                End If
            End If
            If fireeve = 0 Then
                fireeve = 1
                Exit Sub
            End If
        End If


        TV_web_Object_List.Nodes.Clear()
        DG_CodeSection.Rows.Clear()
        DG_CodeSection.Refresh()
        DB_Selection()
        ds.Reset()

        'MsgBox(TV_Test_Component_List.SelectedNode.Text)
        'START : OPEN >PROPERTIES FILE
        Dim getFileName, getFilePath As String

        ' CurrentSelectedNode = TV_Test_Component_List.SelectedNode.Index

        getFilePath = "select Folder_Path from Test_Component_Creation where TestComponent_Name='" + TV_Test_Component_List.SelectedNode.Text + "'"


        CurrentSelectedNode = TV_Test_Component_List.SelectedNode.Index

        Dim Execute_Cmd As New SqlCommand(getFilePath, cn)
        cn.Open()
        Dim FP As String = Execute_Cmd.ExecuteScalar()
        cn.Close()
        'END : OPEN >PROPERTIES FILE

        'START : PUT DATA INTO DGV
        'da.Fill(ds, "Test_Two")
        'Dim Count_TC_Table As Integer = ds.Tables("Test_Two").Rows.Count
        Dim count_TC_table As String = "select COUNT(*) from " + TV_Test_Component_List.SelectedNode.Text
        Dim Execute_Cmdd As New SqlCommand(count_TC_table, cn)
        cn.Open()
        Dim FPP As Integer = Execute_Cmdd.ExecuteScalar()
        cn.Close()
        'END : PUT DATA INTO DGV

        'START: Get Data From SQL_Test_Component_Name_table to DataGridView
        Dim cmdget As SqlCommand
        Dim daget As SqlDataAdapter

        cmdget = New SqlCommand("select * from " + TV_Test_Component_List.SelectedNode.Text, cn)
        daget = New SqlDataAdapter(cmdget)




        daget.Fill(ds, TV_Test_Component_List.SelectedNode.Text)
        For i = 0 To FPP - 1
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = ds.Tables(TV_Test_Component_List.SelectedNode.Text).Rows(i)("Object_Name").ToString
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = ds.Tables(TV_Test_Component_List.SelectedNode.Text).Rows(i)("Action").ToString
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).Value = ds.Tables(TV_Test_Component_List.SelectedNode.Text).Rows(i)("Test_Data").ToString
            If ds.Tables(TV_Test_Component_List.SelectedNode.Text).Rows(i)("Comment_Line").ToString = "True" Then

                DG_CodeSection.Rows(GetActiveRow() - 2).Cells(3).Value = True
            ElseIf ds.Tables(TV_Test_Component_List.SelectedNode.Text).Rows(i)("Comment_Line").ToString = "False" Then
                DG_CodeSection.Rows(GetActiveRow() - 2).Cells(3).Value = False
            End If
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(4).Value = ds.Tables(TV_Test_Component_List.SelectedNode.Text).Rows(i)("Dev_Note").ToString
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(5).Value = ds.Tables(TV_Test_Component_List.SelectedNode.Text).Rows(i)("RowIds").ToString
        Next
        If FPP <> 0 Then
            lbl_TC_Status.Text = "Status : " + ds.Tables(TV_Test_Component_List.SelectedNode.Text).Rows(0)("Status").ToString
            lbl_TC_last_Updated_Time.Text = "Last Updated Date/Time : " + ds.Tables(TV_Test_Component_List.SelectedNode.Text).Rows(0)("Last_Updated_TimeDate").ToString
            lbl_TC_Last_UpdatedBy.Text = "Last Updated By : " + ds.Tables(TV_Test_Component_List.SelectedNode.Text).Rows(0)("Last_Updated_UserName").ToString
        Else
            lbl_TC_Status.Text = "Status : "
            lbl_TC_last_Updated_Time.Text = "Last Updated Date/Time : "
            lbl_TC_Last_UpdatedBy.Text = "Last Updated By : "
        End If
        'END: Get Data From SQL_Test_Component_Name_table to DataGridView

        check_dis_enable_lines()

        Dim reader As System.IO.StreamReader = My.Computer.FileSystem.OpenTextFileReader(FP + "\WebObject Repository\" + TV_Test_Component_List.SelectedNode.Text + ".properties")
        Dim a As String
        Dim no As Integer = 1
        Dim PropertyNamesArray As String()
        Dim propertyList As New List(Of String)()
        Do
            a = reader.ReadLine
            If a <> "" Then
                Dim PropertyArray As Char() = a.ToCharArray
                Dim firstName As Char() = ""

                For i = 0 To PropertyArray.Length - 1
                    If PropertyArray(i) = "=" Then
                        Exit For
                    Else
                        firstName = firstName + PropertyArray(i)
                    End If
                Next


                propertyList.Add(firstName)
                ' MsgBox(no.ToString + " : Property Name = " + firstName)
                no = no + 1
                firstName = ""
            End If
        Loop Until a Is Nothing

        reader.Close()
        PropertyNamesArray = propertyList.ToArray

        For i = 0 To PropertyNamesArray.Length - 1
            Dim getElement_Type As Char() = PropertyNamesArray(i).ToCharArray
            Dim getElement_Ini As String = ""
            For y = 0 To 3
                getElement_Ini = getElement_Ini + getElement_Type(y)
            Next



            If getElement_Ini = "lnk_" Or getElement_Ini = "lbl_" Or getElement_Ini = "txt_" Or getElement_Ini = "cmb_" Or getElement_Ini = "chk_" Or getElement_Ini = "rbd_" Or getElement_Ini = "img_" Or getElement_Ini = "btn_" Then
                TV_web_Object_List.Nodes.Add(PropertyNamesArray(i))
            End If
            getElement_Ini = ""
        Next


        savechange = 1
        bt_create_conponent.Enabled = True
    End Sub

    Private Sub ToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem2.Click
        If DG_CodeSection.SelectedRows.Count = 1 Then
            DG_CodeSection.Rows.Insert(GetSelectedRow(), "", "Get URL", "", False, "")
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).ReadOnly = False
        Else
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = ""
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = "Get URL"
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).ReadOnly = False
        End If
    End Sub

    Private Sub MyWaitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MyWaitToolStripMenuItem.Click
        If DG_CodeSection.SelectedRows.Count = 1 Then
            DG_CodeSection.Rows.Insert(GetSelectedRow(), "", "My Wait (Enter in Seconds)", "", False, "")
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).ReadOnly = False
        Else
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = ""
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = "My Wait (Enter in Seconds)"
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).ReadOnly = False
        End If
    End Sub

    Private Sub BrowserBackToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles BrowserBackToolStripMenuItem.Click
        If DG_CodeSection.SelectedRows.Count = 1 Then
            DG_CodeSection.Rows.Insert(GetSelectedRow(), "", "Browser : Back", "", False, "")
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).ReadOnly = True
        Else
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = ""
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = "Browser : Back"
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).ReadOnly = True
        End If
    End Sub

    Private Sub BrowserRefreshToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles BrowserRefreshToolStripMenuItem.Click
        If DG_CodeSection.SelectedRows.Count = 1 Then
            DG_CodeSection.Rows.Insert(GetSelectedRow(), "", "Browser : Refresh", "", False, "")
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).ReadOnly = True
        Else
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = ""
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = "Browser : Refresh"
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).ReadOnly = True
        End If
    End Sub

    Private Sub BrowserForwardToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles BrowserForwardToolStripMenuItem.Click
        If DG_CodeSection.SelectedRows.Count = 1 Then
            DG_CodeSection.Rows.Insert(GetSelectedRow(), "", "Browser : Forward", "", False, "")
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).ReadOnly = True
        Else
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = ""
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = "Browser : Forward"
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).ReadOnly = True
        End If
    End Sub

    Private Sub AcceptAlertToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AcceptAlertToolStripMenuItem.Click
        If DG_CodeSection.SelectedRows.Count = 1 Then
            DG_CodeSection.Rows.Insert(GetSelectedRow(), "", "Alert - Accept", "", False, "")
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).ReadOnly = True
        Else
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = ""
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = "Alert - Accept"
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).ReadOnly = True
        End If
    End Sub

    Private Sub DismissAlertToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DismissAlertToolStripMenuItem.Click
        If DG_CodeSection.SelectedRows.Count = 1 Then
            DG_CodeSection.Rows.Insert(GetSelectedRow(), "", "Alert - Dismiss", "", False, "")
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).ReadOnly = True
        Else
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = ""
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = "Alert - Dismiss"
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).ReadOnly = True
        End If
    End Sub

    Private Sub Switch2FrameToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Switch2FrameToolStripMenuItem.Click
        If DG_CodeSection.SelectedRows.Count = 1 Then
            DG_CodeSection.Rows.Insert(GetSelectedRow(), "", "Switch to Frame", "", False, "")
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).ReadOnly = False
        Else
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = ""
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = "Switch to Frame"
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).ReadOnly = False
        End If
    End Sub

    Private Sub SwitchBackToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SwitchBackToolStripMenuItem.Click
        If DG_CodeSection.SelectedRows.Count = 1 Then
            DG_CodeSection.Rows.Insert(GetSelectedRow(), "", "Switch Back to Main Frame", "", False, "")
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).ReadOnly = True
        Else
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = ""
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = "Switch Back to Main Frame"
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).ReadOnly = True
        End If
    End Sub

    Private Sub ToolStripMenuItem7_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem7.Click
        Dim ifcountget As Integer = 0
        ifcountget = IF_ConditionCount("IF")
        If DG_CodeSection.SelectedRows.Count = 1 Then
            DG_CodeSection.Rows.Insert(GetSelectedRow(), "", "IF", "", False, "")
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).ReadOnly = False

            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(5).Value = "IF_ID_" + ifcountget.ToString
        Else
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = ""
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = "IF"
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).ReadOnly = False
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(5).Value = "IF_ID_" + ifcountget.ToString
        End If
        If DG_CodeSection.SelectedRows.Count = 1 Then
            DG_CodeSection.Rows.Insert(GetSelectedRow(), "", "End IF", "", False, "")
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(5).Value = "IF_ID_" + ifcountget.ToString
        Else
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = ""
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = "End IF"
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(5).Value = "IF_ID_" + ifcountget.ToString
        End If

    End Sub

    Private Sub ToolStripMenuItem8_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem8.Click
        Dim ifcountget As Integer = 0
        ifcountget = IF_ConditionCount("IF")
        If DG_CodeSection.SelectedRows.Count = 1 Then
            DG_CodeSection.Rows.Insert(GetSelectedRow(), "", "IF", "", False, "")
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).ReadOnly = False
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(5).Value = "IF_ID_" + ifcountget.ToString
        Else
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = ""
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = "IF"
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).ReadOnly = False
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(5).Value = "IF_ID_" + ifcountget.ToString
        End If
        If DG_CodeSection.SelectedRows.Count = 1 Then
            DG_CodeSection.Rows.Insert(GetSelectedRow(), "", "Else", "", False, "")
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(5).Value = "IF_ID_" + ifcountget.ToString
        Else
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = ""
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = "Else"
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(5).Value = "IF_ID_" + ifcountget.ToString
        End If
        If DG_CodeSection.SelectedRows.Count = 1 Then
            DG_CodeSection.Rows.Insert(GetSelectedRow(), "", "End IF", "", False, "")
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(5).Value = "IF_ID_" + ifcountget.ToString
        Else
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = ""
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = "End IF"
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(5).Value = "IF_ID_" + ifcountget.ToString
        End If
    End Sub

    Private Sub ToolStripMenuItem11_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem11.Click
        If DG_CodeSection.SelectedRows.Count = 1 Then
            DG_CodeSection.Rows.Insert(GetSelectedRow(), "", "Do..", "", False, "")
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).ReadOnly = True
        Else
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = ""
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = "Do.."
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).ReadOnly = True
        End If
        If DG_CodeSection.SelectedRows.Count = 1 Then
            DG_CodeSection.Rows.Insert(GetSelectedRow(), "", "While", "", False, "")
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).ReadOnly = False
        Else
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = ""
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = "While"
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).ReadOnly = False
        End If
    End Sub

    Private Sub ToolStripMenuItem12_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem12.Click
        If DG_CodeSection.SelectedRows.Count = 1 Then
            DG_CodeSection.Rows.Insert(GetSelectedRow(), "", "While..", "", False, "")
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).ReadOnly = False
        Else
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = ""
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = "While.."
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).ReadOnly = False
        End If
        If DG_CodeSection.SelectedRows.Count = 1 Then
            DG_CodeSection.Rows.Insert(GetSelectedRow(), "", "End..While", "", False, "")
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).ReadOnly = True
        Else
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = ""
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = "End..While"
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).ReadOnly = True
        End If

    End Sub

    Private Sub ToolStripMenuItem13_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem13.Click
        If DG_CodeSection.SelectedRows.Count = 1 Then
            DG_CodeSection.Rows.Insert(GetSelectedRow(), "", "Exit Loop", "", False, "")
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).ReadOnly = True
        Else
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = ""
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = "Exit Loop"
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).ReadOnly = True
        End If
    End Sub

    Private Sub CodeSeparatorToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CodeSeparatorToolStripMenuItem.Click
        If DG_CodeSection.SelectedRows.Count = 1 Then
            DG_CodeSection.Rows.Insert(GetSelectedRow(), "- - - - - - - - - - - - - - -", "- - - - - - -     Code-Separator     - - - - - - -", "- - - - - - - - - - - - - - -", False, "")
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(3).ReadOnly = True
        Else
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = "- - - - - - - - - - - - - - -"
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = "- - - - - - -     Code-Separator     - - - - - - -"
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).Value = "- - - - - - - - - - - - - - -"
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(3).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(4).Value = ""
        End If
    End Sub

    Private Sub DG_CodeSection_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DG_CodeSection.CellContentClick



    End Sub

    Private Sub TV_web_Object_List_AfterSelect(sender As Object, e As TreeViewEventArgs) Handles TV_web_Object_List.AfterSelect

    End Sub

    Private Sub DG_CodeSection_CurrentCellDirtyStateChanged(sender As Object, e As EventArgs) Handles DG_CodeSection.CurrentCellDirtyStateChanged

    End Sub

    Private Sub DG_CodeSection_CellBeginEdit(sender As Object, e As DataGridViewCellCancelEventArgs) Handles DG_CodeSection.CellBeginEdit
        savechange = savechange + 1
    End Sub

    Private Sub DG_CodeSection_RowsAdded(sender As Object, e As DataGridViewRowsAddedEventArgs) Handles DG_CodeSection.RowsAdded
        If savechange = 1 Then
            savechange = savechange + 1
        End If
    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        My.Forms.CNS_Auto_E.Hide()
        My.Forms.Generate_Test_Script.Show()

        'TV_web_Object_List.Nodes.Clear()
        'DG_CodeSection.Rows.Clear()
    End Sub

    Private Sub DG_CodeSection_RowStateChanged(sender As Object, e As DataGridViewRowStateChangedEventArgs) Handles DG_CodeSection.RowStateChanged

    End Sub

    Private Sub DG_CodeSection_RowsRemoved(sender As Object, e As DataGridViewRowsRemovedEventArgs) Handles DG_CodeSection.RowsRemoved
        If savechange = 1 Then
            savechange = savechange + 1
        End If
    End Sub

    Private Sub lbl_about_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lbl_about.LinkClicked
        My.Forms.CNS_Auto_E.Hide()
        My.Forms.About.Show()
    End Sub

    Private Sub InnerTextToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles InnerTextToolStripMenuItem.Click
        If DG_CodeSection.SelectedRows.Count = 1 Then
            DG_CodeSection.Rows.Insert(GetSelectedRow(), TV_web_Object_List.SelectedNode.Text, "Capture Attribute - InnerText", "", False, "")
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).ReadOnly = False
        Else
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = TV_web_Object_List.SelectedNode.Text
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = "Capture Attribute - InnerText"
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).ReadOnly = False
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).Value = ""
        End If

    End Sub

    Private Sub ValueToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ValueToolStripMenuItem.Click
        If DG_CodeSection.SelectedRows.Count = 1 Then
            DG_CodeSection.Rows.Insert(GetSelectedRow(), TV_web_Object_List.SelectedNode.Text, "Capture Attribute - Value", "", False, "")
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).ReadOnly = False
        Else
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = TV_web_Object_List.SelectedNode.Text
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = "Capture Attribute - Value"
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).ReadOnly = False
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).Value = ""
        End If
    End Sub

    Private Sub IDToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles IDToolStripMenuItem.Click
        If DG_CodeSection.SelectedRows.Count = 1 Then
            DG_CodeSection.Rows.Insert(GetSelectedRow(), TV_web_Object_List.SelectedNode.Text, "Capture Attribute - ID", "", False, "")
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).ReadOnly = False
        Else
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = TV_web_Object_List.SelectedNode.Text
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = "Capture Attribute - ID"
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).ReadOnly = False
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).Value = ""
        End If
    End Sub

    Private Sub TypeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TypeToolStripMenuItem.Click
        If DG_CodeSection.SelectedRows.Count = 1 Then
            DG_CodeSection.Rows.Insert(GetSelectedRow(), TV_web_Object_List.SelectedNode.Text, "Capture Attribute - Type", "", False, "")
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).ReadOnly = False
        Else
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = TV_web_Object_List.SelectedNode.Text
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = "Capture Attribute - Type"
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).ReadOnly = False
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).Value = ""
        End If
    End Sub

    Private Sub SwitchToTabToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SwitchToTabToolStripMenuItem.Click
        If DG_CodeSection.SelectedRows.Count = 1 Then
            DG_CodeSection.Rows.Insert(GetSelectedRow(), "", "Switch to tab 2", "", False, "")
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).ReadOnly = True
        Else
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = ""
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = "Switch to tab 2"
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).ReadOnly = True
        End If
    End Sub

    Private Sub SwitchBackToMainTabToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SwitchBackToMainTabToolStripMenuItem.Click
        If DG_CodeSection.SelectedRows.Count = 1 Then
            DG_CodeSection.Rows.Insert(GetSelectedRow(), "", "Switch to main tab", "", False, "")
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetSelectedRow() - 1).Cells(2).ReadOnly = True
        Else
            DG_CodeSection.Rows.Add()
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = ""
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).ReadOnly = True
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = "Switch to main tab"
            DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).ReadOnly = True
        End If
    End Sub

    Private Sub bt_create_Object_File_Click(sender As Object, e As EventArgs) Handles bt_create_Object_File.Click
        Try
            If (Not System.IO.Directory.Exists("C:\E_FrameWork\Temp\")) Then
                System.IO.Directory.CreateDirectory("C:\E_FrameWork\Temp\")
            End If

            My.Computer.FileSystem.CopyDirectory("\\host2\Automation\Auto-E\Object Collector", "C:\E_FrameWork\Temp", True)

            Dim proc As Process = Nothing
            proc = New Process()
            proc.StartInfo.WorkingDirectory = "C:\E_FrameWork\Temp"
            proc.StartInfo.FileName = "Auto_E - Object Collector.xlsm"
            proc.StartInfo.FileName.Max
            proc.StartInfo.CreateNoWindow = False
            proc.Start()
            'proc.WaitForExit()
        Catch ex As System.IO.IOException
            MsgBox("File Might be Opened, Please close it and try again!")
        End Try


    End Sub

    Private Sub CopyModeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CopyModeToolStripMenuItem.Click
        DG_CodeSection.MultiSelect = True
    End Sub

    Private Sub CopyToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CopyToolStripMenuItem.Click
        'Working on Copy into array and Paste
        'List To store Lines
        RowList.Clear()

        ' MsgBox(DG_CodeSection.SelectedRows.Count)
        'For i = 0 To DG_CodeSection.SelectedRows.Count - 1
        For i = DG_CodeSection.SelectedRows.Count - 1 To 0 Step -1
            'MsgBox(DG_CodeSection.SelectedRows.Item(i).ToString)

            RowList.Add("" + Convert.ToString(DG_CodeSection.SelectedRows.Item(i).Cells(0).Value) + "," + Convert.ToString(DG_CodeSection.SelectedRows.Item(i).Cells(1).Value) + "," + Convert.ToString(DG_CodeSection.SelectedRows.Item(i).Cells(2).Value) + "," + Convert.ToString(DG_CodeSection.SelectedRows.Item(i).Cells(3).Value) + "," + Convert.ToString(DG_CodeSection.SelectedRows.Item(i).Cells(4).Value) + "")
            'MsgBox("" + Convert.ToString(DG_CodeSection.SelectedRows.Item(i).Cells(0).Value) + "," + Convert.ToString(DG_CodeSection.SelectedRows.Item(i).Cells(1).Value) + "," + Convert.ToString(DG_CodeSection.SelectedRows.Item(i).Cells(2).Value) + "," + Convert.ToString(DG_CodeSection.SelectedRows.Item(i).Cells(3).Value) + "," + Convert.ToString(DG_CodeSection.SelectedRows.Item(i).Cells(4).Value) + "")
        Next

        DG_CodeSection.MultiSelect = False

    End Sub

    Private Sub PastedisableToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PastedisableToolStripMenuItem.Click

        For i = 0 To RowList.Count - 1
            Dim words As String() = RowList(i).Split(New Char() {","c})
            'MsgBox(RowList(i).ToString)

            If DG_CodeSection.SelectedRows.Count = 1 Then
                If words(3).ToString = "" Or words(3).ToString = "False" Then
                    DG_CodeSection.Rows.Insert(GetSelectedRow(), words(0).ToString, words(1).ToString, words(2).ToString, False, words(4).ToString)
                Else
                    DG_CodeSection.Rows.Insert(GetSelectedRow(), words(0).ToString, words(1).ToString, words(2).ToString, True, words(4).ToString)
                End If
            Else
                DG_CodeSection.Rows.Add()
                DG_CodeSection.Rows(GetActiveRow() - 2).Cells(0).Value = words(0).ToString
                DG_CodeSection.Rows(GetActiveRow() - 2).Cells(1).Value = words(1).ToString
                DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).Value = words(2).ToString
                If words(3).ToString = "" Or words(3).ToString = "False" Then
                    DG_CodeSection.Rows(GetActiveRow() - 2).Cells(3).Value = False
                Else
                    DG_CodeSection.Rows(GetActiveRow() - 2).Cells(3).Value = True
                End If
                DG_CodeSection.Rows(GetActiveRow() - 2).Cells(2).Value = words(4).ToString
            End If

        Next

        'Call Function to Enable/Disable Row Cells
        check_dis_enable_lines()

    End Sub

    Private Sub DeleteToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DeleteToolStripMenuItem.Click
        'Working on Multiple Deletes

        For i = DG_CodeSection.SelectedRows.Count - 1 To 0 Step -1
            'MsgBox(DG_CodeSection.SelectedRows.Item(i).Index.ToString)

            Try
                DG_CodeSection.Rows.RemoveAt(DG_CodeSection.SelectedRows.Item(i).Index)
                DG_CodeSection.Rows(GetSelectedRow()).Selected = True
            Catch ex As System.InvalidOperationException
                MsgBox("Selected Row Might Be Null.",, "Exception...Hhhmmmm")
            End Try

        Next

        DG_CodeSection.MultiSelect = False
    End Sub

    Private Sub CommentCodeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CommentCodeToolStripMenuItem.Click
        For i = DG_CodeSection.SelectedRows.Count - 1 To 0 Step -1
            'MsgBox(DG_CodeSection.SelectedRows.Item(i).ToString)
            DG_CodeSection.SelectedRows.Item(i).Cells(3).Value = True

            'MsgBox("" + Convert.ToString(DG_CodeSection.SelectedRows.Item(i).Cells(0).Value) + "," + Convert.ToString(DG_CodeSection.SelectedRows.Item(i).Cells(1).Value) + "," + Convert.ToString(DG_CodeSection.SelectedRows.Item(i).Cells(2).Value) + "," + Convert.ToString(DG_CodeSection.SelectedRows.Item(i).Cells(3).Value) + "," + Convert.ToString(DG_CodeSection.SelectedRows.Item(i).Cells(4).Value) + "")
        Next

        DG_CodeSection.MultiSelect = False
    End Sub

    Private Sub RemoveCodeCommentToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RemoveCodeCommentToolStripMenuItem.Click
        For i = DG_CodeSection.SelectedRows.Count - 1 To 0 Step -1
            'MsgBox(DG_CodeSection.SelectedRows.Item(i).ToString)
            DG_CodeSection.SelectedRows.Item(i).Cells(3).Value = False

            'MsgBox("" + Convert.ToString(DG_CodeSection.SelectedRows.Item(i).Cells(0).Value) + "," + Convert.ToString(DG_CodeSection.SelectedRows.Item(i).Cells(1).Value) + "," + Convert.ToString(DG_CodeSection.SelectedRows.Item(i).Cells(2).Value) + "," + Convert.ToString(DG_CodeSection.SelectedRows.Item(i).Cells(3).Value) + "," + Convert.ToString(DG_CodeSection.SelectedRows.Item(i).Cells(4).Value) + "")
        Next

        DG_CodeSection.MultiSelect = False
    End Sub

    Private Sub DG_CodeSection_KeyDown(sender As Object, e As KeyEventArgs) Handles DG_CodeSection.KeyDown
        'START : SHORTKUTS
        If e.KeyCode = Keys.S And Keys.ControlKey Then
            'SAVE (CTRL+S)
            SaveComponent_On_bt_Create_Compo("")
        ElseIf e.KeyCode = Keys.A And Keys.ControlKey Then
            'COMPILE (CTRL+A)
            compilation_button()
        ElseIf e.KeyCode = Keys.F5 Then
            'RUN\EXECUTE (F5)
            GetAuto_Script_From_S_TO_D()
        ElseIf e.KeyCode = Keys.E And Keys.ControlKey Then
            'OPEN TEST_DATA FILE (CTRL+E)
            Excel_Click()
        ElseIf e.KeyCode = Keys.L And Keys.ControlKey Then
            Just_Copy_From_Server_To_Local()
        End If
        'END : SHORTKUTS

        'If (e.KeyCode = Keys.LShiftKey Or e.KeyCode = Keys.LShiftKey) And (e.KeyCode = Keys.Down Or e.KeyCode = Keys.Up) Then
        ' MsgBox("selected..!")
        ' End If

        'START : Select Whole ROW
        If e.KeyCode = Keys.Down Then
            DG_CodeSection.Rows(GetSelectedRow).Selected = True
        End If
        If e.KeyCode = Keys.Up Then
            DG_CodeSection.Rows(GetSelectedRow).Selected = True
        End If
        If e.KeyCode = Keys.Right Then
            DG_CodeSection.Rows(GetSelectedRow).Selected = True
        End If
        If e.KeyCode = Keys.Left Then
            DG_CodeSection.Rows(GetSelectedRow).Selected = True
        End If
        'END : Select Whole ROW
    End Sub

End Class