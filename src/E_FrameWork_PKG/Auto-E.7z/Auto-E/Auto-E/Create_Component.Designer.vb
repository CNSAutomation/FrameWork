﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Create_Component
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.lbl_Create_test_component = New System.Windows.Forms.Label()
        Me.txt_Test_Comp_Name = New System.Windows.Forms.TextBox()
        Me.txt_Test_Component_Description = New System.Windows.Forms.RichTextBox()
        Me.bt_Create_Test_Component = New System.Windows.Forms.Button()
        Me.bt_Browse_Repository = New System.Windows.Forms.Button()
        Me.txt_Web_Object_File_Address = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.OFD_Get_File = New System.Windows.Forms.OpenFileDialog()
        Me.bt_create_conponent = New System.Windows.Forms.Button()
        Me.lbl_validation_message = New System.Windows.Forms.Label()
        Me.lbl_validation_msg_web_object_File = New System.Windows.Forms.Label()
        Me.Hidden_TV_BC = New System.Windows.Forms.TreeView()
        Me.SuspendLayout()
        '
        'lbl_Create_test_component
        '
        Me.lbl_Create_test_component.AutoSize = True
        Me.lbl_Create_test_component.BackColor = System.Drawing.Color.Silver
        Me.lbl_Create_test_component.Font = New System.Drawing.Font("Berlin Sans FB", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Create_test_component.Location = New System.Drawing.Point(207, 21)
        Me.lbl_Create_test_component.Name = "lbl_Create_test_component"
        Me.lbl_Create_test_component.Size = New System.Drawing.Size(215, 23)
        Me.lbl_Create_test_component.TabIndex = 28
        Me.lbl_Create_test_component.Text = "Create Test Component"
        '
        'txt_Test_Comp_Name
        '
        Me.txt_Test_Comp_Name.Font = New System.Drawing.Font("Arial Narrow", 12.0!)
        Me.txt_Test_Comp_Name.Location = New System.Drawing.Point(312, 95)
        Me.txt_Test_Comp_Name.Name = "txt_Test_Comp_Name"
        Me.txt_Test_Comp_Name.Size = New System.Drawing.Size(216, 26)
        Me.txt_Test_Comp_Name.TabIndex = 0
        '
        'txt_Test_Component_Description
        '
        Me.txt_Test_Component_Description.Font = New System.Drawing.Font("Arial Narrow", 12.0!)
        Me.txt_Test_Component_Description.Location = New System.Drawing.Point(312, 199)
        Me.txt_Test_Component_Description.Name = "txt_Test_Component_Description"
        Me.txt_Test_Component_Description.Size = New System.Drawing.Size(216, 61)
        Me.txt_Test_Component_Description.TabIndex = 2
        Me.txt_Test_Component_Description.Text = ""
        '
        'bt_Create_Test_Component
        '
        Me.bt_Create_Test_Component.Font = New System.Drawing.Font("Berlin Sans FB", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt_Create_Test_Component.Location = New System.Drawing.Point(187, 293)
        Me.bt_Create_Test_Component.Name = "bt_Create_Test_Component"
        Me.bt_Create_Test_Component.Size = New System.Drawing.Size(271, 36)
        Me.bt_Create_Test_Component.TabIndex = 3
        Me.bt_Create_Test_Component.Text = "Create Test Component"
        Me.bt_Create_Test_Component.UseVisualStyleBackColor = True
        '
        'bt_Browse_Repository
        '
        Me.bt_Browse_Repository.Font = New System.Drawing.Font("Arial Narrow", 12.0!)
        Me.bt_Browse_Repository.Location = New System.Drawing.Point(534, 140)
        Me.bt_Browse_Repository.Name = "bt_Browse_Repository"
        Me.bt_Browse_Repository.Size = New System.Drawing.Size(83, 30)
        Me.bt_Browse_Repository.TabIndex = 1
        Me.bt_Browse_Repository.Text = "Browse..."
        Me.bt_Browse_Repository.UseVisualStyleBackColor = True
        '
        'txt_Web_Object_File_Address
        '
        Me.txt_Web_Object_File_Address.Font = New System.Drawing.Font("Arial Narrow", 12.0!)
        Me.txt_Web_Object_File_Address.Location = New System.Drawing.Point(312, 142)
        Me.txt_Web_Object_File_Address.Name = "txt_Web_Object_File_Address"
        Me.txt_Web_Object_File_Address.ReadOnly = True
        Me.txt_Web_Object_File_Address.Size = New System.Drawing.Size(216, 26)
        Me.txt_Web_Object_File_Address.TabIndex = 34
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Silver
        Me.Label1.Font = New System.Drawing.Font("Berlin Sans FB", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(59, 98)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(180, 19)
        Me.Label1.TabIndex = 35
        Me.Label1.Text = "Test Component Name :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Silver
        Me.Label2.Font = New System.Drawing.Font("Berlin Sans FB", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(59, 145)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(134, 19)
        Me.Label2.TabIndex = 36
        Me.Label2.Text = "Web Objects File :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Silver
        Me.Label3.Font = New System.Drawing.Font("Berlin Sans FB", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(59, 202)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(217, 19)
        Me.Label3.TabIndex = 37
        Me.Label3.Text = "Test Component Description :"
        '
        'OFD_Get_File
        '
        Me.OFD_Get_File.FileName = "OFD_GetFile"
        Me.OFD_Get_File.Filter = "Web_Object Files|*.properties"
        Me.OFD_Get_File.Title = "UPLOAD WEB_OBJECT FILE"
        '
        'bt_create_conponent
        '
        Me.bt_create_conponent.Font = New System.Drawing.Font("Candara", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt_create_conponent.Image = Global.Auto_E.My.ResourcesRepair.Resources._1490183723_Cancel
        Me.bt_create_conponent.Location = New System.Drawing.Point(623, 3)
        Me.bt_create_conponent.Name = "bt_create_conponent"
        Me.bt_create_conponent.Size = New System.Drawing.Size(42, 41)
        Me.bt_create_conponent.TabIndex = 4
        Me.bt_create_conponent.UseVisualStyleBackColor = True
        '
        'lbl_validation_message
        '
        Me.lbl_validation_message.AutoSize = True
        Me.lbl_validation_message.Location = New System.Drawing.Point(270, 73)
        Me.lbl_validation_message.Name = "lbl_validation_message"
        Me.lbl_validation_message.Size = New System.Drawing.Size(0, 13)
        Me.lbl_validation_message.TabIndex = 38
        '
        'lbl_validation_msg_web_object_File
        '
        Me.lbl_validation_msg_web_object_File.AutoSize = True
        Me.lbl_validation_msg_web_object_File.Location = New System.Drawing.Point(289, 125)
        Me.lbl_validation_msg_web_object_File.Name = "lbl_validation_msg_web_object_File"
        Me.lbl_validation_msg_web_object_File.Size = New System.Drawing.Size(0, 13)
        Me.lbl_validation_msg_web_object_File.TabIndex = 39
        '
        'Hidden_TV_BC
        '
        Me.Hidden_TV_BC.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Hidden_TV_BC.Font = New System.Drawing.Font("Berlin Sans FB", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Hidden_TV_BC.HideSelection = False
        Me.Hidden_TV_BC.Location = New System.Drawing.Point(576, 293)
        Me.Hidden_TV_BC.Name = "Hidden_TV_BC"
        Me.Hidden_TV_BC.ShowLines = False
        Me.Hidden_TV_BC.ShowPlusMinus = False
        Me.Hidden_TV_BC.ShowRootLines = False
        Me.Hidden_TV_BC.Size = New System.Drawing.Size(114, 116)
        Me.Hidden_TV_BC.TabIndex = 41
        Me.Hidden_TV_BC.Visible = False
        '
        'Create_Component
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(677, 376)
        Me.Controls.Add(Me.Hidden_TV_BC)
        Me.Controls.Add(Me.lbl_validation_msg_web_object_File)
        Me.Controls.Add(Me.lbl_validation_message)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txt_Web_Object_File_Address)
        Me.Controls.Add(Me.bt_Browse_Repository)
        Me.Controls.Add(Me.bt_Create_Test_Component)
        Me.Controls.Add(Me.txt_Test_Component_Description)
        Me.Controls.Add(Me.txt_Test_Comp_Name)
        Me.Controls.Add(Me.bt_create_conponent)
        Me.Controls.Add(Me.lbl_Create_test_component)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Create_Component"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Create_Component"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbl_Create_test_component As Label
    Friend WithEvents bt_create_conponent As Button
    Friend WithEvents txt_Test_Comp_Name As TextBox
    Friend WithEvents txt_Test_Component_Description As RichTextBox
    Friend WithEvents bt_Create_Test_Component As Button
    Friend WithEvents bt_Browse_Repository As Button
    Friend WithEvents txt_Web_Object_File_Address As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents OFD_Get_File As OpenFileDialog
    Friend WithEvents lbl_validation_message As Label
    Friend WithEvents lbl_validation_msg_web_object_File As Label
    Friend WithEvents Hidden_TV_BC As TreeView
End Class
