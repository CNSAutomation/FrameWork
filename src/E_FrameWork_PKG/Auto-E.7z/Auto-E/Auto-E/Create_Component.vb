﻿Imports System.Data.SqlClient
Public Class Create_Component
    Dim checkvalidation As Integer = 0
    Dim charcount As Integer = 0
    Dim charstr As String
    Dim path, foldername As String

    'DataBase
    Dim cn As SqlConnection
    Dim cmd As SqlCommand
    Dim da As SqlDataAdapter
    Dim bm As BindingManagerBase
    Dim ds As New Data.DataSet

    Private Sub bt_create_conponent_Click(sender As Object, e As EventArgs) Handles bt_create_conponent.Click
        My.Forms.Create_Component.Close()
        My.Forms.CNS_Auto_E.Refresh()
        CNS_Auto_E.Show()


        'My.Forms.CNS_Auto_E.get_List_of_test_components()
    End Sub

    Private Sub Create_Component_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'MsgBox(My.Forms.CNS_Auto_E.GetProject_FolderPath())

        path = My.Forms.CNS_Auto_E.GetProject_FolderPath()

        Me.ActiveControl = txt_Test_Comp_Name

        'START : DB SECTION
        'cn = New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=" + My.Forms.CNS_Auto_E.GetDBPATH() + ";Integrated Security=False;User Id=sa,;Password=user123")

        'cn = New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=" + My.Forms.CNS_Auto_E.GetDBPATH() + ";Integrated Security=False;User ID=sa;Password=user123;Connect Timeout=15;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False")


        'TEMP
        'IN-USE ''' cn = New SqlConnection("Server=CNS10\E_MSSQLSERVER;Database=Auto_E_DB;User ID=sa;Password=user@123;Trusted_Connection=True;")
        cn = New SqlConnection("Server=db;Database=Auto_E;Integrated Security=SSPI;")
        'TEMP

        'REAL ' cn = New SqlConnection("Server=.\SQLExpress;Database=AUTO_E;Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=" + My.Forms.CNS_Auto_E.GetDBPATH() + ";Integrated Security=True;User ID=sa;Password=user123;Trusted_Connection=True;MultipleActiveResultSets=true")

        'DB : \\CNNAS\AUTOMATION\AUTO-E\DB\AUTO_E.MDF

        '"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=" + My.Forms.CNS_Auto_E.GetDBPATH() + ";Integrated Security=False;User ID=sa;Password=********;Connect Timeout=15;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False"
        cmd = New SqlCommand("select * from Test_Component_Creation", cn)
        da = New SqlDataAdapter(cmd)

        da.Fill(ds)
        bm = Me.BindingContext(ds.Tables(0))
        'END : DB SECTION
    End Sub

    Private Sub bt_Browse_Repository_Click(sender As Object, e As EventArgs) Handles bt_Browse_Repository.Click
        lbl_validation_msg_web_object_File.Text = ""
        OFD_Get_File.ShowDialog()
        txt_Web_Object_File_Address.Text = OFD_Get_File.FileName
    End Sub

    Private Sub txt_Test_Comp_Name_TextChanged(sender As Object, e As EventArgs) Handles txt_Test_Comp_Name.TextChanged
        If checkvalidation = 1 Then
            txt_Test_Comp_Name.Text = ""
            txt_Test_Comp_Name.Focus()
            'txt_Test_Comp_Name.SelectionStart = Len(txt_Test_Comp_Name.Text) + 1
            lbl_validation_message.Text = "Can enter only 'a-z', 'A-Z', '_' (underscore) AND 30 characters Max."
            lbl_validation_message.ForeColor = Color.Red
        End If

        If charcount > 29 Then
            charstr = ""
            Dim chars() = txt_Test_Comp_Name.Text.ToCharArray()
            For i = 0 To chars.Count - 1
                If i > 29 Then
                    Exit For
                Else
                    charstr = charstr + chars(i)
                End If
            Next
            txt_Test_Comp_Name.Text = charstr
            txt_Test_Comp_Name.SelectionStart = Len(txt_Test_Comp_Name.Text) + 1

            lbl_validation_message.Text = "Can enter only 'a-z', 'A-Z', '_' (underscore) AND 30 characters Max."
            lbl_validation_message.ForeColor = Color.Red
            'charcount = 0
            'charcount = chars.Count - 1
        End If
    End Sub

    Private Sub txt_Test_Comp_Name_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_Test_Comp_Name.KeyPress
        If Asc(e.KeyChar) = 32 Or Asc(e.KeyChar) = 96 Or (Asc(e.KeyChar) >= 33 And Asc(e.KeyChar) <= 64) Or (Asc(e.KeyChar) >= 91 And Asc(e.KeyChar) <= 94) Or (Asc(e.KeyChar) >= 123 And Asc(e.KeyChar) <= 127) Then
            checkvalidation = 1
        Else
            checkvalidation = 0
            lbl_validation_message.Text = ""
            charcount = charcount + 1
            If charcount > 29 Then
                charcount = 0
                charcount = txt_Test_Comp_Name.Text.Count
            End If
        End If
    End Sub

    Private Sub txt_Test_Comp_Name_Leave(sender As Object, e As EventArgs) Handles txt_Test_Comp_Name.Leave
        lbl_validation_message.Text = ""
    End Sub

    Private Sub bt_Create_Test_Component_Click(sender As Object, e As EventArgs) Handles bt_Create_Test_Component.Click
        If txt_Test_Comp_Name.Text = "" Then
            lbl_validation_message.Text = "             Test Component Name Should Not be Empty."
            lbl_validation_message.ForeColor = Color.Red
        ElseIf txt_Web_Object_File_Address.Text = "" Then
            lbl_validation_msg_web_object_File.Text = "       Please Select Web Objects (.properties) file."
            lbl_validation_msg_web_object_File.ForeColor = Color.Red
        Else

            'START
            Dim checkexistance As String = "select COUNT(TestComponent_Name) from Test_Component_Creation where TestComponent_Name='" + txt_Test_Comp_Name.Text + "'"
            Dim Execute_Cmd As New SqlCommand(checkexistance, cn)
            cn.Open()
            Dim FP As Integer
            FP = Execute_Cmd.ExecuteScalar()
            cn.Close()
            'END

            'To Check Whether Test_Component Exist or not
            If FP = 1 Then
                MsgBox("Already Exist..! This Test_Component already exist.", , "TC Already Exist..")
            Else
                Hidden_TV_BC.Nodes.Add(txt_Test_Comp_Name.Text)

                'MsgBox(Hidden_TV_BC.SelectedNode.Index = 0)

                Dim nodetree As TreeNode = Hidden_TV_BC.Nodes(0)
                Dim ntt As New TreeNode(txt_Test_Comp_Name.Text)
                'MsgBox(nodetree.Text)
                My.Forms.CNS_Auto_E.TV_Test_Component_List.Focus()
                My.Forms.CNS_Auto_E.TV_Test_Component_List.Nodes.Add(txt_Test_Comp_Name.Text)

                My.Forms.CNS_Auto_E.TV_Test_Component_List.SelectedNode = New TreeNode(txt_Test_Comp_Name.Text)

                My.Forms.CNS_Auto_E.TV_Test_Component_List.SelectedNode = My.Forms.CNS_Auto_E.TV_Test_Component_List.Nodes(txt_Test_Comp_Name.Text)

                GenerateFolder()

                My.Forms.Create_Component.Close()
                My.Forms.CNS_Auto_E.Show()

                My.Forms.CNS_Auto_E.bt_create_conponent.Enabled = True
                My.Forms.CNS_Auto_E.MS_Functions.Enabled = True
                My.Forms.CNS_Auto_E.bt_delete_row.Enabled = True
                My.Forms.CNS_Auto_E.bt_down.Enabled = True
                My.Forms.CNS_Auto_E.bt_up.Enabled = True
                CreateTable_Update()
                Hidden_TV_BC.Nodes.Clear()
            End If

        End If
        My.Forms.CNS_Auto_E.bt_create_conponent.Enabled = False
        My.Forms.CNS_Auto_E.bt_compile_program.Enabled = False
        My.Forms.CNS_Auto_E.bt_excel.Enabled = False
        My.Forms.CNS_Auto_E.bt_run_program.Enabled = False

    End Sub
    Sub CreateTable_Update()
        Dim createtable As String
        createtable = "Create table " + foldername + "(Object_Name nvarchar(100),Action nvarchar(200),Test_Data nvarchar(1000),Comment_Line nvarchar(30),Dev_Note nvarchar(600),Last_Updated_UserName nvarchar(120),Last_Updated_TimeDate nvarchar(120),Status nvarchar(120),RowIds nvarchar(20),IF_Condition nvarchar(1200))"
        Dim Execute_Cmd As New SqlCommand(createtable, cn)
        cn.Open()
        Execute_Cmd.ExecuteNonQuery()
        cn.Close()
    End Sub
    Sub GenerateFolder()
        foldername = txt_Test_Comp_Name.Text
        CNS_Auto_E.foldername = txt_Test_Comp_Name.Text

        'TO create Path
        If (Not System.IO.Directory.Exists(path + foldername)) Then
            System.IO.Directory.CreateDirectory(path + foldername)
        End If

        'Repository operation BC
        If System.IO.File.Exists(path + foldername + "\" + txt_Test_Comp_Name.Text + ".properties") Then
            System.IO.File.Delete(path + foldername + "\" + txt_Test_Comp_Name.Text + ".properties")
        End If


        'Create WebObject Repository Folder.
        If (Not System.IO.Directory.Exists(path + foldername + "\WebObject Repository")) Then
            System.IO.Directory.CreateDirectory(path + foldername + "\WebObject Repository")
        End If

        IO.File.Copy(OFD_Get_File.FileName.ToString, path + foldername + "\WebObject Repository\" + txt_Test_Comp_Name.Text + ".properties")

        CNS_Auto_E.RepositoryFilePath = path + foldername + "\WebObject Repository\" + txt_Test_Comp_Name.Text + ".properties"


        Dim InsertRecord As String
        Dim datetimee As String = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
        InsertRecord = "insert into Test_Component_Creation values('" + txt_Test_Comp_Name.Text + "','" + txt_Test_Component_Description.Text + "','" + path + foldername + "','" + My.User.Name.ToString + "','" + Environment.MachineName.ToString + "','" + datetimee + "')"
        Dim Execute_Cmd As New SqlCommand(InsertRecord, cn)
        cn.Open()
        Execute_Cmd.ExecuteNonQuery()
        cn.Close()

        MsgBox("Test Component Created : '" + txt_Test_Comp_Name.Text + "'",, "Test Component Created")
    End Sub
End Class