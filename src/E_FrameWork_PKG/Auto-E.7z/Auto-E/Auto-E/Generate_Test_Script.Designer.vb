﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Generate_Test_Script
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.LB_Block_Start = New System.Windows.Forms.ListBox()
        Me.LB_Block_Iterative = New System.Windows.Forms.ListBox()
        Me.LB_Block_End = New System.Windows.Forms.ListBox()
        Me.bt_M_2_Start = New System.Windows.Forms.Button()
        Me.bt_M_2_Iterative = New System.Windows.Forms.Button()
        Me.bt_M_2_End = New System.Windows.Forms.Button()
        Me.LB_Test_Components = New System.Windows.Forms.CheckedListBox()
        Me.cmb_browser = New System.Windows.Forms.ComboBox()
        Me.txt_start_iteration = New System.Windows.Forms.TextBox()
        Me.txt_end_iteration = New System.Windows.Forms.TextBox()
        Me.cmb_execution_mode = New System.Windows.Forms.ComboBox()
        Me.bt_Generate_Test_Script = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lbl_Test_Component = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txt_Test_Script_Name = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.bt_up_start_block = New System.Windows.Forms.Button()
        Me.bt_create_conponent = New System.Windows.Forms.Button()
        Me.bt_selected_remove_End = New System.Windows.Forms.Button()
        Me.bt_selected_remove_Iterative = New System.Windows.Forms.Button()
        Me.bt_selected_remove_start = New System.Windows.Forms.Button()
        Me.bt_up_iterative = New System.Windows.Forms.Button()
        Me.bt_up_end = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'LB_Block_Start
        '
        Me.LB_Block_Start.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LB_Block_Start.FormattingEnabled = True
        Me.LB_Block_Start.ItemHeight = 20
        Me.LB_Block_Start.Location = New System.Drawing.Point(396, 58)
        Me.LB_Block_Start.Name = "LB_Block_Start"
        Me.LB_Block_Start.Size = New System.Drawing.Size(150, 104)
        Me.LB_Block_Start.TabIndex = 2
        '
        'LB_Block_Iterative
        '
        Me.LB_Block_Iterative.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LB_Block_Iterative.FormattingEnabled = True
        Me.LB_Block_Iterative.ItemHeight = 20
        Me.LB_Block_Iterative.Location = New System.Drawing.Point(396, 220)
        Me.LB_Block_Iterative.Name = "LB_Block_Iterative"
        Me.LB_Block_Iterative.Size = New System.Drawing.Size(150, 104)
        Me.LB_Block_Iterative.TabIndex = 5
        '
        'LB_Block_End
        '
        Me.LB_Block_End.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LB_Block_End.FormattingEnabled = True
        Me.LB_Block_End.ItemHeight = 20
        Me.LB_Block_End.Location = New System.Drawing.Point(396, 378)
        Me.LB_Block_End.Name = "LB_Block_End"
        Me.LB_Block_End.Size = New System.Drawing.Size(150, 104)
        Me.LB_Block_End.TabIndex = 8
        '
        'bt_M_2_Start
        '
        Me.bt_M_2_Start.Font = New System.Drawing.Font("Berlin Sans FB", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt_M_2_Start.Location = New System.Drawing.Point(272, 88)
        Me.bt_M_2_Start.Name = "bt_M_2_Start"
        Me.bt_M_2_Start.Size = New System.Drawing.Size(71, 37)
        Me.bt_M_2_Start.TabIndex = 1
        Me.bt_M_2_Start.Text = ">>"
        Me.bt_M_2_Start.UseVisualStyleBackColor = True
        '
        'bt_M_2_Iterative
        '
        Me.bt_M_2_Iterative.Font = New System.Drawing.Font("Berlin Sans FB", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt_M_2_Iterative.Location = New System.Drawing.Point(272, 253)
        Me.bt_M_2_Iterative.Name = "bt_M_2_Iterative"
        Me.bt_M_2_Iterative.Size = New System.Drawing.Size(71, 37)
        Me.bt_M_2_Iterative.TabIndex = 4
        Me.bt_M_2_Iterative.Text = ">>"
        Me.bt_M_2_Iterative.UseVisualStyleBackColor = True
        '
        'bt_M_2_End
        '
        Me.bt_M_2_End.Font = New System.Drawing.Font("Berlin Sans FB", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt_M_2_End.Location = New System.Drawing.Point(272, 405)
        Me.bt_M_2_End.Name = "bt_M_2_End"
        Me.bt_M_2_End.Size = New System.Drawing.Size(71, 37)
        Me.bt_M_2_End.TabIndex = 7
        Me.bt_M_2_End.Text = ">>"
        Me.bt_M_2_End.UseVisualStyleBackColor = True
        '
        'LB_Test_Components
        '
        Me.LB_Test_Components.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LB_Test_Components.FormattingEnabled = True
        Me.LB_Test_Components.Location = New System.Drawing.Point(12, 58)
        Me.LB_Test_Components.Name = "LB_Test_Components"
        Me.LB_Test_Components.Size = New System.Drawing.Size(218, 424)
        Me.LB_Test_Components.TabIndex = 0
        '
        'cmb_browser
        '
        Me.cmb_browser.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_browser.Font = New System.Drawing.Font("Arial Narrow", 12.0!)
        Me.cmb_browser.FormattingEnabled = True
        Me.cmb_browser.Items.AddRange(New Object() {"Firefox", "Chrome", "IE", "Edge"})
        Me.cmb_browser.Location = New System.Drawing.Point(691, 58)
        Me.cmb_browser.Name = "cmb_browser"
        Me.cmb_browser.Size = New System.Drawing.Size(121, 28)
        Me.cmb_browser.TabIndex = 10
        '
        'txt_start_iteration
        '
        Me.txt_start_iteration.Font = New System.Drawing.Font("Arial Narrow", 12.0!)
        Me.txt_start_iteration.Location = New System.Drawing.Point(824, 221)
        Me.txt_start_iteration.Name = "txt_start_iteration"
        Me.txt_start_iteration.Size = New System.Drawing.Size(46, 26)
        Me.txt_start_iteration.TabIndex = 12
        '
        'txt_end_iteration
        '
        Me.txt_end_iteration.Font = New System.Drawing.Font("Arial Narrow", 12.0!)
        Me.txt_end_iteration.Location = New System.Drawing.Point(824, 272)
        Me.txt_end_iteration.Name = "txt_end_iteration"
        Me.txt_end_iteration.Size = New System.Drawing.Size(46, 26)
        Me.txt_end_iteration.TabIndex = 13
        '
        'cmb_execution_mode
        '
        Me.cmb_execution_mode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_execution_mode.Font = New System.Drawing.Font("Arial Narrow", 12.0!)
        Me.cmb_execution_mode.FormattingEnabled = True
        Me.cmb_execution_mode.Items.AddRange(New Object() {"Auto", "Manual"})
        Me.cmb_execution_mode.Location = New System.Drawing.Point(691, 128)
        Me.cmb_execution_mode.Name = "cmb_execution_mode"
        Me.cmb_execution_mode.Size = New System.Drawing.Size(121, 28)
        Me.cmb_execution_mode.TabIndex = 11
        '
        'bt_Generate_Test_Script
        '
        Me.bt_Generate_Test_Script.Font = New System.Drawing.Font("Berlin Sans FB", 15.75!)
        Me.bt_Generate_Test_Script.Location = New System.Drawing.Point(675, 435)
        Me.bt_Generate_Test_Script.Name = "bt_Generate_Test_Script"
        Me.bt_Generate_Test_Script.Size = New System.Drawing.Size(199, 44)
        Me.bt_Generate_Test_Script.TabIndex = 15
        Me.bt_Generate_Test_Script.Text = "Generate Test Script"
        Me.bt_Generate_Test_Script.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(412, 32)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(115, 23)
        Me.Label2.TabIndex = 16
        Me.Label2.Text = "START BLOCK"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(422, 352)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(100, 23)
        Me.Label3.TabIndex = 17
        Me.Label3.Text = "END BLOCK"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(398, 194)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(145, 23)
        Me.Label4.TabIndex = 18
        Me.Label4.Text = "ITERATIVE BLOCK"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Berlin Sans FB", 15.75!)
        Me.Label5.Location = New System.Drawing.Point(687, 32)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(133, 23)
        Me.Label5.TabIndex = 21
        Me.Label5.Text = "Select Browser"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Berlin Sans FB", 15.75!)
        Me.Label6.Location = New System.Drawing.Point(687, 102)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(146, 23)
        Me.Label6.TabIndex = 22
        Me.Label6.Text = "Execution Mode"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Berlin Sans FB", 15.75!)
        Me.Label7.Location = New System.Drawing.Point(676, 221)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(136, 23)
        Me.Label7.TabIndex = 23
        Me.Label7.Text = "Start Iteration:"
        '
        'lbl_Test_Component
        '
        Me.lbl_Test_Component.AutoSize = True
        Me.lbl_Test_Component.BackColor = System.Drawing.Color.Silver
        Me.lbl_Test_Component.Font = New System.Drawing.Font("Berlin Sans FB", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Test_Component.Location = New System.Drawing.Point(37, 30)
        Me.lbl_Test_Component.Name = "lbl_Test_Component"
        Me.lbl_Test_Component.Size = New System.Drawing.Size(158, 23)
        Me.lbl_Test_Component.TabIndex = 25
        Me.lbl_Test_Component.Text = "Test Components"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Berlin Sans FB", 15.75!)
        Me.Label1.Location = New System.Drawing.Point(676, 272)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(127, 23)
        Me.Label1.TabIndex = 26
        Me.Label1.Text = "End Iteration:"
        '
        'txt_Test_Script_Name
        '
        Me.txt_Test_Script_Name.Font = New System.Drawing.Font("Arial Narrow", 12.0!)
        Me.txt_Test_Script_Name.Location = New System.Drawing.Point(680, 375)
        Me.txt_Test_Script_Name.Name = "txt_Test_Script_Name"
        Me.txt_Test_Script_Name.Size = New System.Drawing.Size(190, 26)
        Me.txt_Test_Script_Name.TabIndex = 14
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Berlin Sans FB", 15.75!)
        Me.Label8.Location = New System.Drawing.Point(676, 349)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(167, 23)
        Me.Label8.TabIndex = 32
        Me.Label8.Text = "Test Script Name :"
        '
        'bt_up_start_block
        '
        Me.bt_up_start_block.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt_up_start_block.Location = New System.Drawing.Point(552, 112)
        Me.bt_up_start_block.Name = "bt_up_start_block"
        Me.bt_up_start_block.Size = New System.Drawing.Size(29, 34)
        Me.bt_up_start_block.TabIndex = 34
        Me.bt_up_start_block.Text = "↑"
        Me.bt_up_start_block.UseVisualStyleBackColor = True
        '
        'bt_create_conponent
        '
        Me.bt_create_conponent.Font = New System.Drawing.Font("Candara", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt_create_conponent.Image = Global.Auto_E.My.ResourcesRepair.Resources._1490183723_Cancel
        Me.bt_create_conponent.Location = New System.Drawing.Point(846, 12)
        Me.bt_create_conponent.Name = "bt_create_conponent"
        Me.bt_create_conponent.Size = New System.Drawing.Size(42, 41)
        Me.bt_create_conponent.TabIndex = 33
        Me.bt_create_conponent.UseVisualStyleBackColor = True
        '
        'bt_selected_remove_End
        '
        Me.bt_selected_remove_End.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt_selected_remove_End.Image = Global.Auto_E.My.ResourcesRepair.Resources.free
        Me.bt_selected_remove_End.Location = New System.Drawing.Point(552, 393)
        Me.bt_selected_remove_End.Name = "bt_selected_remove_End"
        Me.bt_selected_remove_End.Size = New System.Drawing.Size(29, 34)
        Me.bt_selected_remove_End.TabIndex = 9
        Me.bt_selected_remove_End.UseVisualStyleBackColor = True
        '
        'bt_selected_remove_Iterative
        '
        Me.bt_selected_remove_Iterative.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt_selected_remove_Iterative.Image = Global.Auto_E.My.ResourcesRepair.Resources.free
        Me.bt_selected_remove_Iterative.Location = New System.Drawing.Point(552, 235)
        Me.bt_selected_remove_Iterative.Name = "bt_selected_remove_Iterative"
        Me.bt_selected_remove_Iterative.Size = New System.Drawing.Size(29, 34)
        Me.bt_selected_remove_Iterative.TabIndex = 6
        Me.bt_selected_remove_Iterative.UseVisualStyleBackColor = True
        '
        'bt_selected_remove_start
        '
        Me.bt_selected_remove_start.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt_selected_remove_start.Image = Global.Auto_E.My.ResourcesRepair.Resources.free
        Me.bt_selected_remove_start.Location = New System.Drawing.Point(552, 72)
        Me.bt_selected_remove_start.Name = "bt_selected_remove_start"
        Me.bt_selected_remove_start.Size = New System.Drawing.Size(29, 34)
        Me.bt_selected_remove_start.TabIndex = 3
        Me.bt_selected_remove_start.UseVisualStyleBackColor = True
        '
        'bt_up_iterative
        '
        Me.bt_up_iterative.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt_up_iterative.Location = New System.Drawing.Point(552, 276)
        Me.bt_up_iterative.Name = "bt_up_iterative"
        Me.bt_up_iterative.Size = New System.Drawing.Size(29, 34)
        Me.bt_up_iterative.TabIndex = 35
        Me.bt_up_iterative.Text = "↑"
        Me.bt_up_iterative.UseVisualStyleBackColor = True
        '
        'bt_up_end
        '
        Me.bt_up_end.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt_up_end.Location = New System.Drawing.Point(552, 433)
        Me.bt_up_end.Name = "bt_up_end"
        Me.bt_up_end.Size = New System.Drawing.Size(29, 34)
        Me.bt_up_end.TabIndex = 36
        Me.bt_up_end.Text = "↑"
        Me.bt_up_end.UseVisualStyleBackColor = True
        '
        'Generate_Test_Script
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(901, 500)
        Me.Controls.Add(Me.bt_up_end)
        Me.Controls.Add(Me.bt_up_iterative)
        Me.Controls.Add(Me.bt_up_start_block)
        Me.Controls.Add(Me.bt_create_conponent)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.txt_Test_Script_Name)
        Me.Controls.Add(Me.bt_selected_remove_End)
        Me.Controls.Add(Me.bt_selected_remove_Iterative)
        Me.Controls.Add(Me.bt_selected_remove_start)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lbl_Test_Component)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.bt_Generate_Test_Script)
        Me.Controls.Add(Me.cmb_execution_mode)
        Me.Controls.Add(Me.txt_end_iteration)
        Me.Controls.Add(Me.txt_start_iteration)
        Me.Controls.Add(Me.cmb_browser)
        Me.Controls.Add(Me.bt_M_2_End)
        Me.Controls.Add(Me.bt_M_2_Iterative)
        Me.Controls.Add(Me.bt_M_2_Start)
        Me.Controls.Add(Me.LB_Block_End)
        Me.Controls.Add(Me.LB_Block_Iterative)
        Me.Controls.Add(Me.LB_Test_Components)
        Me.Controls.Add(Me.LB_Block_Start)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Generate_Test_Script"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Generate_Test_Script"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents LB_Block_Start As ListBox
    Friend WithEvents LB_Block_Iterative As ListBox
    Friend WithEvents LB_Block_End As ListBox
    Friend WithEvents bt_M_2_Start As Button
    Friend WithEvents bt_M_2_Iterative As Button
    Friend WithEvents bt_M_2_End As Button
    Friend WithEvents LB_Test_Components As CheckedListBox
    Friend WithEvents cmb_browser As ComboBox
    Friend WithEvents txt_start_iteration As TextBox
    Friend WithEvents txt_end_iteration As TextBox
    Friend WithEvents cmb_execution_mode As ComboBox
    Friend WithEvents bt_Generate_Test_Script As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents lbl_Test_Component As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents bt_selected_remove_start As Button
    Friend WithEvents bt_selected_remove_Iterative As Button
    Friend WithEvents bt_selected_remove_End As Button
    Friend WithEvents txt_Test_Script_Name As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents bt_create_conponent As Button
    Friend WithEvents bt_up_start_block As Button
    Friend WithEvents bt_up_iterative As Button
    Friend WithEvents bt_up_end As Button
End Class
