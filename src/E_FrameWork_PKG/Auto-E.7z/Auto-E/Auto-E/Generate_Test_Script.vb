﻿Imports System.Data.SqlClient
Imports System.IO
Imports Microsoft.Office.Interop.Excel
Imports Excel = Microsoft.Office.Interop.Excel
Public Class Generate_Test_Script
    'DataBase
    Dim cn As SqlConnection
    Dim cmd As SqlCommand
    Dim da As SqlDataAdapter
    Dim bm As BindingManagerBase
    Dim ds As New Data.DataSet

    Public path, foldername As String

    Dim b_start As String()
    Dim b_iterative As String()
    Dim b_end As String()
    Dim TSLocation As String

    'Declaration of Excel Objects
    Dim appXL As Excel.Application
    Dim wbXl As Excel.Workbook
    Dim shXL As Excel.Worksheet
    Dim raXL As Excel.Range

    Dim Runme_Properties, runme As System.IO.StreamWriter
    Private Sub Generate_Test_Script_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        path = My.Forms.CNS_Auto_E.GetProject_FolderPath()

        'START : DB SECTION
        'IN-USE''' cn = New SqlConnection("Server=CNS10\E_MSSQLSERVER;Database=Auto_E_DB;User ID=sa;Password=user@123;Trusted_Connection=True;")
        cn = New SqlConnection("Server=db;Database=Auto_E;Integrated Security=SSPI;")
        cmd = New SqlCommand("select * from Test_Component_Creation", cn)
        da = New SqlDataAdapter(cmd)
        da.Fill(ds)
        bm = Me.BindingContext(ds.Tables(0))
        'END : DB SECTION

        Get_Test_Components_List()
    End Sub

    Private Sub bt_M_2_Start_Click(sender As Object, e As EventArgs) Handles bt_M_2_Start.Click
        Dim selecteditems As Integer = LB_Test_Components.CheckedItems.Count

        For i = 0 To selecteditems - 1
            LB_Block_Start.Items.Add(LB_Test_Components.CheckedItems.Item(i).ToString())
        Next
        uncheck_Test_Component_List()
    End Sub

    Private Sub bt_M_2_Iterative_Click(sender As Object, e As EventArgs) Handles bt_M_2_Iterative.Click
        Dim selecteditems As Integer = LB_Test_Components.CheckedItems.Count

        For i = 0 To selecteditems - 1
            LB_Block_Iterative.Items.Add(LB_Test_Components.CheckedItems.Item(i).ToString())
        Next
        uncheck_Test_Component_List()
    End Sub

    Private Sub bt_M_2_End_Click(sender As Object, e As EventArgs) Handles bt_M_2_End.Click
        Dim selecteditems As Integer = LB_Test_Components.CheckedItems.Count

        For i = 0 To selecteditems - 1
            LB_Block_End.Items.Add(LB_Test_Components.CheckedItems.Item(i).ToString())
        Next
        uncheck_Test_Component_List()
    End Sub

    Sub Get_Test_Components_List()
        Dim propertyList As New List(Of String)()

        For i = 0 To ds.Tables(0).Rows.Count - 1
            propertyList.Add(ds.Tables(0).Rows(i)("TestComponent_Name").ToString)
        Next

        For i = 0 To ds.Tables(0).Rows.Count - 1
            LB_Test_Components.Items.Add(propertyList(i))
        Next
    End Sub

    Sub uncheck_Test_Component_List()
        Dim selecteditems As Integer = LB_Test_Components.Items.Count
        For i = 0 To selecteditems - 1
            LB_Test_Components.SetItemCheckState(i, False)
        Next
    End Sub


    Private Sub txt_start_iteration_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_start_iteration.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            'MessageBox.Show("Please enter numbers only")
            e.Handled = True
        End If
    End Sub

    Private Sub bt_delete_row_Click(sender As Object, e As EventArgs) Handles bt_selected_remove_start.Click
        If LB_Block_Start.SelectedIndex <> -1 Then
            LB_Block_Start.Items.Remove(LB_Block_Start.SelectedItem.ToString())
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles bt_selected_remove_Iterative.Click
        If LB_Block_Iterative.SelectedIndex <> -1 Then
            LB_Block_Iterative.Items.Remove(LB_Block_Iterative.SelectedItem.ToString())
        End If
    End Sub

    Private Sub bt_selected_remove_End_Click_1(sender As Object, e As EventArgs) Handles bt_selected_remove_End.Click
        If LB_Block_End.SelectedIndex <> -1 Then
            LB_Block_End.Items.Remove(LB_Block_End.SelectedItem.ToString())
        End If
    End Sub

    Private Sub bt_Generate_Test_Script_Click(sender As Object, e As EventArgs) Handles bt_Generate_Test_Script.Click
        'START : CHECK ALL BLOCK (NOT BLANK)
        If (LB_Block_Start.Items.Count = 0 And LB_Block_Iterative.Items.Count = 0 And LB_Block_End.Items.Count = 0) Then
            MsgBox("Select Test Component For Any Block.",, "Select TC for Any Block")
        ElseIf cmb_browser.Text = "" Then
            MsgBox("Select Browser",, "Browser")
        ElseIf cmb_execution_mode.Text = "" Then
            MsgBox("Select Execution Mode.",, "Execution Mode")
        ElseIf txt_start_iteration.Text = "" Or txt_end_iteration.Text = "" Then
            MsgBox("Iteration START/END Value Should Not Be Blank.",, "Invalid Iteration Input")
        ElseIf CInt(txt_end_iteration.Text) < CInt(txt_start_iteration.Text) Then
            MsgBox("End Iteration Value Cannot Be Less Then Start Iteration Value.",, "Iteration Value Validation")
        ElseIf txt_Test_Script_Name.Text = "" Then
            MsgBox("Test Script Name Should Not Be Empty.",, "Test Script Name Validation")
        Else
            path = My.Forms.CNS_Auto_E.GetProject_FolderPath()

            'START : CHECK WHETHER TEST SCRIPT FOLDER AVAILABLE.
            If (Not System.IO.Directory.Exists(path + "\TEST SCRIPT")) Then
                System.IO.Directory.CreateDirectory(path + "\TEST SCRIPT")
            End If
            'END : CHECK WHETHER TEST SCRIPT FOLDER AVAILABLE.



            'START : CREATE FOLDER IF NOT EXIST | AND CREATE TEST SCRIPT DIRECTORY. 
            If (Not System.IO.Directory.Exists(path + "\TEST SCRIPT")) Then
                System.IO.Directory.CreateDirectory(path + "\TEST SCRIPT")
            End If

            If (System.IO.Directory.Exists(path + "\TEST SCRIPT\" + txt_Test_Script_Name.Text)) Then
                Directory.Delete(path + "\TEST SCRIPT\" + txt_Test_Script_Name.Text, True)
            End If

            If (Not System.IO.Directory.Exists(path + "\TEST SCRIPT\" + txt_Test_Script_Name.Text)) Then
                System.IO.Directory.CreateDirectory(path + "\TEST SCRIPT\" + txt_Test_Script_Name.Text)
            End If
            'END : CREATE FOLDER IF NOT EXIST | AND CREATE TEST SCRIPT DIRECTORY.

            TSLocation = path + "\TEST SCRIPT\" + txt_Test_Script_Name.Text

            If (Not System.IO.Directory.Exists(TSLocation + "\Package")) Then
                System.IO.Directory.CreateDirectory(TSLocation + "\Package")
            End If

            If (Not System.IO.Directory.Exists(TSLocation + "\Result")) Then
                System.IO.Directory.CreateDirectory(TSLocation + "\Result")
            End If

            If (Not System.IO.Directory.Exists(TSLocation + "\Test Data")) Then
                System.IO.Directory.CreateDirectory(TSLocation + "\Test Data")
            End If

            If (Not System.IO.Directory.Exists(TSLocation + "\WebObject Repository")) Then
                System.IO.Directory.CreateDirectory(TSLocation + "\WebObject Repository")
            End If

            check_items_in_all_Blocks()

            Generate_Runme_Properties()

            Generate_Main_Class()


            Generate_Compilation_Bat()

            Generate_TS_Folder_2_Local_M()

            Directory.Delete(TSLocation, True)

            Execute_BAT()
            MsgBox("Test Script Generated..!")
            Process.Start("C:\E_FrameWork\Test Script\" + txt_Test_Script_Name.Text)
        End If

        'END : CHECK ALL BLOCK (NOT BLANK)
    End Sub
    Sub check_items_in_all_Blocks()
        Generate_Excel(txt_Test_Script_Name.Text)

        If LB_Block_Start.Items.Count <> 0 Then
            For i = 0 To LB_Block_Start.Items.Count - 1


                'START : GET FOLDER PATH
                Dim get_Path_Query As String = "select Folder_Path from Test_Component_Creation where TestComponent_Name='" + LB_Block_Start.Items(i).ToString() + "'"
                Dim Execute_Cmd As New SqlCommand(get_Path_Query, cn)
                cn.Open()
                Dim FP As String = Execute_Cmd.ExecuteScalar()
                cn.Close()
                'END : GET FOLDER PATH

                My.Computer.FileSystem.CopyDirectory(FP + "\Package", TSLocation + "\Package", True)
                ' My.Computer.FileSystem.CopyDirectory(FP + "\Test Data", TSLocation + "\Test Data", True)
                My.Computer.FileSystem.CopyDirectory(FP + "\WebObject Repository", TSLocation + "\WebObject Repository", True)

                ' b_start(i) = LB_Block_Start.Items(i).ToString()
                Move_Sheets(TSLocation + "\Test Data\" + txt_Test_Script_Name.Text + ".xlsx", txt_Test_Script_Name.Text, FP + "\Test Data\" + LB_Block_Start.Items(i).ToString() + ".xlsx")
            Next
        End If

        If LB_Block_Iterative.Items.Count <> 0 Then
            For i = 0 To LB_Block_Iterative.Items.Count - 1


                'START : GET FOLDER PATH
                Dim get_Path_Query As String = "select Folder_Path from Test_Component_Creation where TestComponent_Name='" + LB_Block_Iterative.Items(i).ToString() + "'"
                Dim Execute_Cmd As New SqlCommand(get_Path_Query, cn)
                cn.Open()
                Dim FP As String = Execute_Cmd.ExecuteScalar()
                cn.Close()
                'END : GET FOLDER PATH

                My.Computer.FileSystem.CopyDirectory(FP + "\Package", TSLocation + "\Package", True)
                ' My.Computer.FileSystem.CopyDirectory(FP + "\Test Data", TSLocation + "\Test Data", True)
                My.Computer.FileSystem.CopyDirectory(FP + "\WebObject Repository", TSLocation + "\WebObject Repository", True)

                Move_Sheets(TSLocation + "\Test Data\" + txt_Test_Script_Name.Text + ".xlsx", txt_Test_Script_Name.Text, FP + "\Test Data\" + LB_Block_Iterative.Items(i).ToString() + ".xlsx")
                'b_iterative(i) = LB_Block_Iterative.Items(i).ToString()
            Next
        End If

        If LB_Block_End.Items.Count <> 0 Then
            For i = 0 To LB_Block_End.Items.Count - 1


                'START : GET FOLDER PATH
                Dim get_Path_Query As String = "select Folder_Path from Test_Component_Creation where TestComponent_Name='" + LB_Block_End.Items(i).ToString() + "'"
                Dim Execute_Cmd As New SqlCommand(get_Path_Query, cn)
                cn.Open()
                Dim FP As String = Execute_Cmd.ExecuteScalar()
                cn.Close()
                'END : GET FOLDER PATH

                My.Computer.FileSystem.CopyDirectory(FP + "\Package", TSLocation + "\Package", True)
                'My.Computer.FileSystem.CopyDirectory(FP + "\Test Data", TSLocation + "\Test Data", True)
                My.Computer.FileSystem.CopyDirectory(FP + "\WebObject Repository", TSLocation + "\WebObject Repository", True)


                Move_Sheets(TSLocation + "\Test Data\" + txt_Test_Script_Name.Text + ".xlsx", txt_Test_Script_Name.Text, FP + "\Test Data\" + LB_Block_End.Items(i).ToString() + ".xlsx")
                'b_end(i) = LB_Block_End.Items(i).ToString()
            Next
        End If

    End Sub
    Sub Generate_Excel(SheetFileName As String)

        appXL = CreateObject("Excel.Application")
        appXL.Visible = False


        If System.IO.File.Exists(TSLocation + "\Test Data\" + SheetFileName + ".xlsx") Then
            'Already Exist
            wbXl = appXL.Workbooks.Open(TSLocation)
            appXL.DisplayAlerts = False
            'shXL = wbXl.Sheets
            shXL = wbXl.Sheets(SheetFileName)
            shXL.Name = SheetFileName
            shXL = wbXl.ActiveSheet
        Else
            ' Add a new workbook.
            wbXl = appXL.Workbooks.Add
            appXL.DisplayAlerts = False
            'shXL = wbXl.Sheets
            shXL = wbXl.Sheets("Sheet1")
            shXL.Name = SheetFileName
            shXL = wbXl.ActiveSheet
            wbXl.SaveAs(TSLocation + "\Test Data\" + SheetFileName + ".xlsx")


        End If
        wbXl.Close()
    End Sub
    Sub Move_Sheets(Source_Book As String, SheetName As String, Desntination_Book As String)
        'wbXl = appXL.Workbooks.Open(TSLocation + "\Test Data\" + Source_Book + ".xlsx")
        wbXl = appXL.Workbooks.Open(Source_Book)
        shXL = wbXl.Sheets(SheetName)

        Dim wbXll As Excel.Workbook
        'Dim shXLl As Excel.Worksheet

        'wbXll = appXL.Workbooks.Open(TSLocation + "\Test Data\" + Desntination_Book + ".xlsx")
        wbXll = appXL.Workbooks.Open(Desntination_Book)
        wbXll.Worksheets.Copy(shXL)

        wbXl.Save()
        wbXll.Save()

        wbXl.Close()
        wbXll.Close()
    End Sub
    Sub Generate_Runme_Properties()
        Dim utf8 As New System.Text.UTF8Encoding(False)

        'if exist delete old
        If System.IO.File.Exists(TSLocation + "\WebObject Repository\RunMe.properties") Then
            System.IO.File.Delete(TSLocation + "\WebObject Repository\RunMe.properties")
        End If

        Runme_Properties = My.Computer.FileSystem.OpenTextFileWriter(TSLocation + "\WebObject Repository\RunMe.properties", True, utf8)

        'START:CHECK BROWSER
        If cmb_browser.SelectedItem.ToString = "Firefox" Then
            Runme_Properties.WriteLine("Browser=1")
        ElseIf cmb_browser.SelectedItem.ToString = "IE" Then
            Runme_Properties.WriteLine("Browser=2")
        ElseIf cmb_browser.SelectedItem.ToString = "Chrome" Then
            Runme_Properties.WriteLine("Browser=3")
        ElseIf cmb_browser.SelectedItem.ToString = "Edge" Then
            Runme_Properties.WriteLine("Browser=4")
        End If
        'END : CHECK BROWSER

        'START:CHECK Execution Mode
        If cmb_execution_mode.SelectedItem.ToString = "Auto" Then
            Runme_Properties.WriteLine("ExeutionMode=1")
        ElseIf cmb_execution_mode.SelectedItem.ToString = "Manual" Then
            Runme_Properties.WriteLine("ExeutionMode=0")
        End If
        'END:CHECK Execution Mode

        Runme_Properties.WriteLine("StartIteration=" + txt_start_iteration.Text)
        Runme_Properties.WriteLine("EndIteration=" + txt_end_iteration.Text)

        Runme_Properties.Close()

    End Sub
    Private Sub txt_end_iteration_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_end_iteration.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            'MessageBox.Show("Please enter numbers only")
            e.Handled = True
        End If
    End Sub
    Sub Generate_Main_Class()
        Dim utf8 As New System.Text.UTF8Encoding(False)
        'if exist delete old
        If System.IO.File.Exists(TSLocation + "\E_RunMe.java") Then
            System.IO.File.Delete(TSLocation + "\E_RunMe.java")
        End If
        runme = My.Computer.FileSystem.OpenTextFileWriter(TSLocation + "\E_RunMe.java", True, utf8)

        runme.WriteLine("import java.io.*;")
        runme.WriteLine("import java.util.Properties;")
        runme.WriteLine("import E_FrameWork_PKG.*;")
        runme.WriteLine("import Package.*;" + vbNewLine)

        runme.WriteLine("public class E_RunMe")
        runme.WriteLine("{")

        runme.WriteLine(vbTab + "public static void main(String args[]) throws Exception")
        runme.WriteLine(vbTab + "{")

        runme.WriteLine(vbTab + vbTab + "int ExeutionMode,start,end,browserr;" + vbNewLine)

        runme.WriteLine(vbTab + vbTab + "//Object properties Variables ")
        runme.WriteLine(vbTab + vbTab + "Properties objpro = null;")
        runme.WriteLine(vbTab + vbTab + "FileInputStream objfile;" + vbNewLine)

        runme.WriteLine(vbTab + vbTab + "//Get Default Folder Path")
        runme.WriteLine(vbTab + vbTab + "File currentDirectory = new File(new File(""."").getAbsolutePath());")
        runme.WriteLine(vbTab + vbTab + "final String dir = currentDirectory.getCanonicalPath()+""\\"";" + vbNewLine)

        runme.WriteLine(vbTab + vbTab + "try")
        runme.WriteLine(vbTab + vbTab + "{")

        runme.WriteLine(vbTab + vbTab + vbTab + "objpro = new Properties();")
        runme.WriteLine(vbTab + vbTab + vbTab + "objfile = new FileInputStream(dir+""\\WebObject Repository\\RunMe.properties"");")
        runme.WriteLine(vbTab + vbTab + vbTab + "objpro.load(objfile); ")
        runme.WriteLine(vbTab + vbTab + vbTab + "ExeutionMode=Integer.parseInt(objpro.getProperty(""ExeutionMode""));")
        runme.WriteLine(vbTab + vbTab + vbTab + "start=Integer.parseInt(objpro.getProperty(""StartIteration""));")
        runme.WriteLine(vbTab + vbTab + vbTab + "end=Integer.parseInt(objpro.getProperty(""EndIteration""));")
        runme.WriteLine(vbTab + vbTab + vbTab + "browserr=Integer.parseInt(objpro.getProperty(""Browser""));")

        runme.WriteLine(vbTab + vbTab + "}catch(java.io.FileNotFoundException FNFE)")
        runme.WriteLine(vbTab + vbTab + "{")
        runme.WriteLine(vbTab + vbTab + vbTab + "browserr=1;")
        runme.WriteLine(vbTab + vbTab + vbTab + "ExeutionMode=0;")
        runme.WriteLine(vbTab + vbTab + vbTab + "start=1;")
        runme.WriteLine(vbTab + vbTab + vbTab + "end=1;")
        runme.WriteLine(vbTab + vbTab + "}" + vbNewLine)

        runme.WriteLine(vbTab + vbTab + "E_FrameWork driver = new E_FrameWork();" + vbNewLine)

        'Create Test Data Folder for File
        runme.WriteLine(vbTab + vbTab + "driver.E_Browser_Selection(browserr);")
        runme.WriteLine(vbTab + vbTab + "driver.ETestData_File(dir+""\\Test Data\\" + txt_Test_Script_Name.Text + ".xlsx"");")

        'runme.WriteLine(vbTab + vbTab + "driver.EReport_CreateHTMLReport(dir+""\\Result\\""+""Test Script Execution"");" + vbNewLine)
        runme.WriteLine(vbTab + vbTab + "driver.EReport_CreateHTMLReport(dir+""\\Result\\""+""" + txt_Test_Script_Name.Text + ", Its a TEST SCRIPT"");" + vbNewLine)

        If LB_Block_Start.Items.Count <> 0 Then
            For i = 0 To LB_Block_Start.Items.Count - 1
                runme.WriteLine(vbTab + vbTab + LB_Block_Start.Items(i).ToString() + ".RunFunc(driver,""" + LB_Block_Start.Items(i).ToString() + """,ExeutionMode,start);")
            Next
        End If

        runme.WriteLine(vbTab + vbTab + "for(int i=start;i<=end;i++)")
        runme.WriteLine(vbTab + vbTab + "{")
        If LB_Block_Iterative.Items.Count <> 0 Then
            For i = 0 To LB_Block_Iterative.Items.Count - 1
                runme.WriteLine(vbTab + vbTab + vbTab + LB_Block_Iterative.Items(i).ToString() + ".RunFunc(driver,""" + LB_Block_Iterative.Items(i).ToString() + """,ExeutionMode,i);")
            Next
        End If

        runme.WriteLine(vbTab + vbTab + "}" + vbNewLine)

        If LB_Block_End.Items.Count <> 0 Then
            For i = 0 To LB_Block_End.Items.Count - 1
                runme.WriteLine(vbTab + vbTab + LB_Block_End.Items(i).ToString() + ".RunFunc(driver,""" + LB_Block_End.Items(i).ToString() + """,ExeutionMode,start);")
            Next
        End If
        runme.WriteLine(vbTab + vbTab + "//FINAL Section")
        runme.WriteLine(vbTab + vbTab + "driver.Efile_CloseALL();" + vbNewLine)

        runme.WriteLine(vbTab + vbTab + "System.out.println(""\n\nScript Execution Completed"");")

        runme.WriteLine(vbTab + "}")

        runme.WriteLine("}")
        runme.Close()
    End Sub
    Sub Generate_Compilation_Bat()
        Dim utf8 As New System.Text.UTF8Encoding(False)
        Using sw As System.IO.StreamWriter = New System.IO.StreamWriter(TSLocation + "\Compile.bat", True, utf8)
            sw.WriteLine("@ECHO OFF")
            'sw.WriteLine("set CLASSPATH=%CLASSPATH%;")
            'sw.WriteLine("pushd " + TSLocation)
            'sw.WriteLine("chdir /d " + TSLocation)
            'sw.WriteLine("cls")
            sw.WriteLine("javac E_RunMe.java")
            sw.WriteLine("popd")
            sw.WriteLine("echo Successfully Compiled.")
            sw.Write("pause")
            sw.Close()
        End Using


        Using sw As System.IO.StreamWriter = New System.IO.StreamWriter(TSLocation + "\Run.bat", True, utf8)
            sw.WriteLine("@ECHO OFF")
            'sw.WriteLine("pushd " + TSLocation)
            'sw.WriteLine("chdir /d " + TSLocation)
            'sw.WriteLine("cls")
            sw.WriteLine("java E_RunMe")
            sw.WriteLine("popd")
            sw.Write("pause")
            sw.Close()
        End Using
    End Sub
    Sub Generate_TS_Folder_2_Local_M()

        If (Not System.IO.Directory.Exists("C:\E_FrameWork\Test Script")) Then
            System.IO.Directory.CreateDirectory("C:\E_FrameWork\Test Script")
        End If

        If (Not System.IO.Directory.Exists("C:\E_FrameWork\Test Script\" + txt_Test_Script_Name.Text)) Then
            System.IO.Directory.CreateDirectory("C:\E_FrameWork\Test Script\" + txt_Test_Script_Name.Text)
        Else
            Directory.Delete("C:\E_FrameWork\Test Script\" + txt_Test_Script_Name.Text, True)
        End If

        My.Computer.FileSystem.CopyDirectory(TSLocation, "C:\E_FrameWork\Test Script\" + txt_Test_Script_Name.Text, True)
    End Sub
    Private Sub bt_create_conponent_Click(sender As Object, e As EventArgs) Handles bt_create_conponent.Click
        My.Forms.Generate_Test_Script.Close()
        My.Forms.CNS_Auto_E.Refresh()
        CNS_Auto_E.Show()




        'AddHandler bt_create_conponent.Click, AddressOf My.Forms.CNS_Auto_E.TV_Test_Component_List.AfterSelect
    End Sub

    Private Sub bt_up_start_block_Click(sender As Object, e As EventArgs) Handles bt_up_start_block.Click
        If LB_Block_Start.Items.Count > 1 Then
            Dim item As Object
            Dim index As Integer
            item = LB_Block_Start.SelectedItem()
            index = LB_Block_Start.Items.IndexOf(item)
            If (index - 1) >= 0 Then
                LB_Block_Start.Items.Insert(index - 1, item)
                LB_Block_Start.SelectedIndex = index - 1
                LB_Block_Start.Items.RemoveAt(index + 1)
            End If

        End If

    End Sub

    Private Sub bt_up_iterative_Click(sender As Object, e As EventArgs) Handles bt_up_iterative.Click
        If LB_Block_Iterative.Items.Count > 1 Then
            Dim item As Object
            Dim index As Integer
            item = LB_Block_Iterative.SelectedItem()
            index = LB_Block_Iterative.Items.IndexOf(item)
            If (index - 1) >= 0 Then
                LB_Block_Iterative.Items.Insert(index - 1, item)
                LB_Block_Iterative.SelectedIndex = index - 1
                LB_Block_Iterative.Items.RemoveAt(index + 1)
            End If

        End If
    End Sub

    Private Sub bt_up_end_Click(sender As Object, e As EventArgs) Handles bt_up_end.Click
        If LB_Block_End.Items.Count > 1 Then
            Dim item As Object
            Dim index As Integer
            item = LB_Block_End.SelectedItem()
            index = LB_Block_End.Items.IndexOf(item)
            If (index - 1) >= 0 Then
                LB_Block_End.Items.Insert(index - 1, item)
                LB_Block_End.SelectedIndex = index - 1
                LB_Block_End.Items.RemoveAt(index + 1)
            End If

        End If
    End Sub



    Sub Execute_BAT()
        ' MsgBox("C:\E_FrameWork\Test Script\" + txt_Test_Script_Name.Text + "\Compile.bat")
        ' Process.Start("C:\E_FrameWork\Test Script\" + txt_Test_Script_Name.Text + "\Compile.bat")

        Dim proc As Process = Nothing
        proc = New Process()
        proc.StartInfo.WorkingDirectory = "C:\E_FrameWork\Test Script\" + txt_Test_Script_Name.Text
        proc.StartInfo.FileName = "Compile.bat"
        proc.StartInfo.CreateNoWindow = False
        proc.Start()
        proc.WaitForExit()
    End Sub
    Private Sub txt_Test_Script_Name_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_Test_Script_Name.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            If Not ((Asc(e.KeyChar) >= 97 And Asc(e.KeyChar) <= 122) Or (Asc(e.KeyChar) >= 65 And Asc(e.KeyChar) <= 90) Or (Asc(e.KeyChar) = 95)) Then
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub
End Class