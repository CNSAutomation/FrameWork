﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class IF_Form
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cmb_Conditions_List = New System.Windows.Forms.ComboBox()
        Me.txt_Expression = New System.Windows.Forms.TextBox()
        Me.txt_condition = New System.Windows.Forms.TextBox()
        Me.bt_save = New System.Windows.Forms.Button()
        Me.rb_object_condition = New System.Windows.Forms.RadioButton()
        Me.rb_expression_condition = New System.Windows.Forms.RadioButton()
        Me.lbl_oc_web_objects = New System.Windows.Forms.Label()
        Me.lbl_oc_condition = New System.Windows.Forms.Label()
        Me.lbl_ec_expression = New System.Windows.Forms.Label()
        Me.lbl_ex_condition = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.LB_Object_List = New System.Windows.Forms.ListBox()
        Me.lbl_oc_IS = New System.Windows.Forms.Label()
        Me.cmb_Operator = New System.Windows.Forms.ComboBox()
        Me.cmb_another_conditions = New System.Windows.Forms.ComboBox()
        Me.bt_update = New System.Windows.Forms.Button()
        Me.lb_View = New System.Windows.Forms.ListBox()
        Me.bt_up_View_Condition = New System.Windows.Forms.Button()
        Me.bt_Delete_View = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'cmb_Conditions_List
        '
        Me.cmb_Conditions_List.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_Conditions_List.Enabled = False
        Me.cmb_Conditions_List.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmb_Conditions_List.FormattingEnabled = True
        Me.cmb_Conditions_List.Items.AddRange(New Object() {"IS_VISIBLE", "IS_NOT_VISIBLE", "IS_EXIST", "IS_NOT_EXIST"})
        Me.cmb_Conditions_List.Location = New System.Drawing.Point(11, 288)
        Me.cmb_Conditions_List.Name = "cmb_Conditions_List"
        Me.cmb_Conditions_List.Size = New System.Drawing.Size(195, 26)
        Me.cmb_Conditions_List.TabIndex = 1
        Me.cmb_Conditions_List.Visible = False
        '
        'txt_Expression
        '
        Me.txt_Expression.Enabled = False
        Me.txt_Expression.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Expression.Location = New System.Drawing.Point(273, 145)
        Me.txt_Expression.Name = "txt_Expression"
        Me.txt_Expression.Size = New System.Drawing.Size(196, 26)
        Me.txt_Expression.TabIndex = 2
        Me.txt_Expression.Visible = False
        '
        'txt_condition
        '
        Me.txt_condition.Enabled = False
        Me.txt_condition.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_condition.Location = New System.Drawing.Point(273, 243)
        Me.txt_condition.Name = "txt_condition"
        Me.txt_condition.Size = New System.Drawing.Size(195, 26)
        Me.txt_condition.TabIndex = 3
        Me.txt_condition.Visible = False
        '
        'bt_save
        '
        Me.bt_save.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Bold)
        Me.bt_save.Location = New System.Drawing.Point(190, 492)
        Me.bt_save.Name = "bt_save"
        Me.bt_save.Size = New System.Drawing.Size(107, 34)
        Me.bt_save.TabIndex = 4
        Me.bt_save.Text = "Save"
        Me.bt_save.UseVisualStyleBackColor = True
        '
        'rb_object_condition
        '
        Me.rb_object_condition.AutoSize = True
        Me.rb_object_condition.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Bold)
        Me.rb_object_condition.Location = New System.Drawing.Point(24, 59)
        Me.rb_object_condition.Name = "rb_object_condition"
        Me.rb_object_condition.Size = New System.Drawing.Size(183, 27)
        Me.rb_object_condition.TabIndex = 6
        Me.rb_object_condition.TabStop = True
        Me.rb_object_condition.Text = "OBJECT CONDITION"
        Me.rb_object_condition.UseVisualStyleBackColor = True
        '
        'rb_expression_condition
        '
        Me.rb_expression_condition.AutoSize = True
        Me.rb_expression_condition.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Bold)
        Me.rb_expression_condition.Location = New System.Drawing.Point(255, 59)
        Me.rb_expression_condition.Name = "rb_expression_condition"
        Me.rb_expression_condition.Size = New System.Drawing.Size(223, 27)
        Me.rb_expression_condition.TabIndex = 7
        Me.rb_expression_condition.TabStop = True
        Me.rb_expression_condition.Text = "EXPRESSION CONDITION"
        Me.rb_expression_condition.UseVisualStyleBackColor = True
        '
        'lbl_oc_web_objects
        '
        Me.lbl_oc_web_objects.AutoSize = True
        Me.lbl_oc_web_objects.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Bold)
        Me.lbl_oc_web_objects.Location = New System.Drawing.Point(40, 103)
        Me.lbl_oc_web_objects.Name = "lbl_oc_web_objects"
        Me.lbl_oc_web_objects.Size = New System.Drawing.Size(135, 23)
        Me.lbl_oc_web_objects.TabIndex = 8
        Me.lbl_oc_web_objects.Text = "IF (Web-Object)"
        Me.lbl_oc_web_objects.Visible = False
        '
        'lbl_oc_condition
        '
        Me.lbl_oc_condition.AutoSize = True
        Me.lbl_oc_condition.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_oc_condition.Location = New System.Drawing.Point(60, 267)
        Me.lbl_oc_condition.Name = "lbl_oc_condition"
        Me.lbl_oc_condition.Size = New System.Drawing.Size(90, 18)
        Me.lbl_oc_condition.TabIndex = 9
        Me.lbl_oc_condition.Text = "(CONDITION)"
        Me.lbl_oc_condition.Visible = False
        '
        'lbl_ec_expression
        '
        Me.lbl_ec_expression.AutoSize = True
        Me.lbl_ec_expression.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Bold)
        Me.lbl_ec_expression.Location = New System.Drawing.Point(315, 119)
        Me.lbl_ec_expression.Name = "lbl_ec_expression"
        Me.lbl_ec_expression.Size = New System.Drawing.Size(108, 23)
        Me.lbl_ec_expression.TabIndex = 10
        Me.lbl_ec_expression.Text = "EXPRESSION"
        Me.lbl_ec_expression.Visible = False
        '
        'lbl_ex_condition
        '
        Me.lbl_ex_condition.AutoSize = True
        Me.lbl_ex_condition.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Bold)
        Me.lbl_ex_condition.Location = New System.Drawing.Point(315, 210)
        Me.lbl_ex_condition.Name = "lbl_ex_condition"
        Me.lbl_ex_condition.Size = New System.Drawing.Size(103, 23)
        Me.lbl_ex_condition.TabIndex = 11
        Me.lbl_ex_condition.Text = "CONDITION"
        Me.lbl_ex_condition.Visible = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Bold)
        Me.Label5.Location = New System.Drawing.Point(175, 19)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(121, 23)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "IF CONDITION"
        '
        'LB_Object_List
        '
        Me.LB_Object_List.Enabled = False
        Me.LB_Object_List.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LB_Object_List.FormattingEnabled = True
        Me.LB_Object_List.ItemHeight = 14
        Me.LB_Object_List.Location = New System.Drawing.Point(11, 129)
        Me.LB_Object_List.Name = "LB_Object_List"
        Me.LB_Object_List.Size = New System.Drawing.Size(195, 88)
        Me.LB_Object_List.TabIndex = 15
        Me.LB_Object_List.Visible = False
        '
        'lbl_oc_IS
        '
        Me.lbl_oc_IS.AutoSize = True
        Me.lbl_oc_IS.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Bold)
        Me.lbl_oc_IS.Location = New System.Drawing.Point(85, 230)
        Me.lbl_oc_IS.Name = "lbl_oc_IS"
        Me.lbl_oc_IS.Size = New System.Drawing.Size(19, 23)
        Me.lbl_oc_IS.TabIndex = 16
        Me.lbl_oc_IS.Text = "="
        Me.lbl_oc_IS.Visible = False
        '
        'cmb_Operator
        '
        Me.cmb_Operator.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_Operator.Enabled = False
        Me.cmb_Operator.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmb_Operator.FormattingEnabled = True
        Me.cmb_Operator.Items.AddRange(New Object() {"=", "!=", ">", ">=", "<", "<="})
        Me.cmb_Operator.Location = New System.Drawing.Point(343, 181)
        Me.cmb_Operator.Name = "cmb_Operator"
        Me.cmb_Operator.Size = New System.Drawing.Size(44, 26)
        Me.cmb_Operator.TabIndex = 17
        Me.cmb_Operator.Visible = False
        '
        'cmb_another_conditions
        '
        Me.cmb_another_conditions.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_another_conditions.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmb_another_conditions.FormattingEnabled = True
        Me.cmb_another_conditions.Items.AddRange(New Object() {"End of Condition", "&& (AND)", "|| (OR)"})
        Me.cmb_another_conditions.Location = New System.Drawing.Point(180, 335)
        Me.cmb_another_conditions.Name = "cmb_another_conditions"
        Me.cmb_another_conditions.Size = New System.Drawing.Size(130, 26)
        Me.cmb_another_conditions.TabIndex = 19
        Me.cmb_another_conditions.Visible = False
        '
        'bt_update
        '
        Me.bt_update.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Bold)
        Me.bt_update.Location = New System.Drawing.Point(190, 367)
        Me.bt_update.Name = "bt_update"
        Me.bt_update.Size = New System.Drawing.Size(108, 30)
        Me.bt_update.TabIndex = 20
        Me.bt_update.Text = "Update"
        Me.bt_update.UseVisualStyleBackColor = True
        Me.bt_update.Visible = False
        '
        'lb_View
        '
        Me.lb_View.FormattingEnabled = True
        Me.lb_View.Items.AddRange(New Object() {"IF"})
        Me.lb_View.Location = New System.Drawing.Point(11, 412)
        Me.lb_View.Name = "lb_View"
        Me.lb_View.Size = New System.Drawing.Size(432, 69)
        Me.lb_View.TabIndex = 21
        Me.lb_View.Visible = False
        '
        'bt_up_View_Condition
        '
        Me.bt_up_View_Condition.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt_up_View_Condition.Location = New System.Drawing.Point(449, 412)
        Me.bt_up_View_Condition.Name = "bt_up_View_Condition"
        Me.bt_up_View_Condition.Size = New System.Drawing.Size(29, 28)
        Me.bt_up_View_Condition.TabIndex = 37
        Me.bt_up_View_Condition.Text = "↑"
        Me.bt_up_View_Condition.UseVisualStyleBackColor = True
        Me.bt_up_View_Condition.Visible = False
        '
        'bt_Delete_View
        '
        Me.bt_Delete_View.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt_Delete_View.Image = Global.Auto_E.My.ResourcesRepair.Resources.free
        Me.bt_Delete_View.Location = New System.Drawing.Point(449, 446)
        Me.bt_Delete_View.Name = "bt_Delete_View"
        Me.bt_Delete_View.Size = New System.Drawing.Size(29, 34)
        Me.bt_Delete_View.TabIndex = 36
        Me.bt_Delete_View.UseVisualStyleBackColor = True
        Me.bt_Delete_View.Visible = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(7, 390)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(50, 19)
        Me.Label1.TabIndex = 38
        Me.Label1.Text = "View :"
        '
        'IF_Form
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(486, 538)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.bt_up_View_Condition)
        Me.Controls.Add(Me.bt_Delete_View)
        Me.Controls.Add(Me.lb_View)
        Me.Controls.Add(Me.bt_update)
        Me.Controls.Add(Me.cmb_another_conditions)
        Me.Controls.Add(Me.cmb_Operator)
        Me.Controls.Add(Me.lbl_oc_IS)
        Me.Controls.Add(Me.LB_Object_List)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.lbl_ex_condition)
        Me.Controls.Add(Me.lbl_ec_expression)
        Me.Controls.Add(Me.lbl_oc_condition)
        Me.Controls.Add(Me.lbl_oc_web_objects)
        Me.Controls.Add(Me.rb_expression_condition)
        Me.Controls.Add(Me.rb_object_condition)
        Me.Controls.Add(Me.bt_save)
        Me.Controls.Add(Me.txt_condition)
        Me.Controls.Add(Me.txt_Expression)
        Me.Controls.Add(Me.cmb_Conditions_List)
        Me.Name = "IF_Form"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "IF Condition"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmb_Conditions_List As ComboBox
    Friend WithEvents txt_Expression As TextBox
    Friend WithEvents txt_condition As TextBox
    Friend WithEvents bt_save As Button
    Friend WithEvents rb_object_condition As RadioButton
    Friend WithEvents rb_expression_condition As RadioButton
    Friend WithEvents lbl_oc_web_objects As Label
    Friend WithEvents lbl_oc_condition As Label
    Friend WithEvents lbl_ec_expression As Label
    Friend WithEvents lbl_ex_condition As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents LB_Object_List As ListBox
    Friend WithEvents lbl_oc_IS As Label
    Friend WithEvents cmb_Operator As ComboBox
    Friend WithEvents cmb_another_conditions As ComboBox
    Friend WithEvents bt_update As Button
    Friend WithEvents lb_View As ListBox
    Friend WithEvents bt_up_View_Condition As Button
    Friend WithEvents bt_Delete_View As Button
    Friend WithEvents Label1 As Label
End Class
