﻿Imports System.Data.SqlClient
Public Class IF_Form
    'DataBase
    Dim cn As SqlConnection
    Dim cmd As SqlCommand
    Dim da As SqlDataAdapter
    Dim bm As BindingManagerBase
    Dim ds As New Data.DataSet

    Dim path As String
    Private Sub rb_object_condition_CheckedChanged(sender As Object, e As EventArgs) Handles rb_object_condition.CheckedChanged
        If rb_object_condition.Checked = True Then


            'elements visible
            cmb_another_conditions.Visible = True
            cmb_another_conditions.Enabled = True
            bt_update.Visible = True
            lbl_oc_condition.Visible = True
            lbl_oc_IS.Visible = True
            lbl_oc_web_objects.Visible = True

            cmb_Operator.Visible = False
            lbl_ec_expression.Visible = False
            lbl_ex_condition.Visible = False
            txt_condition.Visible = False
            txt_Expression.Visible = False
            cmb_Conditions_List.Visible = True

            LB_Object_List.Visible = True
            cmb_Conditions_List.Enabled = True
            LB_Object_List.Enabled = True

            txt_condition.Enabled = False
            txt_Expression.Enabled = False

        End If
    End Sub

    Private Sub rb_expression_condition_CheckedChanged(sender As Object, e As EventArgs) Handles rb_expression_condition.CheckedChanged
        If rb_expression_condition.Checked = True Then

            'elements visible
            cmb_another_conditions.Visible = True
            cmb_another_conditions.Enabled = True
            bt_update.Visible = True
            lbl_oc_condition.Visible = False
            lbl_oc_IS.Visible = False
            lbl_oc_web_objects.Visible = False

            cmb_Operator.Visible = True
            lbl_ec_expression.Visible = True
            lbl_ex_condition.Visible = True
            cmb_Conditions_List.Visible = False
            txt_condition.Visible = True
            txt_Expression.Visible = True

            LB_Object_List.Visible = False
            cmb_Conditions_List.Enabled = False
            LB_Object_List.Enabled = False
            cmb_Operator.Enabled = True
            txt_condition.Enabled = True
            txt_Expression.Enabled = True

        End If
    End Sub
    Sub Get_WebObject_List()
        Dim reader As System.IO.StreamReader = My.Computer.FileSystem.OpenTextFileReader("\\host2\Automation\Auto-E\Generated_Test_Components\" + My.Forms.CNS_Auto_E.TV_Test_Component_List.SelectedNode.Text + "\WebObject Repository\" + My.Forms.CNS_Auto_E.TV_Test_Component_List.SelectedNode.Text + ".properties")
        Dim a As String
        Dim no As Integer = 1
        Dim PropertyNamesArray As String()
        Dim propertyList As New List(Of String)()
        Do
            a = reader.ReadLine
            If a <> "" Then
                Dim PropertyArray As Char() = a.ToCharArray
                Dim firstName As Char() = ""

                For i = 0 To PropertyArray.Length - 1
                    If PropertyArray(i) = "=" Then
                        Exit For
                    Else
                        firstName = firstName + PropertyArray(i)
                    End If
                Next


                propertyList.Add(firstName)
                ' MsgBox(no.ToString + " : Property Name = " + firstName)
                no = no + 1
                firstName = ""
            End If
        Loop Until a Is Nothing

        reader.Close()
        PropertyNamesArray = propertyList.ToArray

        For i = 0 To PropertyNamesArray.Length - 1
            Dim getElement_Type As Char() = PropertyNamesArray(i).ToCharArray
            Dim getElement_Ini As String = ""
            For y = 0 To 3
                getElement_Ini = getElement_Ini + getElement_Type(y)
            Next



            If getElement_Ini = "lnk_" Or getElement_Ini = "lbl_" Or getElement_Ini = "txt_" Or getElement_Ini = "cmb_" Or getElement_Ini = "chk_" Or getElement_Ini = "rbd_" Or getElement_Ini = "img_" Or getElement_Ini = "btn_" Then

                LB_Object_List.Items.Add(PropertyNamesArray(i))
            End If
            getElement_Ini = ""
        Next
    End Sub

    Private Sub IF_Form_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Get_WebObject_List()
        cmb_another_conditions.SelectedItem = "End of Condition"
        cmb_Operator.SelectedItem = "="

        'START : DB SELECTION
        cn = New SqlConnection("Server=db;Database=Auto_E;Integrated Security=SSPI;")
        cmd = New SqlCommand("select * from Test_Component_Creation", cn)
        da = New SqlDataAdapter(cmd)
        da.Fill(ds)
        bm = Me.BindingContext(ds.Tables(0))
        'END : DB SELECTION

        'START : GET DATA FROM DB OF "IF_CONDITION"
        Dim get_lb_view_if_Exist, qury As String
        qury = "select IF_Condition from If_Conditions where TestComponent_Name='" + My.Forms.CNS_Auto_E.TV_Test_Component_List.SelectedNode.Text + "' AND RowIds='" + Convert.ToString(My.Forms.CNS_Auto_E.DG_CodeSection.Rows(My.Forms.CNS_Auto_E.GetSelectedRow()).Cells(5).Value) + "';"

        Dim Execute_Cmd As New SqlCommand(qury, cn)
        cn.Open()
        get_lb_view_if_Exist = Convert.ToString(Execute_Cmd.ExecuteScalar())
        cn.Close()
        'END : GET DATA FROM DB OF "IF_CONDITION"

        'START : ADD DATA INTO LB_VIEW FROM DB"
        If get_lb_view_if_Exist <> "" Then
            Dim chars() = get_lb_view_if_Exist.ToCharArray()
            Dim lb_view_data As String
            For i = 0 To chars.Length - 1
                If chars(i).ToString <> ";" Then
                    lb_view_data = lb_view_data + chars(i).ToString
                Else
                    lb_View.Items.Add(lb_view_data)
                    'Exit For
                    lb_view_data = ""
                End If
            Next
            lb_View.Visible = True
            bt_Delete_View.Visible = True
            bt_up_View_Condition.Visible = True
            rb_object_condition.Checked = True
        End If
        'END : ADD DATA INTO LB_VIEW FROM DB"

    End Sub

    Private Sub cmb_Conditions_List_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmb_Conditions_List.SelectedIndexChanged
        If LB_Object_List.Text = "" Then
            MsgBox("First Select Web-Object first.")
        End If
    End Sub

    Private Sub bt_save_Click(sender As Object, e As EventArgs) Handles bt_save.Click


        If lb_View.Visible <> True Then
            MsgBox("Please Update First.")
        ElseIf lb_View.Items(lb_View.Items.Count - 1).ToString <> "End of Condition" Then
            'CHECK WHETHER LAST CONDITION IS 'END OF CONDITIONS'
            MsgBox("In View, Last Condition should be 'End of Condition'.")
        Else
            'First Save Code Section Data
            My.Forms.CNS_Auto_E.SaveComponent_On_bt_Create_Compo("No")

            ''MsgBox("Update " + My.Forms.CNS_Auto_E.TV_Test_Component_List.SelectedNode.Text + " set IF_Condition='" + Marge_View() + "' where RowIds='" + Convert.ToString(My.Forms.CNS_Auto_E.DG_CodeSection.SelectedRows(My.Forms.CNS_Auto_E.GetSelectedRow()).Cells(5).Value) + "'")
            GetRowsId_ToCheck_FieldExist()
            'UPdate COndition in Table
            'Dim Update_TC_Table As String
            Dim Insert_Update_Query As String

            'Update_TC_Table = "Update " + My.Forms.CNS_Auto_E.TV_Test_Component_List.SelectedNode.Text + " set IF_Condition='" + Marge_View() + "' where RowIds='" + Convert.ToString(My.Forms.CNS_Auto_E.DG_CodeSection.Rows(My.Forms.CNS_Auto_E.GetSelectedRow()).Cells(5).Value) + "'"
            'MsgBox(Convert.ToString(DG_CodeSection.Rows(i).Cells(3).Value))



            If GetRowsId_ToCheck_FieldExist() = 0 Then
                Insert_Update_Query = "insert into If_Conditions values('" + My.Forms.CNS_Auto_E.TV_Test_Component_List.SelectedNode.Text + "','" + Convert.ToString(My.Forms.CNS_Auto_E.DG_CodeSection.Rows(My.Forms.CNS_Auto_E.GetSelectedRow()).Cells(5).Value) + "','" + Marge_View() + "')"
            Else
                Insert_Update_Query = "update If_Conditions set IF_Condition='" + Marge_View() + "' where TestComponent_Name='" + My.Forms.CNS_Auto_E.TV_Test_Component_List.SelectedNode.Text + "' AND RowIds='" + Convert.ToString(My.Forms.CNS_Auto_E.DG_CodeSection.Rows(My.Forms.CNS_Auto_E.GetSelectedRow()).Cells(5).Value) + "'"
            End If


            Dim Execute_Cmd As New SqlCommand(Insert_Update_Query, cn)

            cn.Open()
            Execute_Cmd.ExecuteNonQuery()
            cn.Close()
            'END: ADD DATA INTO TABLE
            MsgBox("Condition Saved",, "Auto-E Condition Saved")
            My.Forms.IF_Form.Close()
            'Marge LB_View items and to differneciate it use ";" or "," and save into DB on retreive extract string and remove diff char.
        End If
    End Sub
    Function GetRowsId_ToCheck_FieldExist()

        Dim count_TC_table As String = "select COUNT(RowIds) from If_Conditions where TestComponent_Name='" + My.Forms.CNS_Auto_E.TV_Test_Component_List.SelectedNode.Text + "' AND RowIds='" + Convert.ToString(My.Forms.CNS_Auto_E.DG_CodeSection.Rows(My.Forms.CNS_Auto_E.GetSelectedRow()).Cells(5).Value) + "'"
        Dim Execute_Cmdd As New SqlCommand(count_TC_table, cn)
        cn.Open()
        Dim FPP As Integer = Execute_Cmdd.ExecuteScalar()
        cn.Close()
        Return FPP
    End Function
    Function Marge_View()
        Dim marge_vie As String

        For i = 0 To lb_View.Items.Count - 1
            If lb_View.Items(i).ToString <> "IF" Then
                marge_vie = marge_vie + lb_View.Items(i).ToString + ";"
            End If
        Next

        Return marge_vie

    End Function

    Private Sub bt_update_Click(sender As Object, e As EventArgs) Handles bt_update.Click
        If (rb_object_condition.Checked = True) And (LB_Object_List.Text = "" Or cmb_Conditions_List.Text = "") Then
            'CHECK WHETHER OBJECT CONDITIONS IS FILLED
            MsgBox("Please Select Web-Object/Condition.")
        ElseIf (rb_expression_condition.Checked = True) And (txt_condition.Text = "" Or txt_Expression.Text = "") Then
            'CHECK WHETHER EXPRESSION CONDITIONS IS FILLED
            MsgBox("Please Enter Expression/Condition.")
        ElseIf lb_View.Items(lb_View.Items.Count - 1).ToString = "End of Condition" Then
            'CHECK WHETHER LAST CONDITION IS 'END OF CONDITIONS'
            MsgBox("In View, Last Condition is 'End of Condition'.")
        Else
            'VISIBLE SOME FIELDS
            lb_View.Visible = True
            bt_Delete_View.Visible = True
            bt_up_View_Condition.Visible = True
            'VISIBLE SOME FIELDS


            If rb_object_condition.Checked = True Then
                If cmb_Conditions_List.Text = "IS_VISIBLE" Then
                    lb_View.Items.Add("IS_ELEMENT_DISPLAY(""" + LB_Object_List.Text + """) == true")
                ElseIf cmb_Conditions_List.Text = "IS_NOT_VISIBLE" Then
                    lb_View.Items.Add("IS_ELEMENT_DISPLAY(""" + LB_Object_List.Text + """) == false")
                ElseIf cmb_Conditions_List.Text = "IS_EXIST" Then
                    lb_View.Items.Add("IS_ELEMENT_EXIST(""" + LB_Object_List.Text + """) == true")
                ElseIf cmb_Conditions_List.Text = "IS_NOT_EXIST" Then
                    lb_View.Items.Add("IS_ELEMENT_EXIST(""" + LB_Object_List.Text + """) == false")
                End If

                If cmb_another_conditions.Text = "&& (AND)" Then
                    lb_View.Items.Add("&&")
                ElseIf cmb_another_conditions.Text = "|| (OR)" Then
                    lb_View.Items.Add("||")
                Else
                    lb_View.Items.Add(cmb_another_conditions.Text)
                End If

            ElseIf rb_expression_condition.Checked = True Then

                'START : CHECK # CONDITION
                Dim condition, expression As String
                If txt_condition.Text.Substring(0, 1) = "#" Then
                    condition = "Excel_GetData(""" + txt_condition.Text.Remove(0, 1) + """)"
                Else
                    condition = txt_condition.Text
                End If
                If txt_Expression.Text.Substring(0, 1) = "#" Then
                    expression = "Excel_GetData(""" + txt_Expression.Text.Remove(0, 1) + """)"
                Else
                    expression = txt_Expression.Text
                End If
                'END : CHECK # CONDITION



                If cmb_Operator.Text = "=" Then


                    lb_View.Items.Add("""" + expression + """.equals(""" + condition + """)")

                ElseIf cmb_Operator.Text = ">" Or cmb_Operator.Text = ">=" Or cmb_Operator.Text = "<" Or cmb_Operator.Text = "<=" Then
                    lb_View.Items.Add(expression + " " + cmb_Operator.Text + " " + condition + "")
                ElseIf cmb_Operator.Text = "!=" Then
                    lb_View.Items.Add("!""" + expression + """.equals(""" + condition + """)")
                End If

                If cmb_another_conditions.Text = "&& (AND)" Then
                    lb_View.Items.Add("&&")
                ElseIf cmb_another_conditions.Text = "|| (OR)" Then
                    lb_View.Items.Add("||")
                Else
                    lb_View.Items.Add(cmb_another_conditions.Text)
                End If
            End If
            cmb_another_conditions.Text = "End of Condition"
        End If

    End Sub

    Private Sub lb_View_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lb_View.SelectedIndexChanged

    End Sub

    Private Sub bt_selected_remove_Iterative_Click(sender As Object, e As EventArgs) Handles bt_Delete_View.Click
        If lb_View.SelectedIndex <> -1 Then
            If lb_View.SelectedItem.ToString() <> "IF" Then
                lb_View.Items.Remove(lb_View.SelectedItem.ToString())
            End If
        End If
    End Sub

    Private Sub bt_up_iterative_Click(sender As Object, e As EventArgs) Handles bt_up_View_Condition.Click
        If lb_View.Items.Count > 1 Then
            Dim item As Object
            Dim index As Integer
            item = lb_View.SelectedItem()
            index = lb_View.Items.IndexOf(item)
            If (index - 1) >= 0 Then
                lb_View.Items.Insert(index - 1, item)
                lb_View.SelectedIndex = index - 1
                lb_View.Items.RemoveAt(index + 1)
            End If

        End If
    End Sub
End Class